import { useNavigate } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const StudentTable = () => {
  const [students, setStudents] = useState([]);
  const navigate = useNavigate();

  const DisplayDetails = (id) => {
    navigate('/ViewDetails/' + id);
  };
  const EditDetails = (id) => {
    navigate('/editstudent/' + id);
  };
 const RemoveDetails = (id) => {
  if (window.confirm('Are you sure to delete this student?')) {
    fetch(`http://localhost:3001/students/${id}`, {
      method: 'DELETE',
    })
      .then((res) => {
        alert('Student deleted successfully!');
        window.location.reload(); // or update the state
      })
      .catch((err) => {
        console.error('Error deleting student:', err);
      });
  }
};

  useEffect(() => {
    fetch('http://localhost:3001/students')
      .then((response) => response.json())
      .then((data) => {
        setStudents(data);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);

  return (
    <div className='container'>
      <div className='row'>
        <div className='col-12'>
          <div className="student-card">
            <div className="student-header">
              <h2 className='head'>Student Records</h2>
              <Link to='/createstudent' className='add-btn btn'>Add new Student</Link>
            </div>

            <table className="student-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>NAME</th>
                  <th>PLACE</th>
                  <th>PHONE</th>
                  <th>ACTIONS</th>
                </tr>
              </thead>
              <tbody>
                {
                  students && students.map((student,index) => (
                    <tr key={student.id}>
                      <td>{index+1}</td>
                      <td>{student.name}</td>
                      <td>{student.place}</td>
                      <td>{student.phone}</td>
                      <td className="action-buttons">
                        <button onClick={() => DisplayDetails(student.id)} className="btn view-btn">View</button>
                        <button onClick={() => EditDetails(student.id)} className="btn edit-btn">Edit</button>
                        <button onClick={() => RemoveDetails(student.id)} className="btn delete-btn">Delete</button>
                      </td>
                    </tr>
                  ))
                }
              </tbody>
            </table>

          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentTable;
