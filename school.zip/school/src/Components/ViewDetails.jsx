import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';

const ViewDetails = () => {
  const { studentid } = useParams();
  const [student, setStudent] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:3001/students/${studentid}`)
      .then((res) => res.json())
      .then((data) => setStudent(data))
      .catch((err) => console.error('Failed to fetch student:', err));
  }, [studentid]);

  if (!student) return <div className='container'><h2>Loading student data...</h2></div>;

  return (
    <div className='container'>
      <div className='row'>
        <div className='col-12'>
          <div className='student-card'>
            <div className="student-header">
            <h1 className="head-view">Student Details</h1>
            <div className='student-details'>
              <p><strong>Id:</strong> {student.id}</p>
              <p><strong>Name:</strong> {student.name}</p>
              <p><strong>Place:</strong> {student.place}</p>
              <p><strong>Phone:</strong> {student.phone}</p>
              </div>
              <Link to={'/'} className='btn btn-infoview'>Back</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewDetails;
