import { useNavigate } from 'react-router-dom';
import React, { useState } from 'react'
import { Link } from 'react-router-dom';

const CreateStudent = () => {
    const [id,setId]=useState ("");
    const [name,setName]=useState ("");
    const [place,setPlace]=useState ("");
    const [phone,setPhone]=useState ("");
    const [validation,setValidation]=useState(false);
    const navigate=useNavigate();
    const handleSubmit = (e) => {
        e.preventDefault();
        const studentData = { id, name, place, phone }
        console.log(studentData);
        fetch('http://localhost:3001/students',{
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(studentData)
    
        })
        .then((res) => {
            alert("Saved Data Saved Successfully");
            navigate('/')
        })
        .catch((err) => console.log(err.message))
    }
  return (
    <>
    <div className='container'>
        <div className='row'>
            <div className='col-12'>
                <div className="student-card">
                    <div className="student-header">
                        <h2 className='head'>Add New Student</h2>
                    </div>
                    <form onSubmit={handleSubmit}>
                      <div className='form-group'>
                        <label htmlFor="" >Id:</label>
                        <input type="text" id='id' name='id'  value={id} onChange={e=>setId (e.target.value)} onMouseDown={()=>setValidation(true)} 
                        className='form-control' /> {id.length==0 && validation && <span className='text-danger'>Id is required</span>}
                      </div>
                        <div className="form-group">
                            <label htmlFor="">Name:</label>
                            <input type="text" id='name' name='name' value={name} onChange={e=>setName (e.target.value)} onMouseDown={()=>setValidation(true)}
                            className='form-control' /> {name.length==0 && validation && <span className='text-danger'>Name is required</span>}
                        </div>
                        <div className="form-group">
                            <label htmlFor="">Place:</label>
                            <input type="text" id='place' name='place' value={place} onChange={e=>setPlace (e.target.value)} onMouseDown={()=>setValidation(true)}
                            className='form-control' /> {place.length==0 && validation && <span className='text-danger'>Place is required</span>}
                        </div>
                        <div className="form-group">
                            <label htmlFor="">Phone:</label>
                            <input type="text" id='phone' name='phone' value={phone} onChange={e=>setPhone (e.target.value)} onMouseDown={()=>setValidation(true)}
                            className='form-control' /> {phone.length==0 && validation &&<span className='text-danger'>Phone is required</span>}
                        </div>
                        <div className="button-group form">
                            <button className='btn btn-primaryform'>Save</button>
                            <Link to={'/'} className='btn btn-dangerform'>Back</Link>  
                        </div>
                    </form>
               </div>
            </div>
        </div>
    </div>
    </>
  )
}
export default CreateStudent;