import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const EditStudent = () => {
  const { studentid } = useParams();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    place: '',
    phone: '',
  });

  // Fetch student data
  useEffect(() => {
    fetch(`http://localhost:3001/students/${studentid}`)
      .then((res) => res.json())
      .then((data) => setFormData(data))
      .catch((err) => console.error('Error loading student:', err));
  }, [studentid]);

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.id]: e.target.value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    fetch(`http://localhost:3001/students/${studentid}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    })
      .then(res => {
          alert('Student updated successfully!');
          navigate('/');
      })
      .catch(err => console.error('Update error:', err));
  };

  return (
    <div className='container'>
      <div className='row'>
        <div className='col-12'>
          <div className="student-card">
            <div className="student-header">
              <h2 className='head'>Edit Student</h2>
            </div>
            <form onSubmit={handleSubmit}>
              <div className='form-group'>
                <label htmlFor="id">ID:</label>
                <input type="text" className="form-control" id="id" value={formData.id} onChange={handleChange} disabled />
              </div>
              <div className="form-group">
                <label htmlFor="name">Name:</label>
                <input type="text" className="form-control" id="name" value={formData.name} onChange={handleChange} />
              </div>
              <div className="form-group">
                <label htmlFor="place">Place:</label>
                <input type="text" className="form-control" id="place" value={formData.place} onChange={handleChange} />
              </div>
              <div className="form-group">
                <label htmlFor="phone">Phone:</label>
                <input type="text" className="form-control" id="phone" value={formData.phone} onChange={handleChange} />
              </div>
              <button type="submit" className="btn btn-primaryform">Update</button>
              <button type="button" onClick={() => navigate('/')} className="btn btn-dangerform">Back</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditStudent;
