import React from 'react';
import "./App.css";
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import StudentTable from './Components/StudentTable';
import CreateStudent from './Components/CreateStudent';
import ViewDetails from './Components/ViewDetails';
import EditStudent from './Components/EditStudent';

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<StudentTable />} />
        <Route path='/createstudent' element={<CreateStudent />} />
        <Route path='/ViewDetails/:studentid' element={<ViewDetails />} />
        <Route path='/editstudent/:studentid' element={<EditStudent />} />

      </Routes>
    </BrowserRouter>
  );
};

export default App;
