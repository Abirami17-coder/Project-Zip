//icons
import "bootstrap-icons/font/bootstrap-icons.css";
import "remixicon/fonts/remixicon.css";

//bootstrap
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";

//font awesome
import { library } from "@fortawesome/fontawesome-svg-core";
import { fas } from "@fortawesome/free-solid-svg-icons";

import "./App.css";
import Header from "./components/navigation/Header";
import SideBar from "./components/side-navigation/SideBar";

//router
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Outlet,
  BrowserRouter,
} from "react-router-dom";
import Dashboard from "./components/profile-management/Dashboard";
import MyProfile from "./components/profile-management/MyProfile";
import { useGlobalContext } from "./GlobalContext";
import Login from "./components/general/Login";
import MyPassword from "./components/profile-management/MyPassword";
import { LoggedUserDetail } from "./service/UserService";
import { useEffect } from "react";
import TableTemplate from "./components/template/TableTemplate";
import FormTemplate from "./components/template/FormTemplate";

function App() {
  library.add(fas);

  const handleRetry = () => {
    setAppError(false); // Close the modal when retry is triggered
  };

  const makeLogout = () => {
    localStorage.removeItem("oojwt");
    setAppError(false); // Close the modal when retry is triggered
    setAppUser(null);
    setIsLogin(false);
  };

  const {
    isLoading,
    setIsLoading,
    isAppError,
    setAppError,
    appErrorMessage,
    setAppErrorMessage,
    appErrorTitle,
    setAppErrorTitle,
    appErrorMode,
    setAppErrorMode,
    appUser,
    setAppUser,
    isLogin,
    setIsLogin,
    isLogoutRequest,
    setIsLogoutRequest,
  } = useGlobalContext();

  //call LoggedUserDetail on component load using useEffect
  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        setIsLoading(true);
        const response = await LoggedUserDetail();
        if (response.status === 200) {
          setAppUser(response.user);
          setIsLogin(true);
        }
      } catch (error) {
        setAppError(true);
        setAppErrorTitle("Error");
        setAppErrorMessage("Failed to load user details");
        setAppErrorMode("error");
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserDetails();
  }, []);

  useEffect(() => {
    document.querySelectorAll("input").forEach((input) => {
      input.setAttribute("autocomplete", "off");
    });
  }, []);

  return (
    <>
      {/* loading screen */}
      {isLoading && (
        <div className="loading-overlay">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      )}

      {/* Modal Error Message */}
      {isAppError && (
        <div
          className={appErrorMode + " app-error-message modal d-block"} // `d-block` ensures it always displays
          tabIndex="-1"
          role="dialog"
          aria-labelledby="errorModalLabel"
          aria-hidden="true"
          style={{ backgroundColor: "rgba(0,0,0,0.5)" }} // Optional backdrop styling
        >
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="errorModalLabel">
                  {appErrorTitle}
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  aria-label="Close"
                  onClick={handleRetry}
                ></button>
              </div>
              <div className="modal-body">
                <p>{appErrorMessage}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Error Message */}
      {isLogoutRequest && (
        <div
          className={"warning app-error-message modal d-block"} // `d-block` ensures it always displays
          tabIndex="-1"
          role="dialog"
          aria-labelledby="errorModalLabel"
          aria-hidden="true"
          style={{ backgroundColor: "rgba(0,0,0,0.5)" }} // Optional backdrop styling
        >
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="errorModalLabel">
                  Logout confirmation
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  aria-label="Close"
                  onClick={handleRetry}
                ></button>
              </div>
              <div className="modal-body">
                <p>
                  Do you want to logout?
                  <br></br>
                  <br></br>
                  <button className="btn btn-success-app btn-md" type="button">
                    {" "}
                    No{" "}
                  </button>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <button
                    className="btn btn-danger btn-md"
                    type="button"
                    onClick={makeLogout}
                  >
                    {" "}
                    Yes{" "}
                  </button>
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {isLogin ? (
        <>
          <main id="main" className="main">
            <BrowserRouter>
              <Header></Header>
              <SideBar></SideBar>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/myprofile" element={<MyProfile />} />
                <Route path="/mypassword" element={<MyPassword />} />
                
                {/* template */}
                <Route path="/template/table" element={<TableTemplate />} />
                <Route path="/template/form" element={<FormTemplate />} />
                
              </Routes>
              <Outlet></Outlet>
            </BrowserRouter>
          </main>
        </>
      ) : (
        <>
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Login />} />
              <Route path="/login" element={<Login />} />
              {/* 404 Page */}
              <Route path="*" element={<Login />} />
            </Routes>
            <Outlet></Outlet>
          </BrowserRouter>
        </>
      )}
    </>
  );
}

export default App;
