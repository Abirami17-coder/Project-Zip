import axios from 'axios';
import config from '../config';

const GetAll = async (page, count, keyword, status) => {
    try {
        const token = localStorage.getItem("oojwt");
        const response = await axios.get(config.apiUrl + 'kitchen/search?page=' + page + '&count=' + count + '&keyword=' + keyword + '&status=' + status, {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        });
        console.log(response.data);
        if (response.status === 200) {
            return {
                status: 200,
                kitchens: response.data.kitchens
            };
        }
    } catch (error) {
        console.log(error);
        if (error.response.status === 401) {
            return {
                status: 401,
                message: error.response.data.message
            };
        }
    }
}

const GetById = async (id) => {
    try {
        const token = localStorage.getItem("oojwt");
        const response = await axios.get(config.apiUrl + 'kitchen/get-by-id?id=' + id, {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        });
        console.log(response.data);
        if (response.status === 200) {
            return {
                status: 200,
                kitchen: response.data.kitchen
            };
        }
    } catch (error) {
        console.log(error);
        if (error.response.status === 401) {
            return {
                status: 401,
                message: error.response.data.message
            };
        }
    }
}

//create a function to send the name and image to axios post to save the cateogry
const Add = async (name, cityId, foodCategoryIds, foodCusinesIds, foodDietIds, status, userName, userEmail, userMobile, userPassword, userDob, userGenderId, logo, banner, gstNumber, panNumber, fssaiNumber, fssai, pan, gst, addressLine1, addressLine2, pincode, bio, mapLat, mapLon, bankIfsc, bankAccountNumber, bankAccountName) => {
    try {
        const data = new FormData();
        data.append('name', name);
        data.append('city_id', cityId);
        foodCategoryIds.forEach((temp) => {
            data.append('food_category_ids[]', temp.id);
        });
        foodCusinesIds.forEach((temp) => {
            data.append('food_cusine_ids[]', temp.id);
        });
        foodDietIds.forEach((temp) => {
            data.append('food_diet_ids[]', temp.id);
        });
        data.append('status', status);
        data.append('user_name', userName);
        data.append('user_email', userEmail);
        data.append('user_mobile', userMobile);
        data.append('user_password', userPassword);
        data.append('user_dob', userDob);
        data.append('user_gender_id', userGenderId);
        data.append('logo', logo);
        data.append('banner', banner);
        data.append('gst_number', gstNumber);
        data.append('pan_number', panNumber);
        data.append('fssai_number', fssaiNumber);
        data.append('fssai', fssai);
        data.append('pan', pan);
        data.append('gst', gst);
        data.append('address_line_1', addressLine1);
        data.append('address_line_2', addressLine2);
        data.append('pincode', pincode);
        data.append('bio', bio);
        data.append('map_lat', mapLat);
        data.append('map_lon', mapLon);
        data.append('bank_ifsc', bankIfsc);
        data.append('bank_account_number', bankAccountNumber);
        data.append('bank_account_name', bankAccountName);

        const token = localStorage.getItem("oojwt");
        const response = await axios.post(config.apiUrl + 'kitchen/add', data, {
            headers: {
                'Authorization': 'Bearer ' + token,
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log(response.data);
        if (response.status === 200) {
            return {
                status: 200,
                message: response.data.message,
                kitchen: response.data.kitchen
            };
        }
        console.log("error from api");
        return {
            status: 401,
            message: response.data.message,
        };
    } catch (error) {
        console.log(error);
        return {
            status: 401,
            message: error.response.data.message
        };
    }
}

const Update = async (id, name, cityId, foodCategoryIds, foodCusinesIds, foodDietIds, status, userName, userEmail, userMobile, userDob, userGenderId, logo, banner, gstNumber, panNumber, fssaiNumber, fssai, pan, gst, addressLine1, addressLine2, pincode, bio, mapLat, mapLon, bankIfsc, bankAccountNumber, bankAccountName) => {
    try {
        const data = new FormData();
        data.append("id", id);
        data.append('name', name);
        data.append('city_id', cityId);
        foodCategoryIds.forEach((temp) => {
            data.append('food_category_ids[]', temp.id);
        });
        foodCusinesIds.forEach((temp) => {
            data.append('food_cusine_ids[]', temp.id);
        });
        foodDietIds.forEach((temp) => {
            data.append('food_diet_ids[]', temp.id);
        });
        data.append('status', status);
        data.append('user_name', userName);
        data.append('user_email', userEmail);
        data.append('user_mobile', userMobile);
        data.append('user_dob', userDob);
        data.append('user_gender_id', userGenderId);
        data.append('logo', logo);
        data.append('banner', banner);
        data.append('gst_number', gstNumber);
        data.append('pan_number', panNumber);
        data.append('fssai_number', fssaiNumber);
        data.append('fssai', fssai);
        data.append('pan', pan);
        data.append('gst', gst);
        data.append('address_line_1', addressLine1);
        data.append('address_line_2', addressLine2);
        data.append('pincode', pincode);
        data.append('bio', bio);
        data.append('map_lat', mapLat);
        data.append('map_lon', mapLon);
        data.append('bank_ifsc', bankIfsc);
        data.append('bank_account_number', bankAccountNumber);
        data.append('bank_account_name', bankAccountName);

        const token = localStorage.getItem("oojwt");
        const response = await axios.post(config.apiUrl + 'kitchen/update', data, {
            headers: {
                'Authorization': 'Bearer ' + token,
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log(response.data);
        if (response.status === 200) {
            return {
                status: 200,
                message: response.data.message,
                kitchen: response.data.kitchen
            };
        }
    } catch (error) {
        return {
            status: error.response.status,
            message: error.response.data.message
        };
    }
}

export { Add, Update, GetById, GetAll };