import React from 'react';
//import fontawesome
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Link } from 'react-router-dom';

function SideBar() {
    return (
        <>
            <aside id='sidebar' className='sidebar'>
                <ul className='sidebar-nav' id='sidebar-nav'>
                    <li className='nav-item'>
                        <Link className='nav-link' to='/'>
                            <i className='bi bi-grid'></i>
                            <span>Dashboard</span>
                        </Link>
                    </li>

                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#setting-nav" data-bs-toggle="collapse" to='#'>
                            <i className='bi bi-gear'></i>
                            <span>Settings</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='setting-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to='/setting/branding'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Branding</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/setting/adlogg'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Adloggs</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/setting/razorpay'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Razorpay</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/setting/banner'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Banner</span>
                                </Link>
                            </li>
                        </ul>
                    </li>

                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#brand-officer-nav" data-bs-toggle="collapse" to='#'>
                            <i className='bi bi-person'></i>
                            <span>Brand Officers</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='brand-officer-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to='/bo/new'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Add New</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/bo/list'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Search</span>
                                </Link>
                            </li>
                        </ul>
                    </li>

                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#components-nav" data-bs-toggle="collapse" to='#'>
                            <i className='bi bi-menu-button-wide'></i>
                            <span>Food Settings</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='components-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to='/master/foodcategory/list'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Categories</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/master/foodcusine/list'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Cuisines</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/master/foodtime/list'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Meal Times</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/master/fooddiet/list'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Diets</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/master/foodallergy/list'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Allegeris</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/master/food/list'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Foods</span>
                                </Link>
                            </li>
                        </ul>
                    </li>
                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#kitchen-nav" data-bs-toggle="collapse" to='#'>
                            <i className='bi bi-cart'></i>
                            <span>Kitchens</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='kitchen-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to='/kitchen/new'>
                                    <i className='bi bi-arrow-right'></i>
                                    <span>New Kitchen</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/kitchen/list'>
                                    <i className='bi bi-arrow-right'></i>
                                    <span>Search Kitchen</span>
                                </Link>
                            </li>
                        </ul>
                    </li>
                   
                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#orders-nav" data-bs-toggle="collapse" to='#'>
                            <i className='bi bi-list'></i>
                            <span>Orders</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='orders-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to='/order/list'>
                                    <i className='bi bi-arrow-right'></i>
                                    <span>New</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/order/list/accepted'>
                                    <i className='bi bi-arrow-right'></i>
                                    <span>Accepted</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/order/list/running'>
                                    <i className='bi bi-arrow-right'></i>
                                    <span>Running</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/order/list/completed'>
                                    <i className='bi bi-arrow-right'></i>
                                    <span>Completed</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/order/list/cancelled'>
                                    <i className='bi bi-arrow-right'></i>
                                    <span>Cancelled</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/order/list/rejected'>
                                    <i className='bi bi-arrow-right'></i>
                                    <span>Rejected</span>
                                </Link>
                            </li>
                        </ul>
                    </li>

                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#coupon-nav" data-bs-toggle="collapse" to='#'>
                            <i className='bi bi-send'></i>
                            <span>Coupons</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='coupon-nav' className='nav-content collapse' data-bs-parent="#coupon-nav">
                            <li>
                                <Link to='/coupon/new'>
                                    <i className='bi bi-arrow-right'></i>
                                    <span>Create Coupon</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/coupon/list'>
                                    <i className='bi bi-arrow-right'></i>
                                    <span>Search</span>
                                </Link>
                            </li>
                           
                        </ul>
                    </li>

                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#report-nav" data-bs-toggle="collapse" to='#'>
                            <i className='bi bi-table'></i>
                            <span>Reports</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='report-nav' className='nav-content collapse' data-bs-parent="#report-nav">
                            <li>
                                <Link to='/report/kitchen'>
                                    <i className='bi bi-arrow-right'></i>
                                    <span>Kitchen Payouts</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/report/portal-earning'>
                                    <i className='bi bi-arrow-right'></i>
                                    <span>Portal Earnings</span>
                                </Link>
                            </li>
                        </ul>
                    </li>
                </ul>
            </aside>
        </>
    )
}

export default SideBar