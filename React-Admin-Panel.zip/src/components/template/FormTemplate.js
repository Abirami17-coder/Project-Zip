import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useGlobalContext } from '../../GlobalContext';
import config from '../../config';
import { Helmet } from 'react-helmet';

export default function FormTemplate() {
  const { setIsLoading, setAppError, setAppErrorMessage, setAppErrorTitle, setAppErrorMode } = useGlobalContext();

  return (
    <>
      <div className='container'>
        <div className='page'>
          <div className='page-heading'>
            <h1>Form Template</h1>
            <span>
              <Link to="/"> Dashboard </Link> / <Link to="/kitchen/list"> Kitchen List </Link>
            </span>
          </div>
          <div className='page-content'>
            <div className="portal">
              <div className='portal-body'>
                <div className='form'>
                  <form autoComplete="off" onSubmit={(e) => e.preventDefault()}>
                    <div className='row'>
                      <div className='col-12'>
                        <div className='mb-3'>
                          <h4>Kitchen Menu Information</h4>
                        </div>
                      </div>
                      <div className='col-lg-3 col-md-4 col-sm-12 col-12'>
                        <div className="mb-3">
                          <label className="form-label">Food</label>
                          <select className="form-control">
                            <option value="">Select Food</option>
                          </select>
                        </div>
                      </div>
                      <div className='col-lg-3 col-md-4 col-sm-12 col-12'>
                        <div className="mb-3">
                          <label className="form-label">Name</label>
                          <input type="text" className="form-control" />
                        </div>
                      </div>
                      <div className='col-lg-2 col-md-4 col-sm-12 col-12'>
                        <div className="mb-3">
                          <label className="form-label">Price</label>
                          <input type="number" className="form-control" />
                        </div>
                      </div>
                      <div className='col-sm-12 col-12'>
                        <div className="mb-3">
                          <label className="form-label">Long Description</label>
                          <textarea className="form-control" rows="5"></textarea>
                        </div>
                      </div>
                      <div className='col-12'>
                        <div className="mb-3">
                          <label className="form-label">Select Diets</label>
                          <br />
                          <div className="d-flex flex-wrap">
                            <div className="me-3">
                              <input
                                name="foodDiets[]"
                                type="checkbox"
                              />
                              Option Name
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className='clearfix'></div>
                      <div className='col-12 text-end'>
                        <div className="mb-3">
                          <button type='reset' className='btn btn-danger btn-md'> <i class="ri-reset-right-line"></i> Reset </button>
                          &nbsp;&nbsp;
                          <button type='submit' className='btn btn-success-app btn-md'> <i class="ri-check-fill"></i> Update </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}