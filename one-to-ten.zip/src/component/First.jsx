import { useNavigate } from 'react-router-dom';
import React from 'react'
import logo from '../assets/dv-removebg-preview.png';

const First = () => {
    const navigate = useNavigate();
    return (
        <>
            <div className='container'>
                <div className='row'>
                    <div className='col-12'>
                        <div className='Background-img'>
                            <img src="https://viveconstyle.com/wp-content/uploads/2021/01/Hope-mobile-wallpaper.jpg" alt="background" />
                        </div>
                        <div className=' text-center'>
                           <a href="/second"> <img src={logo} alt="logo" className='logo-img' /> </a> 
                        </div>
                    </div>

                </div>

            </div>
        </>
    )
}

export default First
