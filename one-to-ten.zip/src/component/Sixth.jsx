import React from 'react'

const Sixth = () => {
    return (
        <>
            <div className='container'>
                <div className='row'>
                    <div className='col-12'>
                        <div className='sixth-top'>
                           <a href="/seventh"> <h1 className='text-center sixth-head'>Categories</h1></a>
                            <i className="bi bi-chevron-left me-2 sixth-top-i"></i>
                        </div>
                    </div>

                </div>
                
                <div className='row'>
                    <div className='col-4'>
                        <div className='images-body'>
                            <img src="https://cintracks.com/wp-content/uploads/2020/10/Hygienic-Fleets.png" alt="car" />
                            <h3>Vehicle</h3>
                        </div>
                    </div>

                    <div className='col-4'>
                        <div className='images-body'>
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRcpaepb0dmqxOeQtEYl-HphWC8SKwVtMsiPwgeuv835SjXwUXffblpiew7XLqAq7s7DZM&usqp=CAU" alt="property" />
                            <h3>Property</h3>
                        </div>
                    </div>
                     
                    <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://cdn-icons-png.flaticon.com/128/5272/5272142.png" alt="handphone" />
                            <h3>Handphone</h3>
                        </div>
                    </div>
                     <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTesWGQvYL4UYK3LtksScIxXza_boz5CCySGQ&s" alt="fashion" />
                            <h3>Fashion</h3>
                        </div>
                    </div>
                     <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAeNeIwTDoIVjH5Af4F6gpnmKD8-1sP-GsDjj0as8m2sSuv4R0" alt="babies" />
                            <h3>Babies</h3>
                        </div>
                    </div>
                     <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://cdn-icons-png.freepik.com/512/13616/13616589.png" alt="Jobs" />
                            <h3>Jobs</h3>
                        </div>
                    </div>
                     <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcTjevwgwUpZ6JL2p8vKVDqo8-exwaQC0usTh-6ndBezsBXrKXmD" alt="Sport" />
                            <h3>Sport</h3>
                        </div>
                    </div>
                     <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLx89a0jw9kev9K_j-oXE7gGW3nmYlEsRteVfLDkYjBFicZbnqOi6K7XJZm5p5zMtELsQ&usqp=CAU" alt="Furniture" />
                            <h3>Furniture</h3>
                        </div>
                    </div>
                     <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMJAb2v1EMnk8SScnWPgvvHt4e6UZiWJXh6zNusYjK_SoFg6MjMTPNk4w1Bj7u_MASq_k&usqp=CAU" alt="Electronic" />
                            <h3>Electronic</h3>
                        </div>
                    </div>
                     <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBR_t8X9P5lLbrZ3hcqkNtijv_9MNpTajMrNXVeW5rD_0Hkc8s" alt="Service" />
                            <h3>Service</h3>
                        </div>
                    </div>
                     <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSrcCJYTdWok1sOFxgaAR1JdUbeDYwWoNuqm4IMnxsOcfyAvnzg" alt="books" />
                            <h3>Books</h3>
                        </div>
                    </div>
                     <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://thumbs.dreamstime.com/b/educational-gym-icon-representing-fitness-education-educational-gym-icon-351936787.jpg" alt="Hobbies" />
                            <h3>Hobbies</h3>
                        </div>
                    </div>
                     <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://www.shutterstock.com/image-illustration/pixel-art-monster-gift-wrap-260nw-2551492323.jpg" alt="Medics" />
                            <h3>Medics</h3>
                        </div>
                    </div>
                     <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcQyFYH8HRd2ylABgiT4JBD1fGvWuYO_Ve9hbzmtcxRMsHV6rdQs" alt="Cycle" />
                            <h3>Cycle</h3>
                        </div>
                    </div>
                     <div className='col-4 '>
                        <div className='images-body'>
                            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRpots5OtO3v8zeMdTok28gr4TftZCZ0MWbMxhtZTJ6yDFwD9Fy" alt="Games" />
                            <h3>Games</h3>
                        </div>
                    </div>
                </div>



            </div>
        </>
    )
}

export default Sixth
