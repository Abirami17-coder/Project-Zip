import React from 'react'

const Seventh = () => {
    return (
        <>
            <div className='container'>
                <div className='row'>
                    <div className='col-12'>
                        <div className='seventh-top'>
                            <a href="/eighth"> <h1 className='text-center seventh-head'>Location</h1></a>
                            <i className="bi bi-chevron-left me-2 seventh-top-i"></i>
                        </div>
                    </div>
                    <div className='col-12'>
                        <div className='search-box '>
                            <i className="bi bi-geo-alt-fill location-icon"></i>
                            <input
                                type="text"
                                className="form-control search-input ps-5 pe-5"
                                placeholder="Enter location"
                            />
                            <i className="bi bi-x-circle-fill close-icon"></i>
                        </div>
                    </div>
                    <div className='col-12'>
                        <div className='seventh-ic'>
                            <div className='seventh-ic-item'>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Chennai</span>
                            </div>
                            <div className='seventh-ic-item'>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Trichy</span>
                            </div>
                            <div className='seventh-ic-item'>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Madurai</span>
                            </div>
                            <div className='seventh-ic-item'>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Salem</span>
                            </div>
                            <div className='seventh-ic-item'>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Coimbatore</span>
                            </div>
                            <div className='seventh-ic-item'>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Erode</span>
                            </div>
                            <div className='seventh-ic-item'>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Thanjavur</span>
                            </div>
                            <div className='seventh-ic-item'>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Karur</span>
                            </div>
                            <div className='seventh-ic-item'>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Kanyakumari</span>
                            </div>
                        </div>
                    </div>

                </div>
                <div className='row'>
                    <div className='col-12'>
                        <div className='seventh-footer'>
                            <i className="bi bi-house-fill seventh-footer-i-home"></i>
                            <i className="bi bi-search seventh-footer-i"></i>
                             
                            <i className="bi bi-plus-circle-fill plus-icon"></i>

                            <i className="bi bi-chat-dots-fill seventh-footer-i"></i>
                            <i className="bi bi-person-fill seventh-footer-i"></i>
                        </div>
                    </div>
                </div>



            </div>

        </>
    )
}

export default Seventh
