import React from 'react'

const Eighth = () => {
    return (
        <>
            <div className='container'>
                <div className='row'>
                    <div className='col-12'>
                        <div className='eighth-top'>
                            <a href="/ninth"> <h1 className='text-center eighth-head'>Papular Item</h1></a>
                            <i className="bi bi-chevron-left me-2 eighth-top-i"></i>
                        </div>
                    </div>


                </div>

                <div className='row'>
                    <div className='col-12'>
                        <div className=' eighth-bodyleft'>
                            <p >Services</p>
                            <p>Add</p>


                        </div>
                    </div>
                    <div className='col-12'>
                        <div className=' eighth-bodyright'>
                            <i className="bi bi-three-dots-vertical"></i>
                            <i className="bi bi-list"></i>

                        </div>
                    </div>

                    <div className='col-12'>
                        <div className=' eighth-body'>

                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTvvMtBU40Wsj0127D4GAW3-QeYCEgqIOwEJjRzhY4URz2qffn3" alt="laptop" />
                            <i className="bi bi-heart wishlist-icon" ></i>
                            <div className='eighth-text'>

                                <p >Macbook Pro 14 |2016</p>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Kanyakumari</span>

                            </div>
                            <div >
                                <i className="bi bi-check-circle-fill right" >Verified</i>
                                <i className="bi bi-x-circle-fill wrong" >Urgent</i>
                                <p className='day'>3d Ago</p>
                            </div>
                        </div>
                    </div>

                    <div className='col-12'>
                        <div className=' eighth-two'>
                            <img src="https://i.ebayimg.com/images/g/mfwAAOSwMUxnMpHR/s-l1600.jpg" alt="sycle" />
                            <i className="bi bi-heart wishlist-icon-red" ></i>
                            <div className='eighth-text'>

                                <p >Macbook Pro 14 |2016</p>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Kanyakumari</span>

                            </div>
                            <div >
                                <i className="bi bi-check-circle-fill right" >Verified</i>
                                <i className="bi bi-x-circle-fill wrong" >Urgent</i>
                                <p className='day'>3d Ago</p>
                            </div>
                        </div>
                    </div>
                    <div className='col-12'>
                        <div className='eighth-three'>
                            <img src="https://img.freepik.com/premium-photo/dynamic-white-motorcyclist-precisionist-art-style_899449-502170.jpg" alt="bike" />
                            <i className="bi bi-heart wishlist-icon"></i>

                            <div className='eighth-text'>
                                <p>Macbook Pro 14 |2016</p>
                                <i className="bi bi-geo-alt-fill eighth-location"></i>
                                <span>Kanyakumari</span>

                               
                                <div className="rating-star">
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <span className='rating'>5.0</span>
                                </div>
                            </div>

                            <div>
                                <i className="bi bi-check-circle-fill right">Verified</i>
                                <i className="bi bi-x-circle-fill wrong">Urgent</i>
                                <p className='day'>3d Ago</p>
                            </div>
                        </div>
                    </div>

                    <div className='col-12'>
                        <div className=' eighth-foure'>
                            <img src="https://i.ytimg.com/vi/pwqksGfjofs/mqdefault.jpg" alt="house" />
                            <i className="bi bi-heart wishlist-icon" ></i>
                            <div className='eighth-text'>

                                <p >Macbook Pro 14 |2016</p>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Kanyakumari</span>
                                 <div className="rating-star">
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <span className='rating'>5.0</span>
                                </div>

                            </div>
                            <div >
                                <i className="bi bi-check-circle-fill right" >Verified</i>
                                <i className="bi bi-x-circle-fill wrong" >Urgent</i>
                                <p className='day'>3d Ago</p>
                            </div>
                        </div>
                    </div>
                    <div className='col-12'>
                        <div className=' eighth-five'>
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTAWtrrE4Luv8YudeUwM7JCnyIc4yFAhok8Kiv5MpT3ob3F6oP3z422visdIJfnSdOlmUM&usqp=CAU" alt="car" />
                            <i className="bi bi-heart wishlist-icon" ></i>
                            <div className='eighth-text'>

                                <p >Macbook Pro 14 |2016</p>
                                <i className="bi bi-geo-alt-fill"></i>
                                <span>Kanyakumari</span>
                                 <div className="rating-star">
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <span className='rating'>5.0</span>
                                </div>

                            </div>
                            <div >
                                <i className="bi bi-check-circle-fill right" >Verified</i>
                                <i className="bi bi-x-circle-fill wrong" >Urgent</i>
                                <p className='day'>3d Ago</p>
                            </div>
                        </div>
                    </div>

                </div>


                <div className='row'>
                    <div className='col-12'>
                        <div className='seventh-footer'>
                            <i className="bi bi-house-fill seventh-footer-i-home"></i>
                            <i className="bi bi-search seventh-footer-i"></i>

                            <i className="bi bi-plus-circle-fill plus-icon"></i>

                            <i className="bi bi-chat-dots-fill seventh-footer-i"></i>
                            <i className="bi bi-person-fill seventh-footer-i"></i>
                        </div>
                    </div>
                </div>



            </div>

        </>
    )
}

export default Eighth
