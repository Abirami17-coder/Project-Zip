import React from 'react'
import { useNavigate } from 'react-router-dom';

const Second = () => {
    const navigate = useNavigate();
    
    return (
        <>
            <div className='container'>
                <div className='row'>
                    <div className='col-12'>
                        <div >
                            <img src="https://revealmobile.com/wp-content/uploads/2020/05/Grocery-store-300x300.jpg" alt="three-photo" className='third-img'/>
                            
                        </div>
                        <div className='text-center'>
                            
                            <h1 className='second-text'>One best app for all your need</h1>
                            <p className='second-para'>Lorem ipsum dolor sit amet consectetur adipisicing elit.  Quisquam, voluptatum.</p>
                        </div>
                        <div  >
                            <button type="button" className="btn btn-primary second-btn" onClick={() => navigate("/fourth")}>Get Start</button>
                           
                        </div>
                        <div className='text-center'>
                             <p className='second-para-btn'>Lorem ipsum dolor sit amet <samp className='unique'> consectetur adipisicing </samp> elit. <samp className='unique'> Quisquam,</samp> voluptatum .</p>
                       

                        </div>


                    </div>

                </div>

            </div>
        </>
    )
}

export default Second
