import React from 'react'
import { useNavigate } from 'react-router-dom';
const Fifth = () => {
     const navigate = useNavigate();
    return (
        <>
            <div className='container'>
                <div className='row'>
                    <div className='col-12'>
                        <div>
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSJQlqikOp5iki27uaPgHZOHla7HgM5rNqZxg&s" alt="top-logo" className='fifth-top-logo' />
                        </div>
                        <div>
                            <h1 className='fifth-heading'>Hello Again!</h1>
                            <p className='fifth-para'>Lorem ipsum dolor sit amet consectetur .</p>
                        </div>

                        <form>
                            <div className='form-group-'>
                                <label htmlFor="email" className='form-control-lable'> Email or MobileNumber</label>
                                <input
                                    type="email"
                                    className='form-control email-input'
                                    id='email'
                                    placeholder='Enter Email or Mobile Number'
                                />
                                <i className="bi bi-envelope-fill email-icon"></i>
                            </div>

                            <div className='form-group'>
                                <label htmlFor="password" className='form-control-lable'>Password</label>
                                <input
                                    type="password"
                                    className='form-control password-input'
                                    id='password'
                                    placeholder='Enter Password'
                                />
                                <i className="bi bi-lock-fill password-icon"></i>
                                <div className='eye-icon'>
                                    <i className="bi bi-eye-fill toggle-eye" id="togglePassword"></i>

                                </div>
                            </div>

                            <div className='form-group pass-up'>
                                <a href="#">Forget Password?</a>
                            </div>
                            <div className='form-group btn-fifth'>
                                <button className='btn btn-primary  btn-fifth' onClick={() => navigate("/sixth")}>Login</button>
                            </div>

                            <div>
                                <p className='fith-para'>Or Continue With</p>
                            </div>


                            <div className="text-center fifth-icons">
                                <i className="bi bi-google fs-3 me-3"></i>
                                <i className="bi bi-facebook fs-3 me-3"></i>
                                <i className="bi bi-apple fs-3"></i>
                            </div>
                            <div className='text-center sign-up'>
                                <p>Don't have an account? <a href="#">Sign Up</a></p>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Fifth
