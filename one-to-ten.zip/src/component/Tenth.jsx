import React from 'react'

const Tenth = () => {
    return (
        <>
            <div className='container'>
                <div className='row'>
                    <div className='col-12'>
                        <div className='tenth-top'>


                            <div className='tenthsearch-box '>
                                <i className="bi bi-search search-icon"></i>
                                <input
                                    type="text"
                                    className="form-control search-input ps-5 pe-5"
                                    placeholder="Enter location"
                                />
                                <i className="bi bi-geo-alt-fill tenth-location-icon"></i>
                                <i className="bi bi-bell-fill tenth-noti-icon"></i>


                            </div>
                            <div className='fixed-serch'>
                                <p>bikkr <i className="bi bi-search "></i> </p>
                                <p>bikkr <i className="bi bi-search "></i> </p>
                                <p>bikkr <i className="bi bi-search "></i> </p>
                                <p>bikkr <i className="bi bi-search "></i> </p>
                            </div>
                        </div>

                    </div>

                </div>
                <div className="row">
                    <div className="col-12">
                        <div className="card slide">
                            <div className="card-body ">
                                <div className="img-box ">
                                    <img src="https://cintracks.com/wp-content/uploads/2020/10/Hygienic-Fleets.png" alt="car" />
                                    <p>Vehicle</p>
                                </div>
                                <div className="img-box ">
                                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRcpaepb0dmqxOeQtEYl-HphWC8SKwVtMsiPwgeuv835SjXwUXffblpiew7XLqAq7s7DZM&usqp=CAU" alt="property" />
                                    <p>Property</p>
                                </div>
                                <div className="img-box ">
                                    <img src="https://cdn-icons-png.flaticon.com/128/5272/5272142.png" alt="handphone" />
                                    <p>Handphone</p>
                                </div>
                                <div className="img-box">
                                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTesWGQvYL4UYK3LtksScIxXza_boz5CCySGQ&s" alt="fashion" />
                                    <p>Fashion</p>
                                </div>
                                <div className="img-box">
                                    <img src="https://cdn-icons-png.freepik.com/512/13616/13616589.png" alt="Jobs" />
                                    <p>Babies</p>
                                </div>
                                <div className="img-box">
                                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAeNeIwTDoIVjH5Af4F6gpnmKD8-1sP-GsDjj0as8m2sSuv4R0" alt="babies" />
                                    <p>Jobs</p>
                                </div>
                                <div className="img-box">
                                    <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcTjevwgwUpZ6JL2p8vKVDqo8-exwaQC0usTh-6ndBezsBXrKXmD" alt="Sport" />
                                    <p>Sport</p>
                                </div>
                                <div className="img-box">

                                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLx89a0jw9kev9K_j-oXE7gGW3nmYlEsRteVfLDkYjBFicZbnqOi6K7XJZm5p5zMtELsQ&usqp=CAU" alt="Furniture" />
                                    <p>Furniture</p>
                                </div>
                                <div className="img-box">
                                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMJAb2v1EMnk8SScnWPgvvHt4e6UZiWJXh6zNusYjK_SoFg6MjMTPNk4w1Bj7u_MASq_k&usqp=CAU" alt="Electronic" />
                                    <p>Electroni</p>
                                </div>
                                <div className="img-box">
                                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBR_t8X9P5lLbrZ3hcqkNtijv_9MNpTajMrNXVeW5rD_0Hkc8s" alt="Service" />
                                    <p>Service</p>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>

                <div className='row'>
                     <div className='col-12'>
                        <p className='tenth-heading'>free photo</p>

                     </div>
                    <div className='col-6'>

                        <div className='card tenth-one'>
                            <img src="https://img.freepik.com/premium-photo/dynamic-white-motorcyclist-precisionist-art-style_899449-502170.jpg" className='card-img-top' alt="house" />
                            <div className='card-body'>
                                <h5 className='card-title'>acbook Pro 14 |2016</h5>
                                <i className="bi bi-heart tenth-like"></i>
                                <div className='tenth-stars'>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <span className='rating'>5.0</span>
                                </div>
                                <div >
                                    <i className="bi bi-geo-alt-fill tenth-loc"></i>
                                    <span>Kanyakumari</span>
                                </div>

                                <i className="bi bi-check-circle-fill tenth-loc ">Verified </i>
                                <span>3d Ago</span>


                            </div>

                        </div>
                    </div>
                    <div className='col-6'>
                        <div className='card tenth-one'>
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTvvMtBU40Wsj0127D4GAW3-QeYCEgqIOwEJjRzhY4URz2qffn3" className='card-img-top' alt="laptop" />
                            <div className='card-body'>
                                <h5 className='card-title'>acbook Pro 14 |2016</h5>
                                <i className="bi bi-heart tenth-like"></i>
                                <div className='tenth-stars'>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <span className='rating'>5.0</span>
                                </div>
                                <div >
                                    <i className="bi bi-geo-alt-fill tenth-loc"></i>
                                    <span>Kanyakumari</span>
                                </div>

                                <i className="bi bi-check-circle-fill tenth-loc ">Verified </i>
                                <span>3d Ago</span>


                            </div>

                        </div>
                    </div>

                    <div className='col-6'>
                        <div className='card tenth-one'>
                            <img src="https://i.ebayimg.com/images/g/mfwAAOSwMUxnMpHR/s-l1600.jpg" className='card-img-top' alt="sycle" />
                            <div className='card-body'>
                                <h5 className='card-title'>acbook Pro 14 |2016</h5>
                                <i className="bi bi-heart tenth-like"></i>
                                <div className='tenth-stars'>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <span className='rating'>5.0</span>
                                </div>
                                <div >
                                    <i className="bi bi-geo-alt-fill tenth-loc"></i>
                                    <span>Kanyakumari</span>
                                </div>

                                <i className="bi bi-check-circle-fill tenth-loc ">Verified </i>
                                <span>3d Ago</span>


                            </div>

                        </div>
                    </div>
                    <div className='col-6'>
                        <div className='card tenth-one'>
                            <img src="https://i.ytimg.com/vi/pwqksGfjofs/mqdefault.jpg" className='card-img-top' alt="bike" />
                            <div className='card-body'>
                                <h5 className='card-title'>acbook Pro 14 |2016</h5>
                                <i className="bi bi-heart tenth-like"></i>
                                <div className='tenth-stars'>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <i className="bi bi-star-fill "></i>
                                    <span className='rating'>5.0</span>
                                </div>
                                <div >
                                    <i className="bi bi-geo-alt-fill tenth-loc"></i>
                                    <span>Kanyakumari</span>
                                </div>

                                <i className="bi bi-check-circle-fill tenth-loc ">Verified </i>
                                <span>3d Ago</span>


                            </div>

                        </div>
                    </div>
                </div>





                <div className='row'>
                    <div className='col-12'>
                        <div className='seventh-footer'>
                            <i className="bi bi-house-fill seventh-footer-i-home"></i>
                            <i className="bi bi-search seventh-footer-i"></i>

                            <i className="bi bi-plus-circle-fill plus-icon"></i>

                            <i className="bi bi-chat-dots-fill seventh-footer-i"></i>
                            <i className="bi bi-person-fill seventh-footer-i"></i>
                        </div>
                    </div>
                </div>



            </div>

        </>

    )
}

export default Tenth
