import React from 'react'
import { useNavigate } from 'react-router-dom';

const Second = () => {
    const navigate = useNavigate();

    return (
        <>


            <div className='container'>
                <div className='row'>
                    <div className='col-12'>
                        <div>
                            <img src="https://imgd.aeplcdn.com/642x336/ec/10057/img/m/BMW-3-Series-Front-view-15675_l.jpg?t=145536723&t=145536723&art=1&q=80" alt="top-img" className='top-img' />
                        </div>
                    </div>
                </div>

                <div className='row'>
                    <div className='col-12'>

                        <div  >
                            <img src="https://go4customer.com/img/update-images/Customer-Interactivity-Graphics-4.jpg" alt="fourth-photo" className='fourth-img' />

                        </div>

                        <div className='text-center'>

                            <h1 className='second-text-fourth'>Your test drive is confirmed!</h1>
                            <p className='second-para-fourth'>Lorem ipsum dolor sit amet consectetur adipisicing elit.  Quisquam, voluptatum.</p>
                        </div>
                        <div  >
                            <button type="button" className="btn btn-primary fourth-btn" onClick={() => navigate("/fifth")}>View booking details</button>

                        </div>


                    </div>

                </div>

            </div>


        </>
    )
}

export default Second
