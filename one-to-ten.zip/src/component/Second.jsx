import React from 'react'
import { useNavigate } from 'react-router-dom';

const Second = () => {
    const navigate = useNavigate();
    
    return (
        <>
            <div className='container'>
                <div className='row'>
                    <div className='col-12'>
                        <div >
                            <img src="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcRDq31mPDWjm5qAHB0j3k0N-nuBuQ9IJZKnuVIY5AaL_r2cVLc-" alt="second-photo" className='second-img'/>
                            
                        </div>
                        <div className='text-center'>
                            
                            <h1 className='second-text'>Everything you need all in one app</h1>
                            <p className='second-para'>Lorem ipsum dolor sit amet consectetur adipisicing elit.  Quisquam, voluptatum.</p>
                        </div>
                        <div  >
                            <button type="button" className="btn btn-primary second-btn" onClick={() => navigate("/three")}>Get Start</button>
                           
                        </div>
                        <div className='text-center'>
                             <p className='second-para-btn'>Lorem ipsum dolor sit amet <samp className='unique'> consectetur adipisicing </samp> elit. <samp className='unique'> Quisquam,</samp> voluptatum .</p>
                       

                        </div>


                    </div>

                </div>

            </div>
        </>
    )
}

export default Second
