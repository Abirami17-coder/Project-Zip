import React from 'react'

import { BrowserRouter ,Routes, Route  } from 'react-router-dom'
import Second from './component/Second.jsx'
import First from './component/First.jsx'
import Three from './component/Three.jsx'
import './App.css'
import Fourth from './component/Fourth.jsx'
import Fifth from './component/Fifth.jsx'
import Sixth from './component/Sixth.jsx'
import Seventh from './component/Seventh.jsx'
import Eighth from './component/Eighth.jsx'
import Ninth from './component/Ninth.jsx'
import Tenth from './component/Tenth.jsx'

const App = () => {
  return (
    <div>
      
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<First />} />
          <Route path="/second" element={<Second />} />
          <Route path="/three" element={<Three />} />
          <Route path="/fourth" element={<Fourth />} />
          <Route path="/fifth" element={<Fifth />} />
          <Route path="/sixth" element={<Sixth />} />
          <Route path="/seventh" element={<Seventh />} />
          <Route path="/eighth" element={<Eighth />} />
          <Route path="/ninth" element={<Ninth />} />
          <Route path="/tenth" element={<Tenth />} />
        </Routes>
      </BrowserRouter>

    </div>
  )
}

export default App
