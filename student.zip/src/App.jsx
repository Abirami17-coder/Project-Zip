import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import StudentTable from './components/StudentTable'
import ViewDetails from './components/ViewDetails'
import EditStudent from './components/EditStudent'
import CreateStudent from './components/CreateStudent'

import './App.css'
const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={< StudentTable />} />
        <Route path='/view/:studentid' element={<ViewDetails />} />
        <Route path='/edit/:studentid' element={<EditStudent />} />
        <Route path='/create' element={<CreateStudent />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
