import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react'
import React, { use } from 'react'
import { Link } from 'react-router-dom'

const StudentTable = () => {
  const [students, setStudents] = useState("");
  const navigate = useNavigate();

  const DisplayDetails = (id) => {
    navigate("/view/" + id);
  };
  const EditDetails = (id) => {
    navigate("/edit/" + id);
  };
  const RemoveDetails = (id) => {
    if (window.confirm("Are you sure you want to delete this student?")) {
       fetch("http://localhost:8000/students/"+id,{
    method:"DELETE",
   
  })

    .then((res)=>{
      alert("Remove Student Successfully");
      window.location.reload();

    })
    .catch((err)=>console.log(err.message)
  
)
    }
  };


  useEffect(() => {
    fetch('http://localhost:8000/students')
      .then((res) => res.json())
      .then((data) =>
        setStudents(data)).catch((err) =>
          console.log(err.message))

  }, [])
  return (

    <>
      <div className='container'>
        <div className='col-12 '>
          <div className='table '>
            <h1>Student Records</h1>
            <div className='table-container'>
              <Link to={'/create'} className='btn btn-add'>Add New Student</Link>

              <table className="student-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Place</th>
                    <th>Phone</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody className='table-body'>
                  {
                    students && students.map((item,index) => (
                      <tr key={item.id}>
                        <td>{index+1}</td>
                        <td>{item.name}</td>
                        <td>{item.place}</td>
                        <td>{item.phone}</td>
                        <td>
                          <button onClick={() => EditDetails(item.id)} className="btn btn-edit">Edit</button>
                          <button onClick={() => RemoveDetails(item.id)} className="btn btn-delete">Delete</button>
                          <button onClick={() => DisplayDetails(item.id)} className="btn btn-view">View</button>
                        </td>
                      </tr>
                    )
                    )
                  }


                </tbody>
              </table>


            </div>

          </div>


        </div>

      </div>
    </>
  )
}

export default StudentTable