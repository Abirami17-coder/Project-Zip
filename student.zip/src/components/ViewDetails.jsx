import { useState } from 'react';
import { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom'


const ViewDetails = () => {
  const {studentid}=useParams();
  const [studentData,setStudentData]=useState({});
  
  useEffect(()=>{
    fetch("http://localhost:8000/students/"+studentid)
    .then((res)=>res.json())
    .then((data)=>setStudentData(data))
    .catch((err)=>console.log(err.message))
  },[]);
  
  
  return (
   <>
   <div className='container'>
    <div className='row'>
      <div className='col-12'>
        <div className='table'>
          <h1>View Student Details</h1>
          { studentData && 
          <div className='view-details'>
          
            <p><strong>ID :</strong>{studentData.id}</p>
            <p><strong> Name :</strong>{studentData.name}</p>
            <p><strong>Place :</strong>{studentData.place}</p>
            <p><strong>phone :</strong>{studentData.phone}</p>
               <Link to="/" className='btn btn-back btn-details'>Back</Link>
          </div>
          }
          
          
        </div>
      </div>
    </div>

   </div>
   </>
  )
}

export default ViewDetails