import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';

/**
 * Generates a W-PIN (8 or more characters) using cryptographically secure methods when available,
 * falling back to Math.random() with a warning.
 */
const generateWpin = (minLength = 8, characterSet) => {
  const defaultCharacterSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const characters = characterSet || defaultCharacterSet;
  let wpin = '';

  if (typeof window !== 'undefined' && window.crypto?.getRandomValues) {
    const randomValues = new Uint32Array(minLength);
    window.crypto.getRandomValues(randomValues);
    for (let i = 0; i < minLength; i++) {
      wpin += characters[randomValues[i] % characters.length];
    }
  } else {
    for (let i = 0; i < minLength; i++) {
      wpin += characters[Math.floor(Math.random() * characters.length)];
    }
  }

  return wpin;
};

const AddMember = () => {
  const [formData, setFormData] = useState({
    name: '',
    gender: '',
    bloodGroup: '',
    email: '',
    mobile: '',
    whatsapp: '',
    address: '',
    landmark: '',
    pincode: '',
    city: '',
    password: '',
    confirmPassword: '',
    epin: '',
    referName: 'John Doe',
    referMobile: '9876543210',
    wpin: generateWpin(),
  });

  const [errors, setErrors] = useState({});
  const [epinVerified, setEpinVerified] = useState(false);

  const cities = ['Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata'];
  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const e = {};
    if (formData.name.trim().length < 3) e.name = "Minimum 3 characters";
    if (!formData.gender) e.gender = "Select gender";
    if (!formData.bloodGroup) e.bloodGroup = "Select blood group";
    if (!/^\S+@\S+\.\S+$/.test(formData.email)) e.email = "Invalid email";
    if (!/^\d{10}$/.test(formData.mobile)) e.mobile = "Must be 10 digits";
    if (!/^\d{10}$/.test(formData.whatsapp)) e.whatsapp = "Must be 10 digits";
    if (formData.address.trim().length < 10) e.address = "Minimum 10 characters";
    if (!/^\d{6}$/.test(formData.pincode)) e.pincode = "Must be 6 digits";
    if (!formData.city) e.city = "Select city";
    if (formData.password.length < 5 || formData.password.length > 10)
      e.password = "5-10 characters required";
    if (formData.password !== formData.confirmPassword)
      e.confirmPassword = "Passwords do not match";
    if (!/^[A-Za-z0-9]{6}$/.test(formData.epin)) e.epin = "EPIN must be 6 characters";

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      console.log('Submitted:', formData);
      alert("Form submitted successfully!");
    }
  };

  const handleVerifyEpin = () => {
    if (/^[A-Za-z0-9]{6}$/.test(formData.epin)) {
      setEpinVerified(true);
      alert("EPIN Verified");
    } else {
      setEpinVerified(false);
      alert("Invalid EPIN");
    }
  };

  const handleReset = () => {
    setFormData({
      name: '',
      gender: '',
      bloodGroup: '',
      email: '',
      mobile: '',
      whatsapp: '',
      address: '',
      landmark: '',
      pincode: '',
      city: '',
      password: '',
      confirmPassword: '',
      epin: '',
      referName: 'John Doe',
      referMobile: '9876543210',
      wpin: generateWpin(),
    });
    setErrors({});
    setEpinVerified(false);
  };

  return (
    <>
      <Helmet>
        <title>Add New Member</title>
      </Helmet>

      <div className="container">
        <div className="page">
          <div className="page-heading">
            <h1>Add Member</h1>
            <span>
              <Link to="/">Dashboard</Link> / <Link to="/kitchen/list">Add New Member</Link>
            </span>
          </div>

          <div className="page-content">
            <div className="portal">
              <div className="portal-body">
                <form onSubmit={handleSubmit} className="form">
                  <div className="row">
                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Name <span style={{ color: 'red' }}>*</span></label>
                      <input className="form-control" name="name" value={formData.name} onChange={handleChange} />
                      <div className="error" style={{ color: 'red' }}>{errors.name}</div>
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Gender <span style={{ color: 'red' }}>*</span></label>
                      <div>
                        <input type="radio" name="gender" value="Male" onChange={handleChange} /> Male  &nbsp;
                        <input type="radio" name="gender" value="Female" onChange={handleChange} /> Female  &nbsp;
                        <input type="radio" name="gender" value="Other" onChange={handleChange} /> Other  
                      </div>
                      <div className="error" style={{ color: 'red' }}>{errors.gender}</div>
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Blood Group <span style={{ color: 'red' }}>*</span></label>
                      <select className="form-control" name="bloodGroup" value={formData.bloodGroup} onChange={handleChange}>
                        <option value="">Select</option>
                        {bloodGroups.map(bg => <option key={bg} value={bg}>{bg}</option>)}
                      </select>
                      <div className="error" style={{ color: 'red' }}>{errors.bloodGroup}</div>
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Email <span style={{ color: 'red' }}>*</span></label>
                      <input className="form-control" name="email" value={formData.email} onChange={handleChange} />
                      <div className="error" style={{ color: 'red' }}>{errors.email}</div>
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Mobile <span style={{ color: 'red' }}>*</span></label>
                      <input className="form-control" name="mobile" value={formData.mobile} onChange={handleChange} />
                      <div className="error" style={{ color: 'red' }}>{errors.mobile}</div>
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Whatsapp <span style={{ color: 'red' }}>*</span></label>
                      <input className="form-control" name="whatsapp" value={formData.whatsapp} onChange={handleChange} />
                      <div className="error" style={{ color: 'red' }}>{errors.whatsapp}</div>
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Address <span style={{ color: 'red' }}>*</span></label>
                      <textarea className="form-control" name="address" value={formData.address} onChange={handleChange}></textarea>
                      <div className="error" style={{ color: 'red' }}>{errors.address}</div>
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Landmark</label>
                      <input className="form-control" name="landmark" value={formData.landmark} onChange={handleChange} />
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Pincode <span style={{ color: 'red' }}>*</span></label>
                      <input className="form-control" name="pincode" value={formData.pincode} onChange={handleChange} />
                      <div className="error" style={{ color: 'red' }}>{errors.pincode}</div>
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>City <span style={{ color: 'red' }}>*</span></label>
                      <select className="form-control" name="city" value={formData.city} onChange={handleChange}>
                        <option value="">Select</option>
                        {cities.map(city => <option key={city} value={city}>{city}</option>)}
                      </select>
                      <div className="error" style={{ color: 'red' }}>{errors.city}</div>
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Password <span style={{ color: 'red' }}>*</span></label>
                      <input className="form-control" type="password" name="password" value={formData.password} onChange={handleChange} />
                      <div className="error" style={{ color: 'red' }}>{errors.password}</div>
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Re-type Password <span style={{ color: 'red' }}>*</span></label>
                      <input className="form-control" type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} />
                      <div className="error" style={{ color: 'red' }}>{errors.confirmPassword}</div>
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>EPIN <span style={{ color: 'red' }}>*</span></label>
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <input className="form-control" name="epin" value={formData.epin} onChange={handleChange} />
                        <button type="button" className="btn btn-primary">
                          Verify
                        </button>
                      </div>
                      <div className="error" style={{ color: 'red' }}>{errors.epin}</div>
                      {epinVerified && <div className="text-success">EPIN Verified</div>}
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Refer Member Name</label>
                      <input className="form-control" value={formData.referName} readOnly />
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Refer Member Mobile</label>
                      <input className="form-control" value={formData.referMobile} readOnly />
                    </div>

                    <div className="col-12 text-end">
  <div className="mb-3 d-flex gap-2 align-items-center justify-content-end">
    <button
      type="reset"
      className="btn btn-danger same-height"
      onClick={() =>
        setFormData({
          name: "",
          image: null,
        })
      }
      style={{ height: '40px' }} // Ensuring button height consistency
    >
      <i className="ri-reset-right-line"></i> Reset
    </button>
  <button type="submit" className="btn btn-success">
                            
      <i className="ri-check-fill"></i> Add Member
    </button>
  </div>
</div>


                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddMember;
