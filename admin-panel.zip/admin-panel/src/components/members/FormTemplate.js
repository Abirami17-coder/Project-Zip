import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';

/**
 * Generates a W-PIN (8 or more characters) using cryptographically secure methods when available,
 * falling back to Math.random() with a warning.
 * @param {number} minLength - The minimum length of the W-PIN (default: 8)
 * @param {string} characterSet - The set of characters to use (optional)
 * @returns {string} - The generated W-PIN
 */
const generateWpin = (minLength = 8, characterSet) => {
  // Input validation: Check for valid minimum length
  if (typeof minLength !== 'number' || minLength < 8 || !Number.isInteger(minLength)) {
    console.error("Error: Minimum length must be a number greater than or equal to 8.");
    return ""; // Return empty string to indicate an error
  }

  // Input validation: Check for valid character set
  if (characterSet && typeof characterSet !== 'string') {
    console.error("Error: Character set must be a string.");
    return ""; // Return empty string to indicate an error
  }

  const defaultCharacterSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const characters = characterSet || defaultCharacterSet;
  let wpin = '';

  // Use window.crypto for cryptographically secure random number generation if available
  if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
    const randomValues = new Uint32Array(minLength);
    window.crypto.getRandomValues(randomValues);

    for (let i = 0; i < minLength; i++) {
      const index = randomValues[i] % characters.length;
      wpin += characters.charAt(index);
    }
  } else {
    // Fallback for environments without window.crypto
    console.warn("Warning: Using Math.random() for W-PIN generation. This is NOT cryptographically secure!");
    for (let i = 0; i < minLength; i++) {
      const index = Math.floor(Math.random() * characters.length);
      wpin += characters.charAt(index);
    }
  }
  return wpin;
};

const AddNewMemberForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    dob: '',
    gender: '',
    city: '',
    password: '',
    wpin: generateWpin(), // Initialize with a generated W-PIN
  });
  const [nameError, setNameError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const cities = ['Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata']; // Example cities

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    // Real-time validation for specific fields
    if (name === 'name') {
      if (!value.trim()) {
        setNameError('Name is required.');
      } else if (!/^[a-zA-Z\s]+$/.test(value)) {
        setNameError('Name can only contain letters and spaces.');
      } else {
        setNameError('');
      }
    } else if (name === 'password') {
      // Password validation rules
      const minLength = value.length >= 8;
      const hasNumber = /\d/.test(value);
      const hasSpecialChar = /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(value);

      if (!minLength) {
        setPasswordError('Password must be at least 8 characters long.');
      } else if (!hasNumber) {
        setPasswordError('Password must contain at least one number.');
      } else if (!hasSpecialChar) {
        setPasswordError('Password must contain at least one special character.');
      } else {
        setPasswordError('');
      }
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let hasErrors = false;

    // Final validation before submission
    if (!formData.name.trim()) {
      setNameError('Name is required.');
      hasErrors = true;
    } else if (!/^[a-zA-Z\s]+$/.test(formData.name)) {
      setNameError('Name can only contain letters and spaces.');
      hasErrors = true;
    } else {
      setNameError('');
    }

    const { password } = formData;
    const minLength = password.length >= 8;
    const hasNumber = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(password);

    if (!minLength) {
      setPasswordError('Password must be at least 8 characters long.');
      hasErrors = true;
    } else if (!hasNumber) {
      setPasswordError('Password must contain at least one number.');
      hasErrors = true;
    } else if (!hasSpecialChar) {
      setPasswordError('Password must contain at least one special character.');
      hasErrors = true;
    } else {
      setPasswordError('');
    }

    if (!hasErrors) {
      // In a real application, you would handle form submission here,
      // such as sending the data to an API.
      console.log('Form Data Submitted:', formData);
      // Optionally reset the form after successful submission
      setFormData({
        name: '',
        dob: '',
        gender: '',
        city: '',
        password: '',
        wpin: generateWpin(),
      });
    }
  };

  const handleGenerateNewWpin = () => {
    setFormData({
      ...formData,
      wpin: generateWpin(),
    });
  };

  return (
    <>
      <Helmet>
        <title>Add New Member - Your App</title>
      </Helmet>
      <div className='container'>
        <div className='page'>
          <div className='page-heading'>
            <h1>Add Member</h1>
            <span>
              <Link to="/"> Dashboard </Link> / <Link to="/kitchen/list"> Add New Member </Link>
            </span>
          </div>
          <div className='page-content'>
            <div className="portal">
              <div className='portal-body'>
                <div className='form'>
                  <form onSubmit={handleSubmit}>
                    <div className='row'>
                      <div className='col-12'>
                        <div className='mb-3'>
                          <h4></h4>
                        </div>
                      </div>

                      <div className='col-lg-4 col-md-4 col-sm-12 col-12'>
                        <div className={`mb-3 ${nameError && 'has-error'}`}>
                          <label className="form-label">Name:</label>
                          <input
                            type="text"
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            required
                            className="form-control"
                          />
                          {nameError && <div className="error-message text-danger">{nameError}</div>}
                        </div>
                      </div>
                      <div className='col-lg-4 col-md-4 col-sm-12 col-12'>
                        <div className="mb-3">
                          <label className="form-label">Date of Birth:</label>
                          <input
                            type="date"
                            id="dob"
                            name="dob"
                            value={formData.dob}
                            onChange={handleInputChange}
                            required
                            className="form-control"
                          />
                        </div>
                      </div>
                      <div className='col-lg-4 col-sm-12 col-12'>
                        <label className="form-label">Gender:</label>
                        <div className="mb-3">
                          <label className="me-2">
                            <input
                              type="radio"
                              name="gender"
                              value="male"
                              checked={formData.gender === 'male'}
                              onChange={handleInputChange}
                              required
                              className='me-1'
                            />
                            Male
                          </label>
                          <label className="me-2">
                            <input
                              type="radio"
                              name="gender"
                              value="female"
                              checked={formData.gender === 'female'}
                              onChange={handleInputChange}
                              required
                              className="me-1"
                            />
                            Female
                          </label>
                          <label>
                            <input
                              type="radio"
                              name="gender"
                              value="other"
                              checked={formData.gender === 'other'}
                              onChange={handleInputChange}
                              required
                              className="me-1"
                            />
                            Other
                          </label>
                        </div>
                      </div>

                      <div className='col-lg-4 col-sm-12 col-12'>
                        <div className="mb-3">
                          <label className="form-label">City:</label>
                          <select
                            id="city"
                            name="city"
                            value={formData.city}
                            onChange={handleInputChange}
                            required
                            className="form-control"
                          >
                            <option value="">Select City</option>
                            {cities.map((city) => (
                              <option key={city} value={city}>
                                {city}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                      <div className='col-lg-4 col-md-4 col-sm-12 col-12'>
                        <div className={`mb-3 ${passwordError && 'has-error'}`}>
                          <label className="form-label">Password:</label>
                          <input
                            type="password"
                            id="password"
                            name="password"
                            value={formData.password}
                            onChange={handleInputChange}
                            required
                            className="form-control"
                          />
                          {passwordError && <div className="error-message text-danger">{passwordError}</div>}
                        </div>
                      </div>
                      <div className='col-lg-4 col-md-4 col-sm-12 col-12'>
                        <div className="mb-3">
                          <label className="form-label">W-PIN:</label>
                          <div className="input-group">
                            <input
                              type="text"
                              id="wpin"
                              name="wpin"
                              value={formData.wpin}
                              placeholder='Generated W-PIN'
                              required
                              readOnly
                              className="form-control"
                            />
                            <button
                              type="button"
                              onClick={handleGenerateNewWpin}
                              className="btn btn-primary d-flex align-items-center gap-1 right-rounded"
                            >
                              <i className="ri-key-fill"></i>
                              <span className="fw-bold"></span>
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className='clearfix'></div>
                      <div className='col-12 text-end'>
                        <div className="mb-3 d-flex gap-2 align-items-center justify-content-end">
                            <button type='reset' className='btn btn-danger same-height'> <i className="ri-reset-right-line"></i> Reset </button>
                            <button type='submit' className='btn btn-success-app same-height py-1'> <i className="ri-check-fill"></i> Add Member </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddNewMemberForm;