// src/MemberPasswordUpdate.js

import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';

const MemberPasswordUpdate = () => {
  const [formData, setFormData] = useState({
    password: '',
    confirmPassword: '',
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const e = {};
    if (formData.password.length < 6) e.password = 'Password must be at least 6 characters';
    if (formData.password !== formData.confirmPassword) e.confirmPassword = 'Passwords do not match';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      console.log('Password updated:', formData);
      alert('Password updated successfully!');
    }
  };

  const handleReset = () => {
    setFormData({
      password: '',
      confirmPassword: '',
    });
    setErrors({});
  };

  return (
    <>
      <Helmet>
        <title>Update Password - Your App</title>
      </Helmet>

      <div className="container">
        <div className="page">
          <div className="page-heading">
            <h1>Update Password</h1>
            <span>
              <Link to="/">Dashboard</Link> / <Link to="/members">Update Password</Link>
            </span>
          </div>

          <div className="page-content">
            <div className="portal">
              <div className="portal-body">
                <form onSubmit={handleSubmit}>
                  <div className="row">

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Password <span style={{ color: 'red' }}>*</span></label>
                      <input
                        type="password"
                        className="form-control"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                      />
                      <div style={{ color: 'red' }}>{errors.password}</div>
                    </div>

                    <div className="col-lg-4 col-sm-12 mb-3">
                      <label>Re-type Password <span style={{ color: 'red' }}>*</span></label>
                      <input
                        type="password"
                        className="form-control"
                        name="confirmPassword"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                      />
                      <div style={{ color: 'red' }}>{errors.confirmPassword}</div>
                    </div>

                    <div className="col-12 text-end">
                      <div className="mb-3 d-flex gap-2 align-items-center justify-content-end">
                        <button type="reset" className="btn btn-danger same-height" style={{ height: '40px' }} onClick={handleReset}>
                          <i className="ri-refresh-line"></i> Reset
                        </button>
                        <button type="submit" className="btn btn-success">
                            
                        <i className="ri-check-fill"></i> Update Password
                        </button>
                      </div>
                    </div>

                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default MemberPasswordUpdate;
