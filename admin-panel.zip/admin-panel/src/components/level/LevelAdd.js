import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";

export default function LevelAdd() {
  const [formData, setFormData] = useState({
    name: "",
    sequenceNumber: "",
    referCount: "",
    gift: "",
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const validate = () => {
    const newErrors = {};

    // Name: minimum 4 characters, only letters and spaces
    if (formData.name.trim().length < 4) {
      newErrors.name = "Name must be at least 4 characters long.";
    } else if (!/^[a-zA-Z\s]+$/.test(formData.name)) {
      newErrors.name = "Name must contain only letters and spaces.";
    }

    // Sequence Number: must be a positive number
    if (!/^\d+$/.test(formData.sequenceNumber) || parseInt(formData.sequenceNumber) < 1) {
      newErrors.sequenceNumber = "Sequence Number must be a number greater than 0.";
    }

    // Refer Count: must be a non-negative number
    if (!/^\d+$/.test(formData.referCount) || parseInt(formData.referCount) < 0) {
      newErrors.referCount = "Refer Count must be a number 0 or higher.";
    }

    // Gift: required
    if (!formData.gift) {
      newErrors.gift = "Please select a gift.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      console.log("Form submitted:", formData);
      alert("Form submitted successfully!");
      // Reset form
      setFormData({
        name: "",
        sequenceNumber: "",
        referCount: "",
        gift: "",
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>Form Template</title>
      </Helmet>
      <div className="container">
        <div className="page">
          <div className="page-heading">
            <h1>Level Add</h1>
            <span>
              <Link to="/"> Dashboard </Link> / <Link to="/kitchen/list">Level Add</Link>
            </span>
          </div>
          <div className="page-content">
            <div className="portal">
              <div className="portal-body">
                <div className="form">
                  <form autoComplete="off" onSubmit={handleSubmit}>
                    <div className="row">
                      {/* Name */}
                      <div className="mb-3 col-lg-5 col-md-6 col-sm-12">
                        <label htmlFor="name" className="form-label">Name *</label>
                        <input
                          type="text"
                          id="name"
                          className="form-control"
                          value={formData.name}
                          onChange={handleChange}
                        />
                        {errors.name && <small className="text-danger">{errors.name}</small>}
                      </div>

                      {/* Sequence Number */}
                      <div className="mb-3 col-lg-5 col-md-6 col-sm-12">
                        <label htmlFor="sequenceNumber" className="form-label">Sequence Number *</label>
                        <input
                          type="number"
                          id="sequenceNumber"
                          className="form-control"
                          value={formData.sequenceNumber}
                          onChange={handleChange}
                        />
                        {errors.sequenceNumber && <small className="text-danger">{errors.sequenceNumber}</small>}
                      </div>

                      {/* Refer Count */}
                      <div className="mb-3 col-lg-5 col-md-6 col-sm-12">
                        <label htmlFor="referCount" className="form-label">Refer Count *</label>
                        <input
                          type="number"
                          id="referCount"
                          className="form-control"
                          value={formData.referCount}
                          onChange={handleChange}
                        />
                        {errors.referCount && <small className="text-danger">{errors.referCount}</small>}
                      </div>

                      {/* Gift */}
                      <div className="mb-3 col-lg-5 col-md-6 col-sm-12">
                        <label htmlFor="gift" className="form-label">Gift *</label>
                        <select
                          id="gift"
                          className="form-select"
                          value={formData.gift}
                          onChange={handleChange}
                        >
                          <option value="">-- Select Gift --</option>
                          <option value="Pen">Gift1</option>
                          <option value="Notebook">Gift2</option>
                          <option value="Bag">Gift3</option>
                        </select>
                        {errors.gift && <small className="text-danger">{errors.gift}</small>}
                      </div>

                      {/* Buttons */}
                      <div className="col-12 text-end">
                        <div className="mb-3">
                          <button
                            type="reset"
                            className="btn btn-danger btn-md"
                            onClick={() => setFormData({ name: "", sequenceNumber: "", referCount: "", gift: "" })}
                          >
                            <i className="ri-reset-right-line"></i> Reset
                          </button>
                          &nbsp;&nbsp;
                          <button type="submit" className="btn btn-success">
                            <i className="ri-check-fill"></i> Add Epin
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
