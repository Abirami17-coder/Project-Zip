import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";

export default function LevelEdit() {
  const [formData, setFormData] = useState({
    name: "",
    sequenceNumber: "",
    referCount: "",
    gift: "",
    status: "",
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { id, value, name } = e.target;
    setFormData((prev) => ({ ...prev, [name || id]: value }));
  };

  const validate = () => {
    const newErrors = {};

    // Name validation
    if (formData.name.trim().length < 4) {
      newErrors.name = "Name must be at least 4 characters long.";
    } else if (!/^[a-zA-Z\s]+$/.test(formData.name)) {
      newErrors.name = "Name must contain only letters and spaces.";
    }

    // Sequence Number validation
    if (!/^\d+$/.test(formData.sequenceNumber) || parseInt(formData.sequenceNumber) < 1) {
      newErrors.sequenceNumber = "Sequence Number must be a number greater than 0.";
    }

    // Refer Count validation
    if (!/^\d+$/.test(formData.referCount) || parseInt(formData.referCount) < 0) {
      newErrors.referCount = "Refer Count must be a number 0 or higher.";
    }

    // Gift validation
    if (!formData.gift) {
      newErrors.gift = "Please select a gift.";
    }

    // Status validation
    if (!formData.status) {
      newErrors.status = "Please select a status.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      console.log("Form submitted:", formData);
      alert("Form submitted successfully!");
      setFormData({
        name: "",
        sequenceNumber: "",
        referCount: "",
        gift: "",
        status: "",
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>Form Template</title>
      </Helmet>
      <div className="container">
        <div className="page">
          <div className="page-heading">
            <h1>Level Edit</h1>
            <span>
              <Link to="/"> Dashboard </Link> / <Link to="/kitchen/list">Level Edit</Link>
            </span>
          </div>
          <div className="page-content">
            <div className="portal">
              <div className="portal-body">
                <div className="form">
                  <form autoComplete="off" onSubmit={handleSubmit}>
                    <div className="row">
                      {/* Name */}
                      <div className="mb-3 col-lg-5 col-md-6 col-sm-12">
                        <label htmlFor="name" className="form-label">Name *</label>
                        <input type="text" id="name" className="form-control" value={formData.name} onChange={handleChange} />
                        {errors.name && <small className="text-danger">{errors.name}</small>}
                      </div>

                      {/* Sequence Number */}
                      <div className="mb-3 col-lg-5 col-md-6 col-sm-12">
                        <label htmlFor="sequenceNumber" className="form-label">Sequence Number *</label>
                        <input type="number" id="sequenceNumber" className="form-control" value={formData.sequenceNumber} onChange={handleChange} />
                        {errors.sequenceNumber && <small className="text-danger">{errors.sequenceNumber}</small>}
                      </div>

                      {/* Refer Count */}
                      <div className="mb-3 col-lg-5 col-md-6 col-sm-12">
                        <label htmlFor="referCount" className="form-label">Refer Count *</label>
                        <input type="number" id="referCount" className="form-control" value={formData.referCount} onChange={handleChange} />
                        {errors.referCount && <small className="text-danger">{errors.referCount}</small>}
                      </div>

                      {/* Gift */}
                      <div className="mb-3 col-lg-5 col-md-6 col-sm-12">
                        <label htmlFor="gift" className="form-label">Gift *</label>
                        <select id="gift" className="form-select" value={formData.gift} onChange={handleChange}>
                          <option value="">-- Select Gift --</option>
                          <option value="Pen">Gift1</option>
                          <option value="Notebook">Gift2</option>
                          <option value="Bag">Gift3</option>
                        </select>
                        {errors.gift && <small className="text-danger">{errors.gift}</small>}
                      </div>

                      {/* Status */}
                      <div className="mb-3 col-lg-5 col-md-6 col-sm-12">
                        <label className="form-label">Status *</label>
                        <div>
                          <div className="form-check form-check-inline">
                            <input className="form-check-input" type="radio" name="status" id="statusActive" value="Active" checked={formData.status === "Active"} onChange={handleChange} />
                            <label className="form-check-label" htmlFor="statusActive">Active</label>
                          </div>
                          <div className="form-check form-check-inline">
                            <input className="form-check-input" type="radio" name="status" id="statusDeactive" value="Deactive" checked={formData.status === "Deactive"} onChange={handleChange} />
                            <label className="form-check-label" htmlFor="statusDeactive">Deactive</label>
                          </div>
                        </div>
                        {errors.status && <small className="text-danger">{errors.status}</small>}
                      </div>
                    </div>

                    {/* Buttons */}
                    <div className="col-12 text-end">
                      <button type="reset" className="btn btn-danger btn-md" onClick={() => setFormData({ name: "", sequenceNumber: "", referCount: "", gift: "", status: "" })}>
                        <i className="ri-reset-right-line"></i> Reset
                      </button>
                      &nbsp;&nbsp;
                      <button type="submit" className="btn btn-success">
                        <i className="ri-check-fill"></i> Add Epin
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
