import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";

export default function BelogCategoryEdit() {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    image: null,
    status: "",
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { id, value, files, name } = e.target;

    if (files) {
      // Handle image file
      const file = files[0];

      if (file) {
        const allowedFormats = /\.(png|jpeg|jpg)$/i;
        if (!allowedFormats.test(file.name)) {
          setErrors((prev) => ({ ...prev, image: "Only PNG, JPEG, JPG formats are allowed." }));
          return;
        }

        if (file.size > 5120) {
          setErrors((prev) => ({ ...prev, image: "Image size must be less than 5KB." }));
          return;
        }

        setErrors((prev) => ({ ...prev, image: "" }));
        setFormData((prev) => ({ ...prev, image: file }));
      }
    } else {
      setFormData((prev) => ({ ...prev, [name || id]: value }));
    }
  };

  const validate = () => {
    const newErrors = {};

    // Name validation
    if (formData.name.trim().length < 3) {
      newErrors.name = "Name must be at least 3 characters long.";
    } else if (!/^[a-zA-Z\s]+$/.test(formData.name)) {
      newErrors.name = "Name must contain only letters and spaces.";
    }

    // Description validation
    if (!formData.description.trim()) {
      newErrors.description = "Description is required.";
    }

    // Image validation
    if (!formData.image) {
      newErrors.image = "Please upload an image.";
    }

    // Status validation
    if (!formData.status) {
      newErrors.status = "Please select a status.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      console.log("Form submitted:", formData);
      alert("Form submitted successfully!");
      setFormData({
        name: "",
        description: "",
        image: null,
        status: "",
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>Blog Category Edit</title>
      </Helmet>
      <div className="container">
        <div className="page">
          <div className="page-heading">
            <h1>Blog Category Edit</h1>
            <span>
              <Link to="/"> Dashboard </Link> / <Link to="/kitchen/list">Blog Category Edit</Link>
            </span>
          </div>
          <div className="page-content">
            <div className="portal">
              <div className="portal-body">
                <div className="form">
                  <form autoComplete="off" onSubmit={handleSubmit}>
                    <div className="row">
                      {/* Name */}
                      <div className="mb-3 col-lg-6">
                        <label htmlFor="name" className="form-label">Name *</label>
                        <input type="text" id="name" className="form-control" value={formData.name} onChange={handleChange} />
                        {errors.name && <small className="text-danger">{errors.name}</small>}
                      </div>

                      {/* Image Upload */}
                      <div className="mb-3 col-lg-6">
                        <label className="form-label">Upload Image *</label>
                        <input type="file" id="image" className="form-control" accept=".png,.jpeg,.jpg" onChange={handleChange} />
                        {errors.image && <small className="text-danger">{errors.image}</small>}
                      </div>

                      {/* Description */}
                      <div className="mb-3 col-lg-12">
                        <label htmlFor="description" className="form-label">Description *</label>
                        <textarea id="description" className="form-control" rows="3" value={formData.description} onChange={handleChange}></textarea>
                        {errors.description && <small className="text-danger">{errors.description}</small>}
                      </div>

                      {/* Status */}
                      <div className="mb-3 col-lg-5 col-md-6 col-sm-12">
                        <label className="form-label">Status *</label>
                        <div>
                          <div className="form-check form-check-inline">
                            <input className="form-check-input" type="radio" name="status" value="Active" checked={formData.status === "Active"} onChange={handleChange} />
                            <label className="form-check-label">Active</label>
                          </div>
                          <div className="form-check form-check-inline">
                            <input className="form-check-input" type="radio" name="status" value="Deactive" checked={formData.status === "Deactive"} onChange={handleChange} />
                            <label className="form-check-label">Deactive</label>
                          </div>
                        </div>
                        {errors.status && <small className="text-danger">{errors.status}</small>}
                      </div>

                      {/* Buttons */}
                      <div className="col-12 text-end">
                        <button type="reset" className="btn btn-danger btn-md" onClick={() => setFormData({ name: "", description: "", image: null, status: "" })}>
                          <i className="ri-reset-right-line"></i> Reset
                        </button>
                        &nbsp;&nbsp;
                        <button type="submit" className="btn btn-success">
                          <i className="ri-check-fill"></i> Submit
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
