import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
export default function TableGiftGiving() {
  const [cities, setCities] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [selectedCity, setSelectedCity] = useState('');
  const [name, setName] = useState('');
  const [selectedLevel, setSelectedLevel] = useState('');
  const [selectedGift, setSelectedGift] = useState('');
  // Fetch data from the API
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch('https://jsonplaceholder.typicode.com/users');
        const data = await res.json();
        // Extract unique cities
        const uniqueCities = [...new Set(data.map((user) => user.address.city))];
        setCities(uniqueCities);
        // Set table data
        setTableData(data);
        setFilteredData(data); // Initialize filtered data
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, []);
  // Handle search functionality
  const handleSearch = (e) => {
    e.preventDefault(); // Prevent form submission
    const filtered = tableData.filter((user) => {
      const matchesName = name ? user.name.toLowerCase().includes(name.toLowerCase()) : true;
      const matchesCity = selectedCity ? user.address.city === selectedCity : true;
      const matchesLevel = selectedLevel ? `Level ${user.id % 3 + 1}` === selectedLevel : true; // Example level logic
      const matchesGift = selectedGift ? (user.id % 2 === 0 ? 'Given' : 'Pending') === selectedGift : true; // Example gift logic
      return matchesName && matchesCity && matchesLevel && matchesGift;
    });
    setFilteredData(filtered);
  };
  return (
    <div className='container'>
      <div className='page'>
        <div className='page-heading'>
          <h1>Search Gift Giving</h1>
          <span>
            <Link to="/">Dashboard</Link> / <Link to="/kitchen/list">Search Gift Giving</Link>
          </span>
        </div>
        <div className='page-content'>
          <div className="portal">
            <div className='portal-body'>
              <form onSubmit={handleSearch}>
                <div className="row g-3">
                  {/* Enter Name */}
                  <div className="col-lg-3 col-md-3 col-sm-6 col-12">
                    <div className="mb-3">
                      <label htmlFor="name" className="form-label">Name</label>
                      <input
                        type="text"
                        id="name"
                        className="form-control"
                        placeholder="Enter name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                      />
                    </div>
                  </div>
                  {/* Select City */}
                  <div className="col-lg-3 col-md-3 col-sm-6 col-12">
                    <div className="mb-3">
                      <label htmlFor="city" className="form-label">City</label>
                      <select
                        id="city"
                        className="form-control"
                        value={selectedCity}
                        onChange={(e) => setSelectedCity(e.target.value)}
                      >
                        <option value="">Select City</option>
                        {cities.map((city, index) => (
                          <option key={index} value={city}>
                            {city}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  {/* Select Level */}
                  <div className="col-lg-3 col-md-3 col-sm-6 col-12">
                    <div className="mb-3">
                      <label htmlFor="level" className="form-label">Level</label>
                      <select
                        id="level"
                        className="form-control"
                        value={selectedLevel}
                        onChange={(e) => setSelectedLevel(e.target.value)}
                      >
                        <option value="">Select Level</option>
                        <option value="Level 1">Level 1</option>
                        <option value="Level 2">Level 2</option>
                        <option value="Level 3">Level 3</option>
                      </select>
                    </div>
                  </div>
                  {/* Select Gift */}
                  <div className="col-lg-3 col-md-3 col-sm-6 col-12">
                    <div className="mb-3">
                      <label htmlFor="gift" className="form-label">Gift</label>
                      <select
                        id="gift"
                        className="form-control"
                        value={selectedGift}
                        onChange={(e) => setSelectedGift(e.target.value)}
                      >
                        <option value="">Select Gift</option>
                        <option value="Both">Both</option>
                        <option value="Given">Given</option>
                        <option value="Pending">Pending</option>
                      </select>
                    </div>
                  </div>
                  {/* Search Button */}
                  <div className="col-lg-3 col-md-3 col-sm-6 col-12">
                    <button
                      className="btn btn-secondary w-100"
                      type="submit"
                      id="button-addon1"
                    >
                      <FontAwesomeIcon icon="fa-solid fa-search" /> Search
                    </button>
                  </div>
                </div>
              </form>
              <div className='table-content'>
                <table className='table table-bordered table-condensed'>
                  <thead>
                    <tr>
                      <th>Member Detail</th>
                      <th>City</th>
                      <th>Gift</th>
                      <th>Status</th>
                      <th>Given Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredData.map((user, index) => (
                      <tr key={index}>
                        <td>{user.name}</td>
                        <td>{user.address.city}</td>
                        <td>{index % 2 === 0 ? 'Given' : 'Pending'}</td> {/* Example Gift Status */}
                        <td>{index % 2 === 0 ? 'Completed' : 'Pending'}</td> {/* Example Status */}
                        <td>{new Date().toLocaleDateString()}</td> {/* Example Date */}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}