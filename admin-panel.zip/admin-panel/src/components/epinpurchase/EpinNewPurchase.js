import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";

export default function EpinNewPurchase() {
      const [formData, setFormData] = useState({
    mobile: "",
    name: "",
    city: "",
    purchaseDate: "",
    price: "",
    unit: "",
    level: "",
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const levels = ["Level 1", "Level 2", "Level 3"];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.mobile || !/^\d{10}$/.test(formData.mobile)) {
      newErrors.mobile = "Mobile number must be 10 digits.";
    }

    if (!formData.name || formData.name.trim() === "") {
      newErrors.name = "Member Name is required.";
    } else if (!/^[a-zA-Z\s]+$/.test(formData.name)) {
      newErrors.name = "Member Name must contain only letters and spaces.";
    }

    if (!formData.city || formData.city.trim() === "") {
      newErrors.city = "Member City is required.";
    } else if (!/^[a-zA-Z\s]+$/.test(formData.city)) {
      newErrors.city = "Member City must contain only letters and spaces.";
    }

    if (!formData.purchaseDate) {
      newErrors.purchaseDate = "Purchase Date is required.";
    }

    if (!formData.price) {
      newErrors.price = "Price is required.";
    } else if (isNaN(formData.price) || formData.price < 10) {
      newErrors.price = "Price must be a number and at least 10.";
    }

    if (!formData.unit) {
      newErrors.unit = "Unit is required.";
    } else if (isNaN(formData.unit) || formData.unit < 1) {
      newErrors.unit = "Unit must be a number and at least 1.";
    }

    if (!formData.level) {
      newErrors.level = "Please select a level.";
    }

    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setIsSubmitting(true);
      console.log("Form submitted successfully!", formData);
      // Add API call or submission logic here
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setFormData({
      mobile: "",
      name: "",
      city: "",
      purchaseDate: "",
      price: "",
      unit: "",
      level: "",
    });
    setErrors({});
  };

  return (
    <div className="container">
      <div className="page">
        <div className="page-heading">
          <h1>Epin New Purchase</h1>
          <span>
            <Link to="/"> Dashboard </Link> /{" "}
            <Link to="/epin-new-purchase/create">Epin New Purchase</Link>
          </span>
        </div>
        <div className="page-content">
          <div className="portal">
            <div className="portal-body">
              <div className="form">
                <form autoComplete="off" onSubmit={handleSubmit}>
                  <div className="row mb-3">
                    <div className="col-md-4">
                      <label className="form-label">Member Mobile</label>
                      <div className="input-group">
                        <input
                          type="text"
                          className={`form-control ${
                            errors.mobile ? "is-invalid" : ""
                          }`}
                          placeholder="Enter 10-digit mobile number"
                          name="mobile"
                          value={formData.mobile}
                          onChange={handleChange}
                        />
                        <button type="button" className="btn btn-primary">
                          Verify
                        </button>
                      </div>
                      {errors.mobile && (
                        <small className="text-danger">{errors.mobile}</small>
                      )}
                    </div>

                    <div className="col-md-4">
                      <label className="form-label">Member Name</label>
                      <input
                        type="text"
                        className={`form-control ${errors.name ? "is-invalid" : ""}`}
                        name="name"
                        value={formData.name}
                        readOnly
                      />
                      {errors.name && <small className="text-danger">{errors.name}</small>}
                    </div>

                    <div className="col-md-4">
                      <label className="form-label">Member City</label>
                      <input
                        type="text"
                        className={`form-control ${errors.city ? "is-invalid" : ""}`}
                        name="city"
                        value={formData.city}
                        readOnly
                      />
                      {errors.city && <small className="text-danger">{errors.city}</small>}
                    </div>
                  </div>

                  <div className="row mb-3">
                    <div className="col-md-4">
                      <label className="form-label">Purchase Date</label>
                      <input
                        type="date"
                        className={`form-control ${
                          errors.purchaseDate ? "is-invalid" : ""
                        }`}
                        name="purchaseDate"
                        value={formData.purchaseDate}
                        onChange={handleChange}
                      />
                      {errors.purchaseDate && (
                        <small className="text-danger">
                          {errors.purchaseDate}
                        </small>
                      )}
                    </div>

                    <div className="col-md-4">
                      <label className="form-label">Price</label>
                      <input
                        type="number"
                        className={`form-control ${
                          errors.price ? "is-invalid" : ""
                        }`}
                        placeholder="Enter price (minimum 10)"
                        name="price"
                        value={formData.price}
                        onChange={handleChange}
                      />
                      {errors.price && (
                        <small className="text-danger">{errors.price}</small>
                      )}
                    </div>

                    <div className="col-md-4">
                      <label className="form-label">Unit</label>
                      <input
                        type="number"
                        className={`form-control ${
                          errors.unit ? "is-invalid" : ""
                        }`}
                        placeholder="Enter unit (minimum 1)"
                        name="unit"
                        value={formData.unit}
                        onChange={handleChange}
                      />
                      {errors.unit && (
                        <small className="text-danger">{errors.unit}</small>
                      )}
                    </div>
                  </div>

                  <div className="row mb-3">
                    <div className="col-md-4">
                      <label className="form-label">Level</label>
                      <select
                        className={`form-select ${
                          errors.level ? "is-invalid" : ""
                        }`}
                        name="level"
                        value={formData.level}
                        onChange={handleChange}
                      >
                        <option value="">Select Level</option>
                        {levels.map((level, index) => (
                          <option key={index} value={level}>
                            {level}
                          </option>
                        ))}
                      </select>
                      {errors.level && (
                        <small className="text-danger">{errors.level}</small>
                      )}
                    </div>
                  </div>

                  <div className="text-end">
                    <button
                      type="button"
                      className="btn btn-danger btn-md"
                      onClick={handleReset}
                    >
                      Reset
                    </button>
                    &nbsp;&nbsp;
                    <button
                      type="submit"
                      className="btn btn-success btn-md"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? "Submitting..." : "Submit"}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}