import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faPlus } from '@fortawesome/free-solid-svg-icons';

// 🔧 Filter logic
function filterMembers(members, keyword) {
  return members.filter((member) =>
    member.name.toLowerCase().includes(keyword.toLowerCase())
  );
}

export default function TableBlog() {
  const [keyword, setKeyword] = useState('');
  const [members, setMembers] = useState([]);
  const [filteredMembers, setFilteredMembers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const users = async (searchKeyword) => {
    setLoading(true);
    try {
      const response = await fetch('https://jsonplaceholder.typicode.com/users');
      if (!response.ok) {
        throw new Error(`Failed to fetch users: ${response.status}`);
      }
      const data = await response.json();

      const enhancedData = data.map((user) => ({
        name: user.name,
        city: user.address.city,
        createDateTime: new Date().toLocaleString(),
        status: Math.random() > 0.5 ? 'Active' : 'Inactive',
      }));

      setMembers(enhancedData); // Save full data

      // 🟡 Filter immediately after fetching
      const results = filterMembers(enhancedData, searchKeyword);
      setFilteredMembers(results);

    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    users(keyword); // Pass the keyword to fetch + filter
  };

  if (loading) {
    return (
      <div className="container">
        <div className="page">
          <div className="page-content">Loading...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container">
        <div className="page">
          <div className="page-content">Error: {error}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="page">
        <div className="page-heading">
          <h1>Search Blog</h1>
          <span>
            <Link to="/">Dashboard</Link> / <Link to="/kitchen/list">Search Blog</Link>
          </span>
        </div>

        <div className="page-content">
          <div className="portal">
            <div className="portal-body">
              {/* 🔍 Search Form */}
              <form onSubmit={handleSearch}>
                <div className="row">
                  <div className="col-lg-3 col-md-3 col-sm-6 col-12">
                    <div className="mb-3">
                      <label htmlFor="keyword" className="form-label">
                        Keyword
                      </label>
                      <div className="input-group mb-3">
                        <input
                          type="text"
                          className="form-control"
                          value={keyword}
                          onChange={(e) => setKeyword(e.target.value)}
                        />
                        <button className="btn btn-secondary" type="submit">
                          <FontAwesomeIcon icon={faSearch} />
                        </button>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-3 col-md-3 col-sm-6 col-12">
                    <div className="p-2">
                      <div className="input-group p-4">
                        <Link className="btn btn-secondary" to="/blog/add">
                          <FontAwesomeIcon icon={faPlus} /> Add
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              </form>

              {/* 🧾 Results Table */}
              <div className="table-content">
                <table className="table table-bordered table-condensed">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>City</th>
                      <th>Create Date Time</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredMembers.length > 0 ? (
                      filteredMembers.map((member, index) => (
                        <tr key={index}>
                          <td>{member.name}</td>
                          <td>{member.city}</td>
                          <td>{member.createDateTime}</td>
                          <td>{member.status}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="4" className="text-center">
                          No members found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
