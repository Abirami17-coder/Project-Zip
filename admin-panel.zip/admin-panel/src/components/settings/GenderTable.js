import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useGlobalContext } from '../../GlobalContext';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

export default function TableGenders() {

  const { setIsLoading, setAppError, setAppErrorMessage, setAppErrorTitle, setAppErrorMode, appKitchen } = useGlobalContext();

  return (
    <div className='container'>
      <div className='page'>
        <div className='page-heading'>
          <h1>Search Genders</h1>
          <span>
            <Link to="/">Dashboard</Link> / <Link to="/kitchen/list">Search Genders</Link>
          </span>
        </div>

        <div className='page-content'>
          <div className="portal">
            <div className='portal-body'>
              <form>
                <div className='row'>
                  <div className='col-lg-3 col-md-3 col-sm-6 col-12'>
                    <div className="mb-3">
                      <label htmlFor="keyword" className="form-label">Keyword</label>
                      <div className="input-group mb-3">
                        <input type="text" className="form-control"  />
                        <button className="btn btn-secondary" type="button" id="button-addon1">
                          <FontAwesomeIcon icon="fa-solid fa-search" />
                        </button>
                      </div>
                    </div>
                  </div>
                  <div className='col-lg-3 col-md-3 col-sm-6 col-12'>
                    <div className="p-2">
                      <div className="input-group p-4">
                        <Link className="btn btn-secondary">
                          <FontAwesomeIcon icon="fa-solid fa-plus" /> Add
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              </form>

              <div className='table-content'>
                <table className='table table-bordered table-condensed'>
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
