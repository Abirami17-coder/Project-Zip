import React from 'react'
import { Link } from 'react-router-dom';
import { useGlobalContext } from './../../GlobalContext';

function NavAvatar() {

  const { isLoading, setIsLoading, isAppError, setAppError, appErrorMessage, setAppErrorMessage, appErrorTitle, setAppErrorTitle, appErrorMode, setAppErrorMode, appUser, setAppUser, isLogin, setIsLogin } = useGlobalContext();


  return (
    <>
      <li className='nav-item dropdown pe-3'>
        <Link className='nav-link nav-profile d-flex align-items-center pe-0' to='#' data-bs-toggle="dropdown">
          <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQGtEolGdo2azvBIZT3BEBbP4nClhnBedEWA&s' alt='Profile' className='rounded-circle' />
          <span className='d-none d-md-block dropdown-toggle ps-2'>{appUser.name}</span>
        </Link>

        <ul className='dropdown-menu dropdown-menu-end dropdown-menu-arrow profile'>
          <li className='dropdown-header'>
            <h6>{appUser.mobile}</h6>
            <span>{appUser.role}</span>
          </li>
          <li>
            <hr className='dropdown-divider'/>
          </li>

          <li>
            <Link className='dropdown-item d-flex align-items-center' to='/myprofile'>
              <i className='bi bi-person'></i>
              <span>My Profile</span>
            </Link>
          </li>
          <li>
            <hr className='dropdown-divider'/>
          </li>

          <li>
            <Link className='dropdown-item d-flex align-items-center' to='/mypassword'>
              <i className='bi bi-key'></i>
              <span>My Password</span>
            </Link>
          </li>
          <li>
            <hr className='dropdown-divider'/>
          </li>

          <li>
            <Link className='dropdown-item d-flex align-items-center' to='/config-variables'>
              <i className='bi bi-list'></i>
              <span>Config Variables</span>
            </Link>
          </li>
          <li>
            <hr className='dropdown-divider'/>
          </li>
          
          <li>
            <Link className='dropdown-item d-flex align-items-center' to='#'>
              <i className='bi bi-lock'></i>
              <span>Sign Out</span>
            </Link>
          </li>

        </ul>
      </li>
    </>
  )
}

export default NavAvatar;