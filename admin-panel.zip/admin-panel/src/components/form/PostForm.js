import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import axios from 'axios';

export default function StudentForm() {
    const [student, setStudent] = useState({
        name: '',
        email: '',
        age: '',
        course: '',
    });

    const [errors, setErrors] = useState({});
    const [successMsg, setSuccessMsg] = useState('');
    const [errorMsg, setErrorMsg] = useState('');
    const [submittedStudents, setSubmittedStudents] = useState([]);
    const [studentsVisible, setStudentsVisible] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setStudent({ ...student, [name]: value });
    };

    const validate = () => {
        let formErrors = {};

        // Name validation
        if (!student.name.trim()) {
            formErrors.name = 'Name is required.';
        } else if (!/^[a-zA-Z\s]+$/.test(student.name)) {
            formErrors.name = 'Name can only contain letters and spaces.';
        }

        // Email validation
        if (!student.email.trim()) {
            formErrors.email = 'Email is required.';
        } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(student.email)) {
            formErrors.email = 'Invalid email format.';
        }

        // Age validation (2-digit number)
        if (!student.age.trim()) {
            formErrors.age = 'Age is required.';
        } else if (!/^\d{2}$/.test(student.age)) {
            formErrors.age = 'Age must be a 2-digit number.';
        }

        // Course validation (only letters, >4 chars)
        if (!student.course.trim()) {
            formErrors.course = 'Course is required.';
        } else if (!/^[a-zA-Z\s]+$/.test(student.course)) {
            formErrors.course = 'Course must contain only letters.';
        } else if (student.course.trim().length <= 4) {
            formErrors.course = 'Course must be more than 4 characters.';
        }

        setErrors(formErrors);
        return Object.keys(formErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;

        try {
            const response = await axios.post('https://jsonplaceholder.typicode.com/posts', student);
            const newStudent = { ...student, id: response.data.id };
            setSubmittedStudents(prev => [...prev, newStudent]);
            setSuccessMsg(`Student registered successfully. ID: ${response.data.id}`);
            setErrorMsg('');
            setStudent({ name: '', email: '', age: '', course: '' });
            setErrors({});
            setStudentsVisible(false);
        } catch (error) {
            setErrorMsg('Failed to submit form. Try again.');
            setSuccessMsg('');
        }
    };

    const fetchStudents = () => {
        if (submittedStudents.length === 0) {
            setErrorMsg('No students have been submitted yet.');
            setStudentsVisible(false);
        } else {
            setErrorMsg('');
            setStudentsVisible(true);
        }
    };

    return (
        <>
            <Helmet>
                <title>Student Registration</title>
            </Helmet>
            <div className="container mt-4">
                <div className="page-heading">
                    <h1>Student Registration</h1>
                    <span>
                        <Link to="/">Dashboard</Link> / Student Registration
                    </span>
                </div>

                <div className="page-content">
                    <div className="portal">
                        <div className="portal-body">
                            <form onSubmit={handleSubmit}>
                                <div className="row mb-3">
                                    <div className="col-lg-4 col-sm-12 mb-3">
                                        <label className="form-label">Name:</label>
                                        <input
                                            type="text"
                                            name="name"
                                            value={student.name}
                                            onChange={handleChange}
                                            className="form-control"
                                        />
                                        {errors.name && <div className="text-danger">{errors.name}</div>}
                                    </div>

                                    <div className="col-lg-4 col-sm-12 mb-3">
                                        <label className="form-label">Email:</label>
                                        <input
                                            type="email"
                                            name="email"
                                            value={student.email}
                                            onChange={handleChange}
                                            className="form-control"
                                        />
                                        {errors.email && <div className="text-danger">{errors.email}</div>}
                                    </div>

                                    <div className="col-lg-4 col-sm-12 mb-3">
                                        <label className="form-label">Age:</label>
                                        <input
                                            type="number"
                                            name="age"
                                            value={student.age}
                                            onChange={handleChange}
                                            className="form-control"
                                        />
                                        {errors.age && <div className="text-danger">{errors.age}</div>}
                                    </div>

                                    <div className="col-lg-4 col-sm-12 mb-3">
                                        <label className="form-label">Course:</label>
                                        <input
                                            type="text"
                                            name="course"
                                            value={student.course}
                                            onChange={handleChange}
                                            className="form-control"
                                        />
                                        {errors.course && <div className="text-danger">{errors.course}</div>}
                                    </div>
                                </div>

                                <div className="text-end">
                                    <button
                                        type="reset"
                                        className="btn btn-danger me-2"
                                        onClick={() => {
                                            setStudent({ name: '', email: '', age: '', course: '' });
                                            setErrors({});
                                            setSuccessMsg('');
                                            setErrorMsg('');
                                            setStudentsVisible(false);
                                        }}
                                    >
                                        Reset
                                    </button>
                                    <button type="submit" className="btn btn-success">
                                        Submit
                                    </button>
                                </div>
                            </form>

                            {successMsg && <div className="alert alert-success mt-3">{successMsg}</div>}
                            {errorMsg && <div className="alert alert-danger mt-3">{errorMsg}</div>}

                            <hr className="my-4" />

                            <button onClick={fetchStudents} className="btn btn-primary mb-3">
                                Fetch Students
                            </button>

                            {studentsVisible && (
                                <div className="table-responsive">
                                    <table className="table table-bordered">
                                        <thead className="table-light">
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Age</th>
                                                <th>Course</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {submittedStudents.map((s) => (
                                                <tr key={s.id}>
                                                    <td>{s.id}</td>
                                                    <td>{s.name}</td>
                                                    <td>{s.email}</td>
                                                    <td>{s.age}</td>
                                                    <td>{s.course}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
