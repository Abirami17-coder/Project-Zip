import React from 'react'

const Home = () => {
    return (
        <div className='full-body'>
            <nav className="navbar top-nav">
                <div className="top-logo">
                    <a className="navbar-brand" href="#">
                        <img
                            src="https://miro.medium.com/v2/resize:fit:2400/1*5GEwcDNbK32d0gdPpcb6nA@2x.jpeg"
                            alt="logo"
                            className="logo-img"
                        />
                    </a>

                </div>
                <div className='nav-heading'>
                    <h3>Jim Hurry</h3>
                    <p>UI/UX Designer</p>
                </div>
                <div className="top-right ">
                    <i className="bi bi-calendar3 date-icon"></i>
                    <i className="bi bi-bell-fill notification-icon"></i>
                </div>

            </nav>
            <div className='container'>
                <div className='row'>


                    <div className='col-12'>
                        <div className="card first-card">
                            <div className="card-body">

                                <h4>Today's Summary</h4>
                                <p>02 May, 2025</p>


                                <div className='row'>

                                    <div className='col-4'>
                                        <div className="card text-bg-success  three-card" >

                                            <div className="card-body">
                                                <p className="card-title">Totel Meeting</p>
                                                <p className="card-text">
                                                    03 </p>
                                            </div>
                                        </div>

                                    </div>
                                    <div className='col-4'>
                                        <div className="card text-bg-info three-card " >

                                            <div className="card-body">
                                                <p className="card-title">Event Today</p>
                                                <p className="card-text">
                                                    01 </p>
                                            </div>
                                        </div>

                                    </div>
                                    <div className='col-4'>
                                        <div className="card text-bg-warning   three-card" >

                                            <div className="card-body">
                                                <p className="card-title">Need Approval</p>
                                                <p className="card-text">
                                                    07 </p>
                                            </div>
                                        </div>

                                    </div>


                                </div>



                            </div>
                        </div>
                        <div className="card second-card">
                            <div className="card-body">
                                <h4>Today's Summary</h4>
                                <p>Your schedule for the day</p>
                                <div className='calendar '>
                                    <p>
                                        view in calender  <i className="bi bi-chevron-right greterthen-icon"></i>
                                    </p>
                                </div>

                                <div className='meeting'>
                                    <div className='meeting-left'>
                                        <div className='meeting-title'>
                                            <i className="bi bi-camera-video-fill"></i>
                                            Team Scrum
                                        </div>
                                        <div className='meeting-time'>
                                            <i className="bi bi-clock-fill"></i>
                                            12:30 PM - 01:00 PM
                                        </div>
                                    </div>

                                    <div className='meeting-right'>
                                        <div className='meeting-logos'>
                                            <img src="https://miro.medium.com/v2/resize:fit:2400/1*5GEwcDNbK32d0gdPpcb6nA@2x.jpeg" alt="logo" className="logo-img" />
                                            <img src="https://fiverr-res.cloudinary.com/images/t_main1,q_auto,f_auto,q_auto,f_auto/v1/attachments/delivery/asset/b85cf980e5c3d7fde09d23d36398d476-1666881878/preview_fiverr/create-animated-discord-avatar-and-banners.gif" alt="logo" className="logo-img" />
                                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6hjlk6cRnQKjxbtdhH26u3TiJDlLPZLhlj39gjH-5GrYfY13q7vlVPa79jpVsnz5KBic&usqp=CAU" alt="logo" className="logo-img" />
                                            +3
                                        </div>
                                        <div className='meeting-button'>
                                            <button type="button" className="btn btn-primary join-button">Join Meeting</button>
                                        </div>
                                    </div>
                                </div>
                                <div className='meeting'>
                                    <div className='meeting-left'>
                                        <div className='meeting-title'>
                                            <i className="bi bi-camera-video-fill"></i>
                                            Team Scrum
                                        </div>
                                        <div className='meeting-time'>
                                            <i className="bi bi-clock-fill"></i>
                                            12:30 PM - 01:00 PM
                                        </div>
                                    </div>

                                    <div className='meeting-right'>
                                        <div className='meeting-logos'>
                                            <img src="https://img.freepik.com/free-vector/cute-cat-gaming-cartoon_138676-2969.jpg?semt=ais_hybrid&w=740" alt="logo" className="logo-img" />
                                            <img src="https://i.pinimg.com/474x/94/4c/b0/944cb06d9038601acb51b5e434116db8.jpg" alt="logo" className="logo-img" />
                                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRe8nbC4P3Z0ezNUr7K2XHCLr5CLWo5haaJfZhwbCLEd3KzeWuDTu9-1rUfp4z5I3WlTMQ&usqp=CAU" alt="logo" className="logo-img" />
                                            +3
                                        </div>
                                        <div className='meeting-button'>
                                            <button type="button" className="btn btn-primary join-button">Join Meeting</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="card thard-card">
                            <div className="card-body">
                                <h1>Quick Action</h1>

                                <div className='row'>
                                    <div className='col-6'>
                                        <div className='meeting'>
                                            <div className='actions'>
                                                <i className="bi bi-emoji-smile"></i>
                                                <p>Leave History</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='col-6'>
                                        <div className='meeting'>
                                            <div className='actions'>
                                                <i className="bi bi-file-earmark-break"></i>
                                                <p>Request Document</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='col-6'>
                                        <div className='meeting'>
                                            <div className='actions'>
                                              <i className="bi bi-building-exclamation"></i>
                                                <p>My Attendance</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='col-6'>
                                        <div className='meeting'>
                                            <div className='actions'>
                                                <i className="bi bi-calendar-event"></i>
                                                <p>TA\CA</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                 <div className='footer'>
                <div className='row'>
                    <div className='col-4'>
                        <div className='home-icon'>
                            <i className="bi bi-house-door-fill ">Home</i>
                        </div>

                    </div>
                     <div className='col-2'>
                        <div className='footer-icons'>
                            <i className="bi bi-chat-left-dots-fill"></i>

                        </div>

                    </div>
                     <div className='col-2'>
                        <div className='footer-icons'>
                            <i className="bi bi-box-arrow-in-right"></i>
                        </div>

                    </div>
                     <div className='col-2'>
                        <div className='footer-icons'>
                          <i className="bi bi-pen-fill"></i>


                        </div>

                    </div>
                     <div className='col-2'>
                        <div className='footer-icons'>
                            <i className="bi bi-person-fill"></i>

                        </div>

                    </div>

                </div>

            </div>
            </div>
           
        </div>

    )
}

export default Home
