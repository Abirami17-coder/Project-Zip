    <footer class="bg-dark text-light py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Contact Us</h5>
                    <p>
                        <?php echo $company['address']; ?><br>
                        Phone: <?php echo $company['phone']; ?><br>
                        Email: <?php echo $company['email']; ?>
                    </p>
                </div>
                <div class="col-md-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo BASE_URL; ?>/about.php" class="text-light">About Us</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/products.php" class="text-light">Products & Spares</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/gallery.php" class="text-light">Gallery</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/contact.php" class="text-light">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Follow Us</h5>
                    <div class="social-links">
                        <!-- Add social media links here -->
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/assets/js/main.js"></script>
    <a href="https://wa.me/971547245075" class="whatsapp-float" target="_blank">
        <i class="fab fa-whatsapp"></i>
    </a>
</body>
</html> 