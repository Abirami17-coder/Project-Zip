<?php
require_once 'config/config.php';
require_once 'config/database.php';

// Fetch company details
$sql = "SELECT * FROM company_details WHERE id = 1";
$result = $conn->query($sql);
$company = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $company['company_name']; ?> - Diesel Flow Meters & Spares in UAE</title>
    <meta name="description" content="<?php echo SITE_DESCRIPTION; ?>">
    <meta name="keywords" content="Flow Meters UAE, Diesel Pumps Dubai, Water Pumps UAE, Fuel Dispensers Abu Dhabi, Tank Level Monitoring UAE, Flow Meter Calibration UAE">
    <meta name="author" content="Al Safa Measuring Equipments">
    <meta property="og:title" content="Al Safa Measuring Equipments - Flow Meters & Pumps UAE">
    <meta property="og:description" content="Leading provider of diesel flow meters, water pumps, and fuel dispensing solutions in UAE">
    <meta property="og:image" content="<?php echo BASE_URL; ?>/assets/images/og-image.jpg">
    <meta property="og:url" content="<?php echo BASE_URL; ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo BASE_URL; ?>/assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header class="bg-light">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="<?php echo BASE_URL; ?>/">
                    <img src="<?php echo $company['logo_url']; ?>" alt="<?php echo $company['company_name']; ?>" height="50">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>/">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>/about.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>/products.php">Products & Spares</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>/gallery.php">Gallery</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>/contact.php">Contact Us</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>
</body>
</html> 