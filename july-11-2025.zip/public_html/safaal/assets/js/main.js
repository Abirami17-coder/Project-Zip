// Product modal functionality
function showProductModal(productId) {
    fetch(`ajax/get_product.php?id=${productId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const product = data.data;
                const modal = document.getElementById('productModal');
                
                modal.querySelector('.modal-title').textContent = product.title;
                modal.querySelector('.modal-body').innerHTML = `
                    <div class="row">
                        <div class="col-md-6">
                            <img src="${product.image_url}" class="img-fluid" alt="${product.title}">
                        </div>
                        <div class="col-md-6">
                            <h5>Description</h5>
                            <p>${product.full_description}</p>
                            <button class="btn btn-primary" 
                                    onclick="showEnquiryForm(${product.id}, '${product.title}')">
                                Make Enquiry
                            </button>
                        </div>
                    </div>
                `;
                
                new bootstrap.Modal(modal).show();
            }
        });
}

// Contact form submission
document.getElementById('contactForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('process/contact.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(data.message);
            this.reset();
        } else {
            alert(data.message || 'Error submitting form');
        }
    });
});

// Gallery filtering
document.querySelectorAll('[data-gallery-filter]').forEach(button => {
    button.addEventListener('click', function() {
        const filter = this.getAttribute('data-gallery-filter');
        
        document.querySelectorAll('.gallery-item').forEach(item => {
            if (filter === 'all' || item.getAttribute('data-category') === filter) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
        
        // Update active button
        document.querySelectorAll('[data-gallery-filter]').forEach(btn => {
            btn.classList.remove('active');
        });
        this.classList.add('active');
    });
});

// Gallery modal
document.querySelectorAll('.gallery-image').forEach(image => {
    image.addEventListener('click', function() {
        const modal = document.getElementById('imageModal');
        const modalTitle = modal.querySelector('.modal-title');
        const modalImage = modal.querySelector('.modal-body img');
        
        modalTitle.textContent = this.getAttribute('data-title');
        modalImage.src = this.getAttribute('data-full-image');
        modalImage.alt = this.getAttribute('data-title');
    });
});

// Product filtering - Updated version
document.querySelectorAll('[data-filter]').forEach(button => {
    button.addEventListener('click', function() {
        const filter = this.getAttribute('data-filter');
        
        document.querySelectorAll('.product-item').forEach(item => {
            if (filter === 'all' || item.getAttribute('data-category') === filter) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
        
        // Update active button
        document.querySelectorAll('[data-filter]').forEach(btn => {
            btn.classList.remove('active');
        });
        this.classList.add('active');
    });
}); 