<?php include 'includes/header.php'; ?>

<main>
    <!-- Hero Section -->
    <section class="hero bg-primary text-white py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1>Welcome to Al Safa Measuring Equipments</h1>
                    <p class="lead">Your trusted partner for Diesel Flow Meters & Spares in UAE</p>
                    <div class="mt-4">
                        <a href="<?php echo BASE_URL; ?>/contact.php" class="btn btn-light me-3">Contact Us</a>
                        <a href="<?php echo BASE_URL; ?>/products.php" class="btn btn-outline-light">View Products</a>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="/assets/img/Fuel Dispenser.jpg" alt="Al Safa Services" class="img-fluid rounded" style="max-width: 100%; max-height: 100%; width: 600px; height: 400px; object-fit: contain;">
                </div>
            </div>
        </div>
    </section>

    <!-- Dynamic Content Sections -->
    <?php
    $sections_sql = "SELECT * FROM home_sections WHERE is_active = 1 ORDER BY section_order";
    $sections_result = $conn->query($sections_sql);

    while($section = $sections_result->fetch_assoc()):
        $content_class = $section['image_position'] === 'left' ? 'order-md-2' : '';
        $image_class = $section['image_position'] === 'left' ? 'order-md-1' : '';
    ?>
    <section class="py-5 <?php echo $section['section_order'] % 2 === 0 ? 'bg-light' : ''; ?>">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 <?php echo $content_class; ?>">
                    <h2><?php echo htmlspecialchars($section['title']); ?></h2>
                    <h4 class="text-muted"><?php echo htmlspecialchars($section['subtitle']); ?></h4>
                    <p class="mt-3"><?php echo htmlspecialchars($section['content']); ?></p>
                    <?php if($section['button_text']): ?>
                        <a href="<?php echo BASE_URL . htmlspecialchars($section['button_url']); ?>" 
                           class="btn btn-primary mt-3">
                            <?php echo htmlspecialchars($section['button_text']); ?>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="col-md-6 <?php echo $image_class; ?>">
                    <img src="<?php echo htmlspecialchars($section['image_url']); ?>" 
                         alt="<?php echo htmlspecialchars($section['title']); ?>" 
                         class="img-fluid rounded shadow"
                         style="max-width: 100%; max-height: 100%; width: 600px; height: 400px; object-fit: contain;">
                </div>
            </div>
        </div>
    </section>
    <?php endwhile; ?>

    <!-- Why Choose Us Section -->
    <section class="features py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Why Choose Us?</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-tools fa-3x mb-3"></i>
                            <h5>Expert Service</h5>
                            <p>Professional installation and maintenance of diesel flow meters</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-certificate fa-3x mb-3"></i>
                            <h5>Quality Products</h5>
                            <p>Genuine parts and equipment from trusted manufacturers</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-clock fa-3x mb-3"></i>
                            <h5>24/7 Support</h5>
                            <p>Round-the-clock customer support across UAE</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">What Our Clients Say</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="mb-3">
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                            </div>
                            <p class="card-text">"Their digital monitoring systems have revolutionized our fleet management. Highly recommended for accuracy and reliability."</p>
                            <div class="mt-3">
                                <strong>Mohammed Al Qasimi</strong><br>
                                <small class="text-muted">Logistics Company, Abu Dhabi</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="mb-3">
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                            </div>
                            <p class="card-text">"Excellent service and support. Their calibration services are top-notch, and their team is always responsive."</p>
                            <div class="mt-3">
                                <strong>Sara Al Mansoori</strong><br>
                                <small class="text-muted">Industrial Plant, Sharjah</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5 bg-primary text-white text-center">
        <div class="container">    
            <h2>Ready to Optimize Your Fuel Management?</h2>
            <p class="lead">Contact us today for a FREE consultation on flow meter calibration and fuel dispensing solutions!</p>
            <div class="mt-4">
                <a href="<?php echo BASE_URL; ?>/contact.php" class="btn btn-light me-3">Get a Free Quote</a>
                <a href="tel:+971547245075" class="btn btn-outline-light">Call Us Now</a>
            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?> 