use safaal_db;
-- Insert company details
INSERT INTO company_details (
    company_name,
    logo_url,
    email,
    phone,
    address,
    map_coordinates
) VALUES (
    'Al Safa Measuring Equipments',
    'https://picsum.photos/200/100',
    'sales@safaal.com',
    '+971 54 724 5075',
    'Aljurf 2. Ajman. UAE',
    '25.4049008,55.4700991'
);

-- Insert product categories
INSERT INTO categories (name, slug) VALUES
('Flow Meters', 'flow-meters'),
('Spare Parts', 'spare-parts'),
('Accessories', 'accessories'),
('Service Kits', 'service-kits');

-- Insert sample products
INSERT INTO products (
    category_id,
    title,
    slug,
    short_description,
    full_description,
    image_url
) VALUES
(1, 'Digital Flow Meter DFM-100', 'digital-flow-meter-dfm-100',
    'High-precision digital flow meter for diesel applications',
    'The DFM-100 is a state-of-the-art digital flow meter designed for accurate measurement of diesel fuel consumption. Features include digital display, pulse output, and temperature compensation.',
    'https://picsum.photos/400/300'),

(1, 'Mechanical Flow Meter MFM-200', 'mechanical-flow-meter-mfm-200',
    'Reliable mechanical flow meter for industrial use',
    'The MFM-200 mechanical flow meter offers reliable performance in harsh industrial environments. Built with durable materials and requiring no power supply.',
    'https://picsum.photos/400/300'),

(2, 'Seal Kit SK-001', 'seal-kit-sk-001',
    'Complete seal kit for DFM series flow meters',
    'Comprehensive seal kit containing all necessary seals and O-rings for DFM series flow meters. Includes installation guide and maintenance tips.',
    'https://picsum.photos/400/300'),

(2, 'Flow Sensor FS-100', 'flow-sensor-fs-100',
    'Replacement flow sensor for digital meters',
    'High-quality replacement flow sensor compatible with most digital flow meter models. Features improved durability and accuracy.',
    'https://picsum.photos/400/300'),

(3, 'Mounting Bracket MB-200', 'mounting-bracket-mb-200',
    'Universal mounting bracket for flow meters',
    'Adjustable mounting bracket suitable for various flow meter models. Made from durable stainless steel with vibration dampening.',
    'https://picsum.photos/400/300'),

(4, 'Maintenance Kit MK-001', 'maintenance-kit-mk-001',
    'Complete maintenance kit for annual service',
    'Comprehensive maintenance kit including seals, filters, and cleaning materials. Recommended for annual maintenance of flow meter systems.',
    'https://picsum.photos/400/300');

-- Insert sample gallery images
INSERT INTO gallery (category, title, image_url) VALUES
('Products', 'Flow Meter Installation', 'https://picsum.photos/800/600'),
('Services', 'Maintenance Service', 'https://picsum.photos/800/600'),
('Installation', 'Industrial Setup', 'https://picsum.photos/800/600'),
('Products', 'Digital Display Unit', 'https://picsum.photos/800/600'),
('Services', 'Calibration Process', 'https://picsum.photos/800/600'),
('Installation', 'Commercial Installation', 'https://picsum.photos/800/600');

-- Insert sample enquiry (optional - for testing)
INSERT INTO enquiries (
    name,
    email,
    phone,
    message,
    product_id
) VALUES (
    'Test Customer',
    'test@example.com',
    '+971 50 987 6543',
    'I am interested in the Digital Flow Meter DFM-100. Please send me more information.',
    1
); 

-- Sample data for homepage sections
INSERT INTO home_sections (title, subtitle, content, image_url, image_position, section_order, button_text, button_url) VALUES
('Industry Leading Solutions', 
 'Excellence in Flow Measurement',
 'With decades of experience in the field, we provide cutting-edge diesel flow meter solutions that meet the highest industry standards. Our commitment to quality and precision has made us the preferred choice across UAE.',
 'https://picsum.photos/600/400',
 'right',
 1,
 'View Products',
 '/products.php'),

('Advanced Technology', 
 'State-of-the-art Equipment',
 'We utilize the latest technology in flow measurement systems, ensuring accurate and reliable results for all your diesel consumption monitoring needs.',
 'https://picsum.photos/600/400',
 'left',
 2,
 'Learn More',
 '/about.php'),

('Expert Service Team', 
 'Professional Installation & Support',
 'Our team of certified technicians provides expert installation, calibration, and maintenance services across all emirates, ensuring your equipment performs at its best.',
 'https://picsum.photos/600/400',
 'right',
 3,
 'Contact Us',
 '/contact.php'),

('Quality Assurance', 
 'ISO Certified Products',
 'All our products undergo rigorous quality testing and comply with international standards, providing you with reliable and durable solutions.',
 'https://picsum.photos/600/400',
 'left',
 4,
 'View Certifications',
 '/about.php'),

('Nationwide Coverage', 
 'Serving All Emirates',
 'With our extensive network, we provide prompt service across UAE, ensuring minimal downtime and maximum efficiency for your operations.',
 'https://picsum.photos/600/400',
 'right',
 5,
 'Our Locations',
 '/contact.php'),

('Customer Success', 
 'Trusted by Industry Leaders',
 'Join our growing list of satisfied clients who trust Al Safa for their flow measurement needs. We pride ourselves on building long-term relationships through excellent service.',
 'https://picsum.photos/600/400',
 'left',
 6,
 'Read Testimonials',
 '/about.php');

-- Sample data for about page sections
INSERT INTO about_sections (title, content, image_url, section_order) VALUES
('Our Legacy',
 'Since our establishment, Al Safa has been at the forefront of providing innovative flow measurement solutions across the UAE. Our journey is marked by continuous improvement and dedication to excellence.',
 'https://picsum.photos/600/400',
 1),

('Our Expertise',
 'With a team of highly skilled professionals and state-of-the-art facilities, we specialize in providing comprehensive flow measurement solutions tailored to your specific needs.',
 'https://picsum.photos/600/400',
 2),

('Quality Commitment',
 'We maintain the highest standards of quality in all our products and services, backed by international certifications and rigorous testing procedures.',
 'https://picsum.photos/600/400',
 3); 