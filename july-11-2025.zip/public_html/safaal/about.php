<?php include 'includes/header.php'; ?>

<main>
    <!-- About Hero Section -->
    <section class="about-hero bg-light py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1>About Al Safa</h1>
                    <p class="lead">Leading Provider of Diesel Flow Meters & Spares in UAE</p>
                </div>
                <div class="col-md-6">
                    <img src="/assets/img/AME.jpg" alt="About Al Safa" class="img-fluid rounded">
                </div>
            </div>
        </div>
    </section>

    <!-- Dynamic About Sections -->
    <?php
    $about_sql = "SELECT * FROM about_sections ORDER BY section_order";
    $about_result = $conn->query($about_sql);

    while($section = $about_result->fetch_assoc()):
    ?>
    <section class="py-5 <?php echo $section['section_order'] % 2 === 0 ? 'bg-light' : ''; ?>">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 <?php echo $section['section_order'] % 2 === 0 ? 'order-md-2' : ''; ?>">
                    <h2><?php echo htmlspecialchars($section['title']); ?></h2>
                    <div class="mt-4">
                        <?php echo nl2br(htmlspecialchars($section['content'])); ?>
                    </div>
                </div>
                <div class="col-md-6 <?php echo $section['section_order'] % 2 === 0 ? 'order-md-1' : ''; ?>">
                    <img src="<?php echo htmlspecialchars($section['image_url']); ?>" 
                         alt="<?php echo htmlspecialchars($section['title']); ?>" 
                         class="img-fluid rounded shadow">
                </div>
            </div>
        </div>
    </section>
    <?php endwhile; ?>
</main>

<?php include 'includes/footer.php'; ?> 