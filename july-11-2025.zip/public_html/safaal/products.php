<?php 
include 'includes/header.php';

// Fetch categories
$cat_sql = "SELECT * FROM categories ORDER BY name";
$categories = $conn->query($cat_sql);

// Store categories in array for reuse
$categories_array = [];
while($cat = $categories->fetch_assoc()) {
    $categories_array[] = $cat;
}

// Fetch products
$prod_sql = "SELECT p.*, c.name as category_name, c.slug as category_slug 
             FROM products p
             JOIN categories c ON p.category_id = c.id
             WHERE p.is_active = 1
             ORDER BY c.name, p.title";
$products = $conn->query($prod_sql);
?>

<main>
    <section class="py-5">
        <div class="container">
            <h1 class="text-center mb-5">Our Products & Spares</h1>
            
            <!-- Category Filter -->
            <div class="mb-4 text-center">
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-outline-primary active" data-filter="all">All Products</button>
                    <?php foreach($categories_array as $cat): ?>
                        <button type="button" class="btn btn-outline-primary" 
                                data-filter="<?php echo htmlspecialchars($cat['slug']); ?>">
                            <?php echo htmlspecialchars($cat['name']); ?>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Products Grid -->
            <div class="row g-4" id="products-grid">
                <?php while($product = $products->fetch_assoc()): ?>
                    <div class="col-md-4 product-item" data-category="<?php echo htmlspecialchars($product['category_slug']); ?>">
                        <div class="card h-100">
                            <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
                                 class="card-img-top" 
                                 alt="<?php echo htmlspecialchars($product['title']); ?>"
                                 style="cursor: pointer;"
                                 onclick="showProductModal(<?php echo $product['id']; ?>)">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($product['title']); ?></h5>
                                <p class="card-text"><?php echo htmlspecialchars($product['short_description']); ?></p>
                                <button class="btn btn-primary" 
                                        onclick="showProductModal(<?php echo $product['id']; ?>)">
                                    View Details
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <!-- Product Modal -->
    <div class="modal fade" id="productModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <!-- Content will be loaded dynamically -->
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?> 