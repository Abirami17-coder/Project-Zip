<?php include 'includes/header.php'; ?>

<main>
    <section class="py-5">
        <div class="container">
            <h1 class="text-center mb-5">Our Gallery</h1>

            <!-- Gallery Filter -->
            <div class="mb-4 text-center">
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-outline-primary active" data-gallery-filter="all">All</button>
                    <button type="button" class="btn btn-outline-primary" data-gallery-filter="Products">Products</button>
                    <button type="button" class="btn btn-outline-primary" data-gallery-filter="Services">Services</button>
                    <button type="button" class="btn btn-outline-primary" data-gallery-filter="Installation">Installation</button>
                </div>
            </div>

            <!-- Gallery Grid -->
            <div class="row g-4" id="gallery-grid">
                <?php
                $gallery_sql = "SELECT * FROM gallery WHERE is_active = 1 ORDER BY created_at DESC";
                $gallery_result = $conn->query($gallery_sql);

                while($image = $gallery_result->fetch_assoc()): ?>
                    <div class="col-md-4 gallery-item" data-category="<?php echo htmlspecialchars($image['category']); ?>">
                        <div class="card h-100">
                            <img src="<?php echo htmlspecialchars($image['image_url']); ?>" 
                                 class="card-img-top gallery-image" 
                                 alt="<?php echo htmlspecialchars($image['title']); ?>"
                                 data-bs-toggle="modal"
                                 data-bs-target="#imageModal"
                                 data-full-image="<?php echo htmlspecialchars($image['image_url']); ?>"
                                 data-title="<?php echo htmlspecialchars($image['title']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($image['title']); ?></h5>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <!-- Image Modal -->
    <div class="modal fade" id="imageModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <img src="" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?> 