<?php
// define('DB_HOST', 'localhost');
// define('DB_USER', 'root');
// define('DB_PASS', '');
// define('DB_NAME', 'safaal_db');

define('DB_HOST', 'sdb-79.hosting.stackcp.net');
define('DB_USER', 'safaal_db-353038330581');
define('DB_PASS', '99c2zoktjm');
define('DB_NAME', 'safaal_db-353038330581');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 