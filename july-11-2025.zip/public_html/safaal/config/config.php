<?php
// Base URL configuration
define('BASE_URL', 'https://safaal.mjit.in'); // Change this according to your setup

// Site settings
define('SITE_NAME', 'Al Safa Measurement Equipments');
define('SITE_DESCRIPTION', 'Al Safa Measuring Equipments (AME) - Leading provider of diesel flow meters, water pumps, and fuel dispensing solutions in UAE. ISO-certified equipment and professional calibration services.');

// Email settings
define('ADMIN_EMAIL', 'Sales@safaal.com');

// Other global settings can be added here 