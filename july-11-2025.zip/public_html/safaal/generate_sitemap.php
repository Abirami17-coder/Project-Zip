<?php
require_once 'config/config.php';
require_once 'config/database.php';

// Start output buffering
ob_start();

// Begin XML
echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

// Function to add a URL to the sitemap
function addUrl($loc, $lastmod = null, $changefreq = 'monthly', $priority = '0.5') {
    echo '<url>';
    echo '<loc>' . htmlspecialchars($loc, ENT_XML1, 'UTF-8') . '</loc>';
    if ($lastmod) {
        echo '<lastmod>' . htmlspecialchars($lastmod, ENT_XML1, 'UTF-8') . '</lastmod>';
    }
    echo '<changefreq>' . htmlspecialchars($changefreq, ENT_XML1, 'UTF-8') . '</changefreq>';
    echo '<priority>' . htmlspecialchars($priority, ENT_XML1, 'UTF-8') . '</priority>';
    echo '</url>';
}

// Add static pages
addUrl(BASE_URL . '/', date('Y-m-d'), 'weekly', '1.0');
addUrl(BASE_URL . '/about.php', date('Y-m-d'), 'monthly', '0.8');
addUrl(BASE_URL . '/products.php', date('Y-m-d'), 'weekly', '0.9');
addUrl(BASE_URL . '/gallery.php', date('Y-m-d'), 'weekly', '0.7');
addUrl(BASE_URL . '/contact.php', date('Y-m-d'), 'monthly', '0.8');

// Add product pages
$products_sql = "SELECT slug, created_at FROM products WHERE is_active = 1";
$products_result = $conn->query($products_sql);

if ($products_result && $products_result->num_rows > 0) {
    while ($product = $products_result->fetch_assoc()) {
        $slug = urlencode($product['slug']);
        $lastmod = $product['created_at'] ? date('Y-m-d', strtotime($product['created_at'])) : date('Y-m-d');
        addUrl(BASE_URL . '/product.php?slug=' . $slug, $lastmod, 'weekly', '0.6');
    }
}

// Add category pages
$categories_sql = "SELECT slug FROM categories";
$categories_result = $conn->query($categories_sql);

if ($categories_result && $categories_result->num_rows > 0) {
    while ($category = $categories_result->fetch_assoc()) {
        $slug = urlencode($category['slug']);
        addUrl(BASE_URL . '/category.php?slug=' . $slug, date('Y-m-d'), 'weekly', '0.7');
    }
}

// Close XML
echo '</urlset>';

// Get XML output from buffer
$sitemapXml = ob_get_clean();

// Save to sitemap.xml
$filePath = __DIR__ . '/sitemap.xml';
file_put_contents($filePath, $sitemapXml);

// Optional: Output success message
echo "Sitemap generated successfully: <a href='sitemap.xml' target='_blank'>View sitemap.xml</a>";
?>
