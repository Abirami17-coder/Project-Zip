<?php
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $phone = filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
    $message = filter_var($_POST['message'], FILTER_SANITIZE_STRING);
    
    // Validate inputs
    if (empty($name) || empty($email) || empty($phone) || empty($message)) {
        die(json_encode([
            'success' => false,
            'message' => 'All fields are required'
        ]));
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die(json_encode([
            'success' => false,
            'message' => 'Invalid email format'
        ]));
    }
    
    // Save to database
    $sql = "INSERT INTO enquiries (name, email, phone, message) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $email, $phone, $message);
    
    if ($stmt->execute()) {
        // Send email to admin
        $to_admin = $company['email'];
        $subject = "New Contact Form Submission";
        $admin_message = "New contact form submission:\n\n";
        $admin_message .= "Name: $name\n";
        $admin_message .= "Email: $email\n";
        $admin_message .= "Phone: $phone\n";
        $admin_message .= "Message: $message\n";
        
        mail($to_admin, $subject, $admin_message);
        
        // Send confirmation email to user
        $user_subject = "Thank you for contacting Al Safa";
        $user_message = "Dear $name,\n\n";
        $user_message .= "Thank you for contacting Al Safa. We have received your message and will get back to you shortly.\n\n";
        $user_message .= "Best regards,\nAl Safa Team";
        
        mail($email, $user_subject, $user_message);
        
        echo json_encode([
            'success' => true,
            'message' => 'Thank you for your message. We will contact you soon.'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error saving your message. Please try again.'
        ]);
    }
} 