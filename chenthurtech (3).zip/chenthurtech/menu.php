<nav class="py-[31px] bg-black fixed top-0 left-0 right-0 z-50">
	<div class="container-fluid">
		<div class="flex items-center justify-between">
			<!-- Logo -->
			<a href="<?php echo $systemHostlink; ?>" class="text-[26px] font-light text-white">
				<img src="<?php echo $systemHostlink; ?>uploads/logo.png" alt="" class="max-h-[55px]">
			</a>
			
			<!-- Links -->
			<ul class="lg:flex hidden items-center gap-[38px]">
				<li><a href="<?php echo $systemHostlink; ?>index.php" class="text-base font-medium text-white transition hover:text-primary-500">Ecommerce App</a></li>
				<li><a href="<?php echo $systemHostlink; ?>matrimony.php" class="text-base font-medium text-white transition hover:text-primary-500">Matrimony App</a></li>
				<li><a href="<?php echo $systemHostlink; ?>gst.php" class="text-base font-medium text-white transition hover:text-primary-500">GST POS</a></li>
				<li><a href="<?php echo $systemHostlink; ?>sms.php" class="text-base font-medium text-white transition hover:text-primary-500">Bulk SMS</a></li>
				<li><a href="<?php echo $systemHostlink; ?>payment-gateway.php" target="_blank" class="text-base font-medium text-white transition hover:text-primary-500">Payment Gateway</a></li>
				<li><a href="<?php echo $systemHostlink; ?>contact.php" class="text-base font-medium text-white transition hover:text-primary-500">Contact Us</a></li>
			</ul>
			
			<!-- Right -->
			<div class="space-x-2">
				<a href="#" class="bg-green-500 rounded-full h-[41px] px-[24px] text-base font-medium text-white leading-[41px] transition hover:opacity-90 lg:inline-block hidden">Schedule Demo</a>
				
				<button type="button" onclick="toggleMenu()" class="bg-primary-500 rounded-full w-[44px] h-[44px] text-center text-base font-medium text-white leading-[46px] transition hover:opacity-90 inline-block text-[24px] lg:hidden"><i class='bx bx-menu'></i></button>
			</div>
			
			<div class="transition top-0 w-full h-[100vh] fixed z-50 -left-[9999%] bg-black" id="mobileMenu">
				<div class="container">
					<div class="flex items-center justify-between pt-[31px] pb-5 mb-5">
						<img src="<?php echo $systemHostlink; ?>uploads/logo.png" alt="" class="max-h-[55px]">
						
						<button class="bg-primary-500 rounded-full w-[44px] h-[44px] text-center text-base font-medium text-white leading-[46px] transition hover:opacity-90 inline-block text-[24px]" onclick="toggleMenu()">
							<i class='bx bx-x'></i>
						</button>
					</div>
					
					<ul class="mb-5 space-y-5">
						<li><a href="<?php echo $systemHostlink; ?>" class="text-xl font-medium text-white transition hover:text-primary-500" onclick="toggleMenu()">Home</a></li>
						<li><a href="<?php echo $systemHostlink; ?>#features" class="text-xl font-medium text-white transition hover:text-primary-500" onclick="toggleMenu()">Features</a></li>
						<li><a href="<?php echo $systemHostlink; ?>#stores" class="text-xl font-medium text-white transition hover:text-primary-500" onclick="toggleMenu()">Our Stores</a></li>
						<li><a href="<?php echo $systemHostlink; ?>#contact" class="text-xl font-medium text-white transition hover:text-primary-500" onclick="toggleMenu()">Pricing</a></li>
					</ul>
					
					<!-- Button -->
					<div class="flex flex-wrap items-center gap-3">
						<a href="#" class="bg-green-500 rounded-full h-[41px] px-[24px] text-base font-medium text-white leading-[41px] transition hover:opacity-90 inline-block">Schedule Demo</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</nav>