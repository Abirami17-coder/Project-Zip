<?php
	
	include("init.php");	
	
	$name = $_POST['name'];	
	$mobile = $_POST['mobile'];	
	$business = $_POST['business'];	
	$message = $_POST['message'];	
	
	//send mail
	$content = "Name - " . $name . "<br> Mobile - " . $mobile . "<br> Business - " . $business . "<br> Message - " . $message ."
	
	<br><br><br>
	Best Regards,<br>
	" . $companyAddress . "<br>";
	
	$subject = "Enquiry Details - " . $websiteTitle;
	$to = $adminMailId;
	
	$mailController->sendMail( $to, $subject, $content );
	echo 1;
	exit();
?>