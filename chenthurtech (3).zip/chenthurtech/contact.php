<?php
include("init.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<?php include("head.php"); ?>

	<!-- Primary Meta Tags -->
	<title>Contact Us | Get in Touch with ChenthurTech</title>
	<meta name="title" content="Contact ChenthurTech - Support, Sales & Inquiries" />
	<meta name="description"
		content="Have questions about ChenthurTech's online store builder or payment gateway? Contact our support, sales, or general inquiry teams. We're here to help you build your dream online business." />
	<meta name="keywords"
		content="contact us, chenthurtech contact, support, customer service, sales inquiry, online store help, payment gateway support, contact information, reach out, get in touch" />

	<!-- Open Graph / Facebook -->
	<meta property="og:type" content="website" />
	<meta property="og:url" content="<?php echo $websiteTitle; ?>" />
	<meta property="og:title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
	<meta property="og:description"
		content="Plan to Start an Online Ecommerce Store ? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 2 mins!. No coding requires!.Best Shopify Alternative for small medium business owners" />
	<meta property="og:image" content="<?php echo $systemHostlink; ?>uploads/favicon.png" />

	<!-- Twitter -->
	<meta property="twitter:card" content="summary_large_image" />
	<meta property="twitter:url" content="<?php echo $websiteTitle; ?>" />
	<meta property="twitter:title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
	<meta property="twitter:description"
		content="Plan to Start an Online Ecommerce Store ? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 5 mins!. No coding requires!." />
	<meta property="twitter:image" content="<?php echo $systemHostlink; ?>uploads/logo.png" />

</head>

<body class="text-white bg-black">

	<!-- Navbar -->
	<?php include("menu.php"); ?>

	<section
		class="bg-[#0A0A0A] py-28 relative before:absolute before:top-0 before:left-0 before:bg-[#32CAFD] before:w-[150px] before:h-[150px] before:blur-[250px] after:absolute after:bottom-10 after:right-0 after:bg-[#C11DD4] after:w-[150px] after:h-[150px] after:blur-[250px] before:-z-[1] after:-z-[1] z-[1]"
		id="contact">
		<div class="container">
			<div class="mx-auto text-center max-w-[750px] mb-[50px]">
				<h3 class="text-[40px] font-bold leading-[140%] text-white">
					Let’s <span class="text-[#41DB78]">Connect</span> and Build Something Great to<span
						class="text-[#369BF8]">Contact Us</span> Get Started
				</h3>

				<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]"> Contact us and get your personalized
					demo and start your IT Journey</p>
			</div>
		</div>
	</section>

	<!-- Contact Form Section -->
	<div class="flex justify-center items-center w-full">
		<div class="p-8 bg-white rounded-lg shadow text-black">
			<form id="form-2" class="space-y-8">
				<div>
					<label for="name" class="block mb-3 text-base font-medium">Your Name</label>
					<input type="text"
						class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
						name="name" id="name" placeholder="Enter your name">
				</div>

				<div>
					<label for="mobile" class="block mb-3 text-base font-medium">Your Mobile</label>
					<input type="number"
						class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
						name="mobile" id="mobile" placeholder="Enter your mobile">
				</div>

				<div>
					<label for="email" class="block mb-3 text-base font-medium">Your Email</label>
					<input type="email"
						class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
						name="email" id="email" placeholder="Enter your email">
				</div>

				<div>
					<label for="whatsapp" class="block mb-3 text-base font-medium">Your Whatsapp</label>
					<input type="number"
						class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
						name="whatsapp" id="whatsapp" placeholder="Enter your whatsapp">
				</div>

				<div>
					<label for="business" class="block mb-3 text-base font-medium">Your Business
						Information</label>
					<input type="text"
						class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
						name="business" id="business" placeholder="Enter your business">
				</div>

				<div>
					<label for="message" class="block mb-3 text-base font-medium">Message</label>
					<textarea
						class="w-full px-4 py-3 text-base font-medium transition border-2 bg-[#e5e7eb] rounded-lg focus:border-primary"
						placeholder="Enter your message" name="message" id="message" rows="8"></textarea>
				</div>

				<p>
					<small>
						Please enter your information, so that our team can provide your the best solution
					</small>
				</p>
				<button type="submit" name="submit"
					class="w-full px-4 py-3 text-white bg-primary-500 rounded-md hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-600"
					onclick="sendMail()">Submit</button>
			</form>
		</div>
	</div>
	</div>


	<section id="contact" class="py-10" itemscope itemtype="https://schema.org/FAQPage">
		<div class="container">
			<div class="mx-auto text-center max-w-[700px] mb-[70px]">
				<h3 class="text-[40px] font-bold leading-[140%] text-white">Contact <span
						class="text-[#41DB78]">Us</span></h3>
				<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">Have questions or need help? We're here
					for you!</p>
			</div>
			<div class="grid lg:grid-cols-3 grid-cols-1 sm:grid-cols-2 gap-10">

				<!-- Mobile -->
				<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
					<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Mobile</h3>
					<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
						<p class="text-gray-400 text-2xl flex items-center gap-3" itemprop="text">
							<a href="+917200296443" target="_blank">
								<i class='bx bxs-phone text-[#41DB78] text-3xl'></i> +91 72002 96443
							</a>
						</p>
					</div>
				</div>

				<!-- WhatsApp -->
				<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
					<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Whatsapp</h3>
					<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
						<p class="text-gray-400 text-2xl flex items-center gap-3" itemprop="text">
							<a href="https://wa.link/otkvy7" target="_blank">
								<i class='bx bxl-whatsapp text-[#41DB78] text-3xl'></i> +91 72002 96443
							</a>
						</p>
					</div>
				</div>

				<!-- Email -->
				<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
					<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Email</h3>
					<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
						<p class="text-gray-400 text-2xl flex items-center gap-3" itemprop="text">
							<a href="mailto:info@chenthurtech.com" target="_blank">
								<i class='bx bxs-envelope text-[#41DB78] text-3xl'></i> info@chenthurtech.com
							</a>
						</p>
					</div>
				</div>

			</div>
		</div>
	</section>
	</main>

	<!-- footer -->
	<footer>
		<?php include("footer.php"); ?>
	</footer>

</body>

</html>


<script>
	$(document).ready(function (e) {
		//form-content
		$("#form-1").on('submit', (function (e) {
			e.preventDefault();

			//mobile
			value = document.getElementById("mobile").value.trim();

			if (value == null || value === "") {
				showAlert(3, "Please enter mobile number.");
				document.getElementById("mobile").focus();

				return false;
			} else {
				var validMobile = validateMobileNumber(value);
				if (!validMobile) {
					showAlert(3, "Please enter valid 10 digit mobile number.");
					document.getElementById("mobile").focus();
					return false;
				}
			}

			loadingOpen();

			$.ajax({
				url: "mobile-enquiry-send-mail.php",
				type: "POST",
				contentType: false,
				cache: false,
				processData: false,
				data: new FormData(this),
				success: function (data) {
					data = data.trim();
					if (isNaN(data)) {
						showAlert(2, "Error : " + data);
						loadingClose();
					} else {
						if (data > 0) {
							showAlert(1, "Enquiry sent successfully.");
							loadingClose();
							window.location = "<?php echo $systemHostlink; ?>";
							//location.reload();
						} else {
							showAlert(3, "Error : " + data);
							loadingClose();
						}
					}
				},
				error: function () {
					showAlert(3, "Oops something went wrong. Please try later.");
					loadingClose();
				}
			});

		}));

	});
</script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
<script type="text/javascript">
	(function () {
		emailjs.init("d9_yW4ix6I7rxyv6a");
	})();
</script>

<script>
	function sendMail() {
		event.preventDefault(); // Prevent form from refreshing page

		var params = {

			email: document.getElementById("email").value,
			yourname: document.getElementById("name").value,
			mobile: document.getElementById("mobile").value,
			whatsapp: document.getElementById("whatsapp").value,
			business: document.getElementById("business").value,
			message: document.getElementById("message").value,
		};

		const serviceID = "service_i1nnodg";
		const templateID = "template_t70fp98";

		emailjs.send(serviceID, templateID, params)
			.then(res => {
				// Clear the form fields
				document.getElementById("form-2").reset();
				console.log(res);
				alert("Your message sent successfully!!");
			})
			.catch(err => console.log(err));
	}
</script>

<script>
	$(document).ready(function (e) {
		//form-content
		$("#form-2").on('submit', (function (e) {
			e.preventDefault();

			//name
			value = document.getElementById("name").value.trim();
			if (value == null || value == "") {
				showAlert(3, "Please enter name");
				document.getElementById("name").focus();
				return false;
			} else {
				let name = document.getElementById("name").value.trim();
				if (name.length < 3 || !/^[A-Za-z\s]+$/.test(name)) {
					showAlert(3, "Please enter a valid name with a minimum of 3 characters, only alphabets allowed.");
					document.getElementById("name").focus();
					return false;
				}
			}

			//mobile
			value = document.getElementById("mobile").value.trim();
			if (value == null || value === "") {
				showAlert(3, "Please enter mobile number.");
				document.getElementById("mobile").focus();

				return false;
			} else {
				var validMobile = validateMobileNumber(value);
				if (!validMobile) {
					showAlert(3, "Please enter valid 10 digit mobile number.");
					document.getElementById("mobile").focus();
					return false;
				}
			}

			//business
			value = document.getElementById("business").value.trim();
			if (value == null || value == "") {
				showAlert(3, "Please enter your business");
				document.getElementById("business").focus();
				return false;
			}

			//message
			value = document.getElementById("message").value.trim();
			if (value == null || value == "") {
				showAlert(3, "Please enter message");
				document.getElementById("message").focus();
				return false;
			}

			loadingOpen();

			$.ajax({
				url: "contact-enquiry-send-mail.php",
				type: "POST",
				contentType: false,
				cache: false,
				processData: false,
				data: new FormData(this),
				success: function (data) {
					data = data.trim();
					if (isNaN(data)) {
						showAlert(2, "Error : " + data);
						loadingClose();
					} else {
						if (data > 0) {
							showAlert(1, "Enquiry sent successfully.");
							loadingClose();
							window.location = "<?php echo $systemHostlink; ?>";
							//location.reload();
						} else {
							showAlert(3, "Error : " + data);
							loadingClose();
						}
					}
				},
				error: function () {
					showAlert(3, "Oops something went wrong. Please try later.");
					loadingClose();
				}
			});

		}));

	});
</script>