<?php
include("init.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include("head.php"); ?>

    <!-- Primary Meta Tags -->
    <title>BulkSms - Your Dream Online Store within 2 mins | ChenthurTech</title>
    <meta name="title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
    <meta name="description"
        content="Plan to Start an Online Ecommerce Store? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 2 mins!. No coding requires!.Best Shopify alternative for small medium business owners." />

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website" />
    <meta property="og:url" content="<?php echo $websiteTitle; ?>" />
    <meta property="og:title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
    <meta property="og:description"
        content="Plan to Start an Online Ecommerce Store ? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 2 mins!. No coding requires!.Best Shopify Alternative for small medium business owners" />
    <meta property="og:image" content="<?php echo $systemHostlink; ?>uploads/favicon.png" />

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image" />
    <meta property="twitter:url" content="<?php echo $websiteTitle; ?>" />
    <meta property="twitter:title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
    <meta property="twitter:description"
        content="Plan to Start an Online Ecommerce Store ? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 5 mins!. No coding requires!." />
    <meta property="twitter:image" content="<?php echo $systemHostlink; ?>uploads/logo.png" />

</head>

<body class="text-white bg-black">

    <!-- Navbar -->
    <?php include("menu.php"); ?>

    <main class="min-h-[calc(100vh-251.98px)]">
        <!-- Hero section -->



        <section id="faq" class="py-28" itemscope itemtype="https://schema.org/FAQPage">
            <div class="container">
                <div class="mx-auto text-center max-w-[700px] mb-[70px]">
                    <h3 class="text-[40px] font-bold leading-[140%] text-white">Refund <span
                            class="text-[#41DB78]">Policy</span></h3>
                </div>


                <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
                    <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
                        <h3 class="mt-4 text-lg text-white min-h-[96px] w-full" itemprop="name">
                            Refund for Courses / Long Sessions:
                        </h3>
                        <div class=" text-gray-400 p-6 rounded-lg w-full mt-4">
                            <div class="space-y-2  w-full">
                                <p>1. Refund must be applied before 10% of the course duration and the learner must have attendened the 10% od the course or session for the refund eligibility.</p>
                                <p>2. Once refund is requested the learner will not be able to attended the course or session.</p>
                                <p>3. The refund will be completed in 7 working days</p>
                                <p>4. Refund amount will send after deducting the number of days attended in the course / session
                                </p>
                            </div>
                        </div>
                        <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
                            <h3 class="mt-4 text-lg text-white min-h-[96px] w-full" itemprop="name">
                                Refund for Seminars and Workshops:
                            </h3>
                            <div class=" text-gray-400 p-6 rounded-lg w-full mt-4">
                            <div class="space-y-2  w-full">
                                <p>1. There will be no refund for seminars and workshops.</p>
                               
                            </div>
                            <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
                            <h3 class="mt-4 text-lg text-white min-h-[96px] w-full" itemprop="name">
                              General:  
                            </h3>
                            <div class=" text-gray-400 p-6 rounded-lg w-full mt-4">
                            <div class="space-y-2  w-full">
                                <p>1.All refunds will be done in 7 working days</p>
                                <p>2. All refunds will be done digitally only [no cash refunds]</p>
                               
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- footer -->
    </main>

    <footer>
        <?php include("footer.php"); ?>
    </footer>


</body>

</html>


<script>
    $(document).ready(function (e) {
        //form-content
        $("#form-1").on('submit', (function (e) {
            e.preventDefault();

            //mobile
            value = document.getElementById("mobile").value.trim();

            if (value == null || value === "") {
                showAlert(3, "Please enter mobile number.");
                document.getElementById("mobile").focus();

                return false;
            } else {
                var validMobile = validateMobileNumber(value);
                if (!validMobile) {
                    showAlert(3, "Please enter valid 10 digit mobile number.");
                    document.getElementById("mobile").focus();
                    return false;
                }
            }

            loadingOpen();

            $.ajax({
                url: "mobile-enquiry-send-mail.php",
                type: "POST",
                contentType: false,
                cache: false,
                processData: false,
                data: new FormData(this),
                success: function (data) {
                    data = data.trim();
                    if (isNaN(data)) {
                        showAlert(2, "Error : " + data);
                        loadingClose();
                    } else {
                        if (data > 0) {
                            showAlert(1, "Enquiry sent successfully.");
                            loadingClose();
                            window.location = "<?php echo $systemHostlink; ?>";
                            //location.reload();
                        } else {
                            showAlert(3, "Error : " + data);
                            loadingClose();
                        }
                    }
                },
                error: function () {
                    showAlert(3, "Oops something went wrong. Please try later.");
                    loadingClose();
                }
            });

        }));

    });
</script>

<script>
    $(document).ready(function (e) {
        //form-content
        $("#form-2").on('submit', (function (e) {
            e.preventDefault();

            //name
            value = document.getElementById("name").value.trim();
            if (value == null || value == "") {
                showAlert(3, "Please enter name");
                document.getElementById("name").focus();
                return false;
            } else {
                let name = document.getElementById("name").value.trim();
                if (name.length < 3 || !/^[A-Za-z\s]+$/.test(name)) {
                    showAlert(3, "Please enter a valid name with a minimum of 3 characters, only alphabets allowed.");
                    document.getElementById("name").focus();
                    return false;
                }
            }

            //mobile
            value = document.getElementById("mobile").value.trim();
            if (value == null || value === "") {
                showAlert(3, "Please enter mobile number.");
                document.getElementById("mobile").focus();

                return false;
            } else {
                var validMobile = validateMobileNumber(value);
                if (!validMobile) {
                    showAlert(3, "Please enter valid 10 digit mobile number.");
                    document.getElementById("mobile").focus();
                    return false;
                }
            }

            //business
            value = document.getElementById("business").value.trim();
            if (value == null || value == "") {
                showAlert(3, "Please enter your business");
                document.getElementById("business").focus();
                return false;
            }

            //message
            value = document.getElementById("message").value.trim();
            if (value == null || value == "") {
                showAlert(3, "Please enter message");
                document.getElementById("message").focus();
                return false;
            }

            loadingOpen();

            $.ajax({
                url: "contact-enquiry-send-mail.php",
                type: "POST",
                contentType: false,
                cache: false,
                processData: false,
                data: new FormData(this),
                success: function (data) {
                    data = data.trim();
                    if (isNaN(data)) {
                        showAlert(2, "Error : " + data);
                        loadingClose();
                    } else {
                        if (data > 0) {
                            showAlert(1, "Enquiry sent successfully.");
                            loadingClose();
                            window.location = "<?php echo $systemHostlink; ?>";
                            //location.reload();
                        } else {
                            showAlert(3, "Error : " + data);
                            loadingClose();
                        }
                    }
                },
                error: function () {
                    showAlert(3, "Oops something went wrong. Please try later.");
                    loadingClose();
                }
            });

        }));

    });
</script>