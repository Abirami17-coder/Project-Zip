<?php
	
	include("init.php");
	
	
	$mobile = $_POST['mobile'];	
	
	//send mail
	$content = "Mobile - " . $mobile ."
	
	<br><br><br>
	Best Regards,<br>
	" . $companyAddress . "<br>";
	
	$subject = "Enquiry Details - " . $websiteTitle;
	$to = $adminMailId;
	
	$mailController->sendMail( $to, $subject, $content );
	echo 1;
	exit();
?>