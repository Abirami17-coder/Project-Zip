<?php
include("init.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<?php include("head.php"); ?>

	<!-- Primary Meta Tags -->
	<title>GST POS Billing Software for Small Business | ChenthurTeck</title>
	<meta name="description"
		content="ChenthurTeck GST POS is a simple and easy billing software for shops and small businesses. Fast GST billing, invoice printing, and sales tracking – all in one place." />
	<meta name="keywords"
		content="GST POS, Billing Software, GST Billing, POS System, Shop Billing, Small Business Software, Invoice Software, ChenthurTeck POS" />
	<!-- Open Graph / Facebook -->
	<meta property="og:type" content="website" />
	<meta property="og:url" content="<?php echo $websiteTitle; ?>" />
	<meta property="og:title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
	<meta property="og:description"
		content="Plan to Start an Online Ecommerce Store ? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 2 mins!. No coding requires!.Best Shopify Alternative for small medium business owners" />
	<meta property="og:image" content="<?php echo $systemHostlink; ?>uploads/favicon.png" />

	<!-- Twitter -->
	<meta property="twitter:card" content="summary_large_image" />
	<meta property="twitter:url" content="<?php echo $websiteTitle; ?>" />
	<meta property="twitter:title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
	<meta property="twitter:description"
		content="Plan to Start an Online Ecommerce Store ? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 5 mins!. No coding requires!." />
	<meta property="twitter:image" content="<?php echo $systemHostlink; ?>uploads/logo.png" />

</head>

<body class="text-white bg-black">

	<!-- Navbar -->
	<?php include("menu.php"); ?>

	<main class="min-h-[calc(100vh-251.98px)]">
		<!-- Hero section -->
		<div
			class="lg:min-h-[750px] py-5 lg:py-0 flex items-center relative before:absolute before:top-0 before:left-0 before:bg-[#C11DD4] before:w-[250px] before:h-[10px] before:blur-[250px] after:absolute after:bottom-0 after:right-0 after:bg-[#32CAFD] after:w-[250px] after:h-[250px] after:blur-[250px] before:-z-[1] after:-z-[1] z-[1] home-section-1">
			<div class="container">
				<div class="items-center justify-between lg:flex">
					<div class="w-full max-w-[650px]" style="margin-bottom:40px !important">
						<h1 class="text-white text-[48px] font-bold leading-[135%]">Get Your <span
								class="text-primary-500">GST Billing - POS </span> software today</h1>

						<p class="text-2xl font-medium leading-[135%] text-[#BDBDBD] mt-[22px]">Get your <b
								class="text-white"> website + hosting + domain + android app </b> as all in one package.
						</p>

						<!-- Input -->
						<form id="form-1"
							class="h-[74px] leading-[74px] bg-[#1B1B1B] px-[25px] rounded-full max-w-[500px] w-full mt-[38px] relative">
							<button type="submit"
								class="bg-primary-500 rounded-full px-8 h-[56px] text-white leading-[56px] lg:absolute lg:top-[50%] lg:right-[10px] lg:-translate-y-[50%] text-[18px] font-medium w-full lg:w-[unset] w-100">Get
								Details</button>
						</form>
					</div>

					<div class="hidden lg:block">
						<img src="<?php echo $systemHostlink; ?>uploads/banner-img.png" alt="" class="w-full">
					</div>
				</div>
			</div>
		</div>

		<!-- GST POS Examples Section with Enhanced Hover Zoom Effect -->
		<section id="templates" class="bg-[#0A0A0A] py-20">
			<div class="container mx-auto px-4">
				<div class="mx-auto text-center max-w-[700px] mb-[70px]">
					<h3 class="text-[40px] font-bold leading-[140%] text-white">
						Solution for <span class="text-[#FF9458]">every</span> <span
							class="text-[#FB62B7]">business</span>
					</h3>
					<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">EXPLORE GST POS EXAMPLES</p>
				</div>
				<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
					<!-- Example image block -->
					<img src="https://vyaparapp.in/v/z/wp-content/uploads/2024/09/POS-Software-Hero-Image-1-scaled.webp"
						alt="GST POS Screenshot"
						class="rounded-xl shadow-lg w-full h-auto transform transition duration-300 ease-in-out hover:scale-110 hover:-translate-y-1 hover:brightness-110 hover:shadow-2xl cursor-pointer" />

					<!-- Repeat for all images -->
					<img src="https://justbilling.in/wp-content/uploads/2024/05/Just-Billing-Best-POS-Software-1024x525-1.webp"
						alt="GST POS Screenshot"
						class="rounded-xl shadow-lg w-full h-auto transform transition duration-300 ease-in-out hover:scale-110 hover:-translate-y-1 hover:brightness-110 hover:shadow-2xl cursor-pointer" />

					<img src="https://www.lithospos.com/themes/lithos-pos/assets/images/ipad-payment.jpg"
						alt="GST POS Screenshot"
						class="rounded-xl shadow-lg w-full h-auto transform transition duration-300 ease-in-out hover:scale-110 hover:-translate-y-1 hover:brightness-110 hover:shadow-2xl cursor-pointer" />

					<img src="https://brightinventions.pl/images/establish-button-hierarchy.png"
						alt="GST POS Screenshot"
						class="rounded-xl shadow-lg w-full h-auto transform transition duration-300 ease-in-out hover:scale-110 hover:-translate-y-1 hover:brightness-110 hover:shadow-2xl cursor-pointer" />

					<img src="https://wallacepos.com/images/terminal-transaction.png" alt="GST POS Screenshot"
						class="rounded-xl shadow-lg w-full h-auto transform transition duration-300 ease-in-out hover:scale-110 hover:-translate-y-1 hover:brightness-110 hover:shadow-2xl cursor-pointer" />

					<img src="https://www.gofrugal.com/sites/gweb/files/gofrugal/images/retail/supermarket-groceries/supermarket-tab-screen.webp"
						alt="GST POS Screenshot"
						class="rounded-xl shadow-lg w-full h-auto transform transition duration-300 ease-in-out hover:scale-110 hover:-translate-y-1 hover:brightness-110 hover:shadow-2xl cursor-pointer" />

					<img src="https://hikeup.com/wp-content/uploads/2021/12/enter-sale-ipad-screen-v1-e1512992013964.png"
						alt="GST POS Screenshot"
						class="rounded-xl shadow-lg w-full h-auto transform transition duration-300 ease-in-out hover:scale-110 hover:-translate-y-1 hover:brightness-110 hover:shadow-2xl cursor-pointer" />

					<img src="https://learn.microsoft.com/en-us/dynamics365/commerce/localizations/media/apac-ind-gst-pos-customer-order.png"
						alt="GST POS Screenshot"
						class="rounded-xl shadow-lg w-full h-auto transform transition duration-300 ease-in-out hover:scale-110 hover:-translate-y-1 hover:brightness-110 hover:shadow-2xl cursor-pointer" />
				</div>
			</div>
		</section>


		<!-- Last but not least -->
		<section class="bg-[#0A0A0A] py-28" id="features">
			<div class="container">
				<div class="mx-auto text-center max-w-[500px] mb-[70px]">
					<h3 class="text-[40px] font-bold leading-[140%] text-white">Our <span class="text-[#FF9458]">GST
							POS</span> <span class="text-[#FB62B7]">Features</span></h3>

					<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">A fully featured eCommerce Platform
					</p>
				</div>

				<div class="grid grid-cols-2 gap-5 sm:grid-cols-3 xl:grid-cols-7 lg:grid-cols-5">
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/easy-to-use.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Easy to use and efficient</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/no-code.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">No Code Platform</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/no-app.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">No Additional Apps Requires</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/manage-orders.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Create Bills and Invoices Quickly</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/product-reports.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Quick Business Reports</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/no-skills.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">No Technical Skills Requires</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/no-skills.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">IGST, SGST + CGST Support</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/secure-payment.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Run in Local System</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/customer-based-report.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Customer Based Reports</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/coupon.jpeg" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Simple GST Reports</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/order-track.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Track Payments</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/custom-domain.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Easy Backup Option</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/custom-domain.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">All Reports to Excel</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/custom-domain.png" alt=""
							class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Mulitple Bill Formats</span>
					</div>
				</div>
			</div>
		</section>

		<!-- Feature 1 -->
		<section
			class="bg-[#0A0A0A] py-28 relative before:absolute before:top-0 before:left-0 before:bg-[#32CAFD] before:w-[150px] before:h-[150px] before:blur-[250px] after:absolute after:bottom-10 after:right-0 after:bg-[#C11DD4] after:w-[150px] after:h-[150px] after:blur-[250px] before:-z-[1] after:-z-[1] z-[1]">
			<div class="container">
				<div class="grid lg:grid-cols-2 gap-[75px] items-center">
					<!-- Left -->
					<div>
						<h3 class="text-[40px] font-bold leading-[140%] text-white">Simple and <span
								class="text-[#369BF8]"> Esay to Understand </span> Software UI and Options </h3>

						<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">The UI designed to be simple and
							easily understandable for any business owner without the need of a technical person. Install
							and start using in the first day. The software UI design allows business owners to create
							invoices, enter payments and take reports within few seconds.</p>
					</div>

					<!-- Right -->
					<div class="flex justify-center lg:justify-end">
						<img src="<?php echo $systemHostlink; ?>uploads/feature-1.png" alt=""
							class="w-auto max-h-[307px] object-cover">
					</div>
				</div>
			</div>
		</section>

		<!-- Feature 2 -->
		<section class="py-28">
			<div class="container">
				<div class="grid lg:grid-cols-2 gap-[75px] items-center">
					<!-- Left -->
					<div class="flex justify-center lg:justify-start">
						<img src="<?php echo $systemHostlink; ?>uploads/feature-2.png" alt=""
							class="w-auto max-h-[307px] object-cover">
					</div>

					<!-- Right -->
					<div>
						<h3 class="text-[40px] font-bold leading-[140%] text-white">Easy reporting with <span
								class="text-[#41DB78]"> excel export </span>option</h3>

						<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">All the reports dispaly on the
							GST POS is quickly exportable to Excel sheets so that it can be shared with your auditors,
							business partners or any needed persons.</p>
					</div>
				</div>
			</div>
		</section>



		<section
			class="bg-[#0A0A0A] py-28 relative before:absolute before:top-0 before:left-0 before:bg-[#32CAFD] before:w-[150px] before:h-[150px] before:blur-[250px] after:absolute after:bottom-10 after:right-0 after:bg-[#C11DD4] after:w-[150px] after:h-[150px] after:blur-[250px] before:-z-[1] after:-z-[1] z-[1]"
			id="pricing">
			<div class="container">
				<div class="mx-auto text-center max-w-[750px] mb-[70px]">
					<h3 class="text-[40px] font-bold leading-[140%] text-white">Get started with a <span
							class="text-[#41DB78]">Affordable</span> plan and start your<span class="text-[#369BF8]">
							online business</span></h3>
					<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">Contact us and get your personalized
						demo and start your ecomemrce business soon</p>
				</div>

				<div class="grid grid-cols-1 md:grid-cols-2 gap-5">
					<!-- Pricing Section -->
					<div class="lg:grid-cols-4">
						<div
							class="relative z-10 mb-10 rounded-[10px] border-2 border-stroke dark:border-dark-3 bg-[#121212] border-[#2A2A2A] py-10 px-8 shadow-pricing sm:p-12 lg:py-10 lg:px-6 xl:p-[50px]">
							<div
								class="h-[60px] bg-green-500 text-white absolute -top-[50px] left-0 w-full -z-[1] rounded-t-[10px] text-center font-semibold text-xl flex items-center justify-center">
								Exclusive Deals</div>
							<span class="mb-3 block text-lg font-semibold text-primary-500">GST POS License Life
								Time</span>
							<h2 class="mb-5 text-[30px] font-bold text-dark dark:text-white">
								<span>₹ 15,000</span> Only
							</h2>
							<p
								class="mb-8 border-b border-stroke dark:border-dark-3 pb-8 text-base text-body-color dark:text-dark-6">
								Just install and start using..</p>
							<div class="mb-9 flex flex-col gap-[14px]">
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									GST POS Software Installation
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									IGST, SGST and CGST Support
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Supplier Management
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Customer Management
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Product Catalogue Management
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Sales and Sale Return Management
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Purchase and Purchase Return Management
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Damaged Stock Management
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Expenses Management
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Payment Tracking and reports
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Bill To Bill and Account Wise Payment Tracking
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Auditor Friendly Reports
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									All Reports to Excel
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									A4, A5, Thermal Size Print Options
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Easy Backup Solutions
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
										stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round"
											d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Tele Support
								</p>
							</div>
						</div>
					</div>

					<!-- Contact Form Section -->
					<div class="p-8 bg-white rounded-lg shadow text-black">
						<form id="form-2" class="space-y-8">
							<div>
								<label for="name" class="block mb-3 text-base font-medium">Your Name</label>
								<input type="text"
									class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
									name="name" id="name" placeholder="Enter your name">
							</div>

							<div>
								<label for="mobile" class="block mb-3 text-base font-medium">Your Mobile</label>
								<input type="number"
									class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
									name="mobile" id="mobile" placeholder="Enter your mobile">
							</div>

							<div>
								<label for="email" class="block mb-3 text-base font-medium">Your Email</label>
								<input type="email"
									class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
									name="email" id="email" placeholder="Enter your email">
							</div>

							<div>
								<label for="whatsapp" class="block mb-3 text-base font-medium">Your Whatsapp</label>
								<input type="number"
									class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
									name="whatsapp" id="whatsapp" placeholder="Enter your whatsapp">
							</div>

							<div>
								<label for="business" class="block mb-3 text-base font-medium">Your Business
									Information</label>
								<input type="text"
									class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
									name="business" id="business" placeholder="Enter your business">
							</div>

							<div>
								<label for="message" class="block mb-3 text-base font-medium">Message</label>
								<textarea
									class="w-full px-4 py-3 text-base font-medium transition border-2 bg-[#e5e7eb] rounded-lg focus:border-primary"
									placeholder="Enter your message" name="message" id="message" rows="8"></textarea>
							</div>

							<p>
								<small>
									Please enter your information, so that our team can provide your the best solution
								</small>
							</p>
							<button type="submit" name="submit"
								class="w-full px-4 py-3 text-white bg-primary-500 rounded-md hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-600"
								onclick="sendMail()">Submit</button>
						</form>
					</div>
				</div>
			</div>
		</section>


		<section id="contact" class="py-10" itemscope itemtype="https://schema.org/FAQPage">
			<div class="container">
				<div class="mx-auto text-center max-w-[700px] mb-[70px]">
					<h3 class="text-[40px] font-bold leading-[140%] text-white">Contact <span
							class="text-[#41DB78]">Us</span></h3>
					<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">Have questions or need help? We're
						here for you!</p>
				</div>
				<div class="grid lg:grid-cols-3 grid-cols-1 sm:grid-cols-2 gap-10">

					<!-- Mobile -->
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Mobile</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
							<p class="text-gray-400 text-2xl flex items-center gap-3" itemprop="text">
								<a href="+917200296443" target="_blank">
									<i class='bx bxs-phone text-[#41DB78] text-3xl'></i> +91 72002 96443
								</a>
							</p>
						</div>
					</div>

					<!-- WhatsApp -->
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Whatsapp</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
							<p class="text-gray-400 text-2xl flex items-center gap-3" itemprop="text">
								<a href="https://wa.link/otkvy7" target="_blank">
									<i class='bx bxl-whatsapp text-[#41DB78] text-3xl'></i> +91 72002 96443
								</a>
							</p>
						</div>
					</div>

					<!-- Email -->
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Email</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
							<p class="text-gray-400 text-2xl flex items-center gap-3" itemprop="text">
								<a href="mailto:info@chenthurtech.com" target="_blank">
									<i class='bx bxs-envelope text-[#41DB78] text-3xl'></i> info@chenthurtech.com
								</a>
							</p>
						</div>
					</div>

				</div>
			</div>
		</section>

		<section id="faq" class="py-28" itemscope itemtype="https://schema.org/FAQPage">
			<div class="container">
				<div class="mx-auto text-center max-w-[700px] mb-[70px]">
					<h3 class="text-[40px] font-bold leading-[140%] text-white">
						Frequently asked <span class="text-[#41DB78]">questions</span>
					</h3>
					<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">
						Common questions about GST POS for GST billing and POS businesses.
					</p>
				</div>

				<div class="grid lg:grid-cols-3 grid-cols-1 sm:grid-cols-2 gap-10">

					<!-- Question 1 -->
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">What is GST POS?</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
							<p class="text-gray-400" itemprop="text">
								GST POS is a GST-compliant Point of Sale (POS) solution that helps small and medium
								businesses manage billing, inventory, and customer data with ease. It's ideal for
								grocery stores, clothing shops, and other local businesses.
							</p>
						</div>
					</div>

					<!-- Question 2 -->
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Is GST POS easy to use for GST
							billing?</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
							<p class="text-gray-400" itemprop="text">
								Yes, GST POS is designed for simplicity. You can generate GST invoices, track sales, and
								manage stock without any technical expertise. It’s a no-code solution tailored for
								Indian small businesses.
							</p>
						</div>
					</div>

					<!-- Question 3 -->
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Do I need any technical skills
							to run GST POS?</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
							<p class="text-gray-400" itemprop="text">
								Not at all. GST POS is a user-friendly platform that can be operated with basic computer
								or mobile knowledge. It is built to simplify GST billing for shopkeepers and retailers.
							</p>
						</div>
					</div>

				</div>
			</div>
		</section>

		<!-- footer -->
	</main>

	<footer>
		<?php include("footer.php"); ?>
	</footer>


</body>

</html>


<script>
	$(document).ready(function (e) {
		//form-content
		$("#form-1").on('submit', (function (e) {
			e.preventDefault();

			//mobile
			value = document.getElementById("mobile").value.trim();

			if (value == null || value === "") {
				showAlert(3, "Please enter mobile number.");
				document.getElementById("mobile").focus();

				return false;
			} else {
				var validMobile = validateMobileNumber(value);
				if (!validMobile) {
					showAlert(3, "Please enter valid 10 digit mobile number.");
					document.getElementById("mobile").focus();
					return false;
				}
			}

			loadingOpen();

			$.ajax({
				url: "mobile-enquiry-send-mail.php",
				type: "POST",
				contentType: false,
				cache: false,
				processData: false,
				data: new FormData(this),
				success: function (data) {
					data = data.trim();
					if (isNaN(data)) {
						showAlert(2, "Error : " + data);
						loadingClose();
					} else {
						if (data > 0) {
							showAlert(1, "Enquiry sent successfully.");
							loadingClose();
							window.location = "<?php echo $systemHostlink; ?>";
							//location.reload();
						} else {
							showAlert(3, "Error : " + data);
							loadingClose();
						}
					}
				},
				error: function () {
					showAlert(3, "Oops something went wrong. Please try later.");
					loadingClose();
				}
			});

		}));

	});
</script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
<script type="text/javascript">
	(function () {
		emailjs.init("d9_yW4ix6I7rxyv6a");
	})();
</script>

<script>
	function sendMail() {
		event.preventDefault(); // Prevent form from refreshing page

		var params = {

			email: document.getElementById("email").value,
			yourname: document.getElementById("name").value,
			mobile: document.getElementById("mobile").value,
			whatsapp: document.getElementById("whatsapp").value,
			business: document.getElementById("business").value,
			message: document.getElementById("message").value,
		};

		const serviceID = "service_i1nnodg";
		const templateID = "template_t70fp98";

		emailjs.send(serviceID, templateID, params)
			.then(res => {
				// Clear the form fields
				document.getElementById("form-2").reset();
				console.log(res);
				alert("Your message sent successfully!!");
			})
			.catch(err => console.log(err));
	}
</script>

<script>
	$(document).ready(function (e) {
		//form-content
		$("#form-2").on('submit', (function (e) {
			e.preventDefault();

			//name
			value = document.getElementById("name").value.trim();
			if (value == null || value == "") {
				showAlert(3, "Please enter name");
				document.getElementById("name").focus();
				return false;
			} else {
				let name = document.getElementById("name").value.trim();
				if (name.length < 3 || !/^[A-Za-z\s]+$/.test(name)) {
					showAlert(3, "Please enter a valid name with a minimum of 3 characters, only alphabets allowed.");
					document.getElementById("name").focus();
					return false;
				}
			}

			//mobile
			value = document.getElementById("mobile").value.trim();
			if (value == null || value === "") {
				showAlert(3, "Please enter mobile number.");
				document.getElementById("mobile").focus();

				return false;
			} else {
				var validMobile = validateMobileNumber(value);
				if (!validMobile) {
					showAlert(3, "Please enter valid 10 digit mobile number.");
					document.getElementById("mobile").focus();
					return false;
				}
			}

			//business
			value = document.getElementById("business").value.trim();
			if (value == null || value == "") {
				showAlert(3, "Please enter your business");
				document.getElementById("business").focus();
				return false;
			}

			//message
			value = document.getElementById("message").value.trim();
			if (value == null || value == "") {
				showAlert(3, "Please enter message");
				document.getElementById("message").focus();
				return false;
			}

			loadingOpen();

			$.ajax({
				url: "contact-enquiry-send-mail.php",
				type: "POST",
				contentType: false,
				cache: false,
				processData: false,
				data: new FormData(this),
				success: function (data) {
					data = data.trim();
					if (isNaN(data)) {
						showAlert(2, "Error : " + data);
						loadingClose();
					} else {
						if (data > 0) {
							showAlert(1, "Enquiry sent successfully.");
							loadingClose();
							window.location = "<?php echo $systemHostlink; ?>";
							//location.reload();
						} else {
							showAlert(3, "Error : " + data);
							loadingClose();
						}
					}
				},
				error: function () {
					showAlert(3, "Oops something went wrong. Please try later.");
					loadingClose();
				}
			});

		}));

	});
</script>

<script>
	document.addEventListener('DOMContentLoaded', function () {
		// Create the overlay for popup
		const overlay = document.createElement('div');
		overlay.id = 'img-blur-overlay';
		overlay.style.position = 'fixed';
		overlay.style.top = 0;
		overlay.style.left = 0;
		overlay.style.width = '100vw';
		overlay.style.height = '100vh';
		overlay.style.background = 'rgba(0,0,0,0.5)';
		overlay.style.backdropFilter = 'blur(8px)';
		overlay.style.display = 'none';
		overlay.style.alignItems = 'center';
		overlay.style.justifyContent = 'center';
		overlay.style.zIndex = '9999';
		overlay.innerHTML = `
	<img id="img-blur-popup" src="" alt="Preview" style="max-width:90vw;max-height:80vh;border-radius:18px;box-shadow:0 8px 32px #000a;border:6px solid #fff;background:#fff;cursor:pointer;" />
  `;
		document.body.appendChild(overlay);

		// Show overlay and image on click
		document.querySelectorAll('#templates img').forEach(img => {
			img.addEventListener('click', function () {
				document.getElementById('img-blur-popup').src = this.src;
				overlay.style.display = 'flex';
			});
		});

		// Hide overlay when clicking outside the image
		overlay.addEventListener('click', function (e) {
			if (e.target === overlay) {
				overlay.style.display = 'none';
			}
		});
	});
</script>