

<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<link rel="stylesheet" href="<?php echo $systemHostlink; ?>assets/css/style.css">


<link rel="shortcut icon" href="<?php echo $systemHostlink; ?>uploads/logo.png">
<link rel="canonical" href="<?php echo $systemHostlink; ?>">

<style>
	@import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
	
	
	:root {
	--primary-color-500: #D336F8;
	--primary-font: 'Montserrat';
	}
</style>

<!-- Meta Pixel Code -->
<script>
	! function(f, b, e, v, n, t, s) {
		if (f.fbq) return;
		n = f.fbq = function() {
			n.callMethod ?
			n.callMethod.apply(n, arguments) : n.queue.push(arguments)
		};
		if (!f._fbq) f._fbq = n;
		n.push = n;
		n.loaded = !0;
		n.version = '2.0';
		n.queue = [];
		t = b.createElement(e);
		t.async = !0;
		t.src = v;
		s = b.getElementsByTagName(e)[0];
		s.parentNode.insertBefore(t, s)
	}(window, document, 'script',
	'https://connect.facebook.net/en_US/fbevents.js');
	fbq('init', '674693734794365');
	fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=674693734794365&ev=PageView&noscript=1" /></noscript>
<!-- End Meta Pixel Code -->

<!-- Google Tag Manager -->
<script>
	(function(w, d, s, l, i) {
		w[l] = w[l] || [];
		w[l].push({
			'gtm.start': new Date().getTime(),
			event: 'gtm.js'
		});
		var f = d.getElementsByTagName(s)[0],
		j = d.createElement(s),
		dl = l != 'dataLayer' ? '&l=' + l : '';
		j.async = true;
		j.src =
		'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
		f.parentNode.insertBefore(j, f);
	})(window, document, 'script', 'dataLayer', 'GTM-PXR9TRDF');
</script>
<!-- End Google Tag Manager -->
<script type="text/javascript">
	(function(c,l,a,r,i,t,y){
		c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
		t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
		y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
	})(window, document, "clarity", "script", "p8m5vdbei6");
</script>




<!-- cart-alert div -->
<div class="row">
	<div class="col-xs-12">
		<div id="app-page-alert" class="d-none alert alert-dismissible" role="alert">
			<span id="app-page-alert-message"></span>
			<button type="button" class="btn btn-sm" onclick="dismissAlert()"> <i class="fa fa-times"></i> </button>
		</div>
	</div>
</div>