<?php
include("init.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<?php include("head.php"); ?>

	<!-- Primary Meta Tags -->
	<title>Launch Your Dream E-commerce Store in Minutes</title>
	<meta name="title"
        content="E-commerce Website - Shop Online for Electronics, Fashion, Home Goods & More | Best Deals" />
    <meta name="description"
        content="Discover a wide range of products including electronics, fashion, home essentials, and more at our e-commerce website. Enjoy great deals, secure shopping, and fast delivery for all your online needs." />
    <meta name="keywords"
        content="e-commerce, online shopping, electronics, fashion, home goods, best deals, secure shopping, fast delivery, shop online, products, marketplace, business, e commerce websites, best e commerce sites, ecommerce shop" />

	<!-- Open Graph / Facebook -->
	<meta property="og:type" content="website" />
	<meta property="og:url" content="<?php echo $websiteTitle; ?>" />
	<meta property="og:title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
	<meta property="og:description" content="Plan to Start an Online Ecommerce Store ? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 2 mins!. No coding requires!.Best Shopify Alternative for small medium business owners" />
	<meta property="og:image" content="<?php echo $systemHostlink; ?>uploads/favicon.png" />

	<!-- Twitter -->
	<meta property="twitter:card" content="summary_large_image" />
	<meta property="twitter:url" content="<?php echo $websiteTitle; ?>" />
	<meta property="twitter:title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
	<meta property="twitter:description" content="Plan to Start an Online Ecommerce Store ? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 5 mins!. No coding requires!." />
	<meta property="twitter:image" content="<?php echo $systemHostlink; ?>uploads/logo.png" />

</head>

<body class="text-white bg-black">

	<!-- Navbar -->
	<?php include("menu.php"); ?>

	<main class="min-h-[calc(100vh-251.98px)]">
		<!-- Hero section -->
		<div class="lg:min-h-[750px] py-5 lg:py-0 flex items-center relative before:absolute before:top-0 before:left-0 before:bg-[#C11DD4] before:w-[250px] before:h-[10px] before:blur-[250px] after:absolute after:bottom-0 after:right-0 after:bg-[#32CAFD] after:w-[250px] after:h-[250px] after:blur-[250px] before:-z-[1] after:-z-[1] z-[1] home-section-1">
			<div class="container">
				<div class="items-center justify-between lg:flex">
					<div class="w-full max-w-[650px]" style="margin-bottom:40px !important">
						<h1 class="text-white text-[48px] font-bold leading-[135%]">Launch your <span class="text-primary-500">ecommerce website</span> tension free</h1>

						<p class="text-2xl font-medium leading-[135%] text-[#BDBDBD] mt-[22px]">Get your <b class="text-white"> website + hosting + domain + android app </b> as all in one package.</p>

						<!-- Input -->
						<form id="form-1" class="h-[74px] leading-[74px] bg-[#1B1B1B] px-[25px] rounded-full max-w-[500px] w-full mt-[38px] relative">
							<div class="flex items-center gap-1 text-[18px] font-medium leading-[55px] h-full mr-5">
								<input class="text-[#bebebe] bg-transparent w-full pr-14" placeholder="Mobile number" name="mobile" id="mobile">
							</div>

							<button type="submit" class="bg-primary-500 rounded-full px-8 h-[56px] text-white leading-[56px] lg:absolute lg:top-[50%] lg:right-[10px] lg:-translate-y-[50%] text-[18px] font-medium w-full lg:w-[unset]">Get Details</button>
						</form>
					</div>

					<div class="hidden lg:block">
						<img src="<?php echo $systemHostlink; ?>uploads/banner-img.png" alt="" class="w-full">
					</div>
				</div>
			</div>
		</div>

		<!-- Templates -->
		<section id="templates" class="bg-[#0A0A0A] py-20" id="templates">
			<div class="container">
				<div class="mx-auto text-center max-w-[700px] mb-[70px]">
					<h3 class="text-[40px] font-bold leading-[140%] text-white">Solution for <span class="text-[#FF9458]">every</span> <span class="text-[#FB62B7]">business</span></h3>

					<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">EXPLORE SOME EXAMPLES</p>
				</div>

				<div class="grid lg:grid-cols-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
					<?php
					for ($i = 1; $i <= 3; $i++) {
					?>
						<a href="#" target="_blank" class="bg-[#202226] py-[14px] px-[8px] rounded-[10px]">

							<div style="background-image: url('<?php echo $systemHostlink; ?>uploads/templates/general-merchandise.png'); transition: ease-in-out 5s;" class="h-[400px] w-full object-cover overflow-hidden rounded-[10px] bg-no-repeat bg-cover bg-left-top hover:bg-left-bottom"></div>

							<div class="h-[45px] rounded-[10px] font-semibold text-base text-[#44274A] mt-[8px] flex items-center justify-center" style="background: #E7CFFF">Fashion</div>

						</a>
						<a href="#" target="_blank" class="bg-[#202226] py-[14px] px-[8px] rounded-[10px]">

							<div style="background-image: url('<?php echo $systemHostlink; ?>uploads/templates/flower-shop.png'); transition: ease-in-out 5s;" class="h-[400px] w-full object-cover overflow-hidden rounded-[10px] bg-no-repeat bg-cover bg-left-top hover:bg-left-bottom"></div>

							<div class="h-[45px] rounded-[10px] font-semibold text-base text-[#44274A] mt-[8px] flex items-center justify-center" style="background: #FFD1EC">Jewellery</div>

						</a>
						<a href="#" target="_blank" class="bg-[#202226] py-[14px] px-[8px] rounded-[10px]">

							<div style="background-image: url('<?php echo $systemHostlink; ?>uploads/templates/fast-food-shop.png'); transition: ease-in-out 5s;" class="h-[400px] w-full object-cover overflow-hidden rounded-[10px] bg-no-repeat bg-cover bg-left-top hover:bg-left-bottom"></div>

							<div class="h-[45px] rounded-[10px] font-semibold text-base text-[#44274A] mt-[8px] flex items-center justify-center" style="background: #FFECD9">Fast Food Shop</div>

						</a>
						<a href="#" target="_blank" class="bg-[#202226] py-[14px] px-[8px] rounded-[10px]">

							<div style="background-image: url('<?php echo $systemHostlink; ?>uploads/templates/medicine-shop.png'); transition: ease-in-out 5s;" class="h-[400px] w-full object-cover overflow-hidden rounded-[10px] bg-no-repeat bg-cover bg-left-top hover:bg-left-bottom"></div>

							<div class="h-[45px] rounded-[10px] font-semibold text-base text-[#44274A] mt-[8px] flex items-center justify-center" style="background: #DBFFF9">Medicine Shop</div>

						</a>
					<?php
					}
					?>
				</div>
			</div>
		</section>

		<!-- Last but not least -->
		<section class="bg-[#0A0A0A] py-28" id="features">
			<div class="container">
				<div class="mx-auto text-center max-w-[500px] mb-[70px]">
					<h3 class="text-[40px] font-bold leading-[140%] text-white">What <span class="text-[#FF9458]">We</span> <span class="text-[#FB62B7]">Offer</span></h3>

					<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">A fully featured eCommerce Platform</p>
				</div>

				<div class="grid grid-cols-2 gap-5 sm:grid-cols-3 xl:grid-cols-7 lg:grid-cols-5">
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/easy-to-use.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Easy to use and efficient</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/no-code.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">No Code Platform</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/no-app.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">No Additional Apps Requires</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/manage-orders.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Manage Store Orders</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/product-reports.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Unique Product Reports</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/no-skills.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">No Technical Skills Requires</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/no-skills.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Update Order Status</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/no-skills.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Update Tracking Id & Courier name </span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/secure-payment.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Secure Payments</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/customer-based-report.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Customer Based Reports</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/coupon.jpeg" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Apply coupon code</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/order-track.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Track Order</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/custom-domain.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Custom domain</span>
					</div>
					<div class="bg-[#121212] border border-[#2A2A2A] rounded-2xl p-5 transition hover:bg-primary-500">
						<img src="<?php echo $systemHostlink; ?>uploads/features/custom-domain.png" alt="" class="w-[64px] h-[64px] mx-auto mb-3">
						<span class="block text-base font-semibold text-center">Import Bulk Order Status from Excel</span>
					</div>
				</div>
			</div>
		</section>

		<!-- Feature 1 -->
		<section class="bg-[#0A0A0A] py-28 relative before:absolute before:top-0 before:left-0 before:bg-[#32CAFD] before:w-[150px] before:h-[150px] before:blur-[250px] after:absolute after:bottom-10 after:right-0 after:bg-[#C11DD4] after:w-[150px] after:h-[150px] after:blur-[250px] before:-z-[1] after:-z-[1] z-[1]">
			<div class="container">
				<div class="grid lg:grid-cols-2 gap-[75px] items-center">
					<!-- Left -->
					<div>
						<h3 class="text-[40px] font-bold leading-[140%] text-white">Support for both <span class="text-[#369BF8]"> COD and Online payment </span> gateways </h3>

						<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">We offer complete convenience with multiple payment methods to suit your needs. Choose Cash on Delivery (COD) for a hassle-free doorstep payment, or enjoy the ease and security of Online Payments through trusted gateways. Shop confidently with flexible options that put you in control.</p>
					</div>

					<!-- Right -->
					<div class="flex justify-center lg:justify-end">
						<img src="<?php echo $systemHostlink; ?>uploads/feature-1.png" alt="" class="w-auto max-h-[307px] object-cover">
					</div>
				</div>
			</div>
		</section>

		<!-- Feature 2 -->
		<section class="py-28">
			<div class="container">
				<div class="grid lg:grid-cols-2 gap-[75px] items-center">
					<!-- Left -->
					<div class="flex justify-center lg:justify-start">
						<img src="<?php echo $systemHostlink; ?>uploads/feature-2.png" alt="" class="w-auto max-h-[307px] object-cover">
					</div>

					<!-- Right -->
					<div>
						<h3 class="text-[40px] font-bold leading-[140%] text-white">Easy reporting with <span class="text-[#41DB78]"> excel export </span>option</h3>

						<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">Monitor your business effortlessly with detailed order reports. View all order-related data in one place and export it to Excel for easy tracking, analysis, or offline record-keeping. Stay on top of your sales with streamlined reporting tools.</p>
					</div>
				</div>
			</div>
		</section>



		<section class="bg-[#0A0A0A] py-28 relative before:absolute before:top-0 before:left-0 before:bg-[#32CAFD] before:w-[150px] before:h-[150px] before:blur-[250px] after:absolute after:bottom-10 after:right-0 after:bg-[#C11DD4] after:w-[150px] after:h-[150px] after:blur-[250px] before:-z-[1] after:-z-[1] z-[1]" id="pricing">
			<div class="container">
				<div class="mx-auto text-center max-w-[750px] mb-[70px]">
					<h3 class="text-[40px] font-bold leading-[140%] text-white">Get started with a <span class="text-[#41DB78]">Affordable</span> plan and start your<span class="text-[#369BF8]"> online business</span></h3>
					<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">Contact us and get your personalized demo and start your ecomemrce business soon</p>
				</div>

				<div class="grid grid-cols-1 md:grid-cols-2 gap-5">
					<!-- Pricing Section -->
					<div class="lg:grid-cols-4">
						<div class="relative z-10 mb-10 rounded-[10px] border-2 border-stroke dark:border-dark-3 bg-[#121212] border-[#2A2A2A] py-10 px-8 shadow-pricing sm:p-12 lg:py-10 lg:px-6 xl:p-[50px]">
							<div class="h-[60px] bg-green-500 text-white absolute -top-[50px] left-0 w-full -z-[1] rounded-t-[10px] text-center font-semibold text-xl flex items-center justify-center">Exclusive Deals</div>
							<span class="mb-3 block text-lg font-semibold text-primary-500">Professional</span>
							<h2 class="mb-5 text-[30px] font-bold text-dark dark:text-white">
								<span>₹ 15,000</span> Only
							</h2>
							<p class="mb-8 border-b border-stroke dark:border-dark-3 pb-8 text-base text-body-color dark:text-dark-6">Kickstart Your E-commerce Business..</p>
							<div class="mb-9 flex flex-col gap-[14px]">
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									1 Ecommerce Android App
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									1 Ecommerce Website
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Cash On Delivery
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Online Payment Gateway
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									SMS Integration
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Mail Integration
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Quick Order Tracking
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									1 GB Hosting and 1 Domain Name
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Unlimited Categories
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Unlimited Products
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Unlimited Customers
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Unlimited Orders
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Unlimited Blogs
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Unlimited Pages
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Sales Reports
								</p>
								<p class="text-base text-body-color dark:text-dark-6 flex gap-3">
									<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
										<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
									</svg>
									Tele Support
								</p>
							</div>
						</div>
					</div>

					<!-- Contact Form Section -->
					<div class="p-8 bg-white rounded-lg shadow text-black">
						<form id="form-2" class="space-y-8">
							<div>
								<label for="name" class="block mb-3 text-base font-medium">Your Name</label>
								<input type="text"
									class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
									name="name" id="name" placeholder="Enter your name">
							</div>

							<div>
								<label for="mobile" class="block mb-3 text-base font-medium">Your Mobile</label>
								<input type="number"
									class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
									name="mobile" id="mobile" placeholder="Enter your mobile">
							</div>

							<div>
								<label for="email" class="block mb-3 text-base font-medium">Your Email</label>
								<input type="email"
									class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
									name="email" id="email" placeholder="Enter your email">
							</div>

							<div>
								<label for="whatsapp" class="block mb-3 text-base font-medium">Your Whatsapp</label>
								<input type="number"
									class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
									name="whatsapp" id="whatsapp" placeholder="Enter your whatsapp">
							</div>

							<div>
								<label for="business" class="block mb-3 text-base font-medium">Your Business
									Information</label>
								<input type="text"
									class="w-full px-4 py-3 text-base font-medium transition border-2 rounded-lg focus:border-primary"
									name="business" id="business" placeholder="Enter your business">
							</div>

							<div>
								<label for="message" class="block mb-3 text-base font-medium">Message</label>
								<textarea
									class="w-full px-4 py-3 text-base font-medium transition border-2 bg-[#e5e7eb] rounded-lg focus:border-primary"
									placeholder="Enter your message" name="message" id="message" rows="8"></textarea>
							</div>

							<p>
								<small>
									Please enter your information, so that our team can provide your the best solution
								</small>
							</p>
							<button type="submit" name="submit"
								class="w-full px-4 py-3 text-white bg-primary-500 rounded-md hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-600"
								onclick="sendMail()">Submit</button>
						</form>
					</div>
				</div>
			</div>
		</section>


		<section id="contact" class="py-10" itemscope itemtype="https://schema.org/FAQPage">
			<div class="container">
				<div class="mx-auto text-center max-w-[700px] mb-[70px]">
					<h3 class="text-[40px] font-bold leading-[140%] text-white">Contact <span class="text-[#41DB78]">Us</span></h3>
					<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">Have questions or need help? We're here for you!</p>
				</div>
				<div class="grid lg:grid-cols-3 grid-cols-1 sm:grid-cols-2 gap-10">

					<!-- Mobile -->
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Mobile</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
							<p class="text-gray-400 text-2xl flex items-center gap-3" itemprop="text">
								<a href="+917200296443" target="_blank">
									<i class='bx bxs-phone text-[#41DB78] text-3xl'></i> +91 72002 96443
								</a>
							</p>
						</div>
					</div>

					<!-- WhatsApp -->
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Whatsapp</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
							<p class="text-gray-400 text-2xl flex items-center gap-3" itemprop="text">
								<a href="https://wa.link/otkvy7" target="_blank">
									<i class='bx bxl-whatsapp text-[#41DB78] text-3xl'></i> +91 72002 96443
								</a>
							</p>
						</div>
					</div>

					<!-- Email -->
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Email</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
							<p class="text-gray-400 text-2xl flex items-center gap-3" itemprop="text">
								<a href="mailto:info@chenthurtech.com" target="_blank">
									<i class='bx bxs-envelope text-[#41DB78] text-3xl'></i> info@chenthurtech.com
								</a>
							</p>
						</div>
					</div>

				</div>
			</div>
		</section>


		<section id="faq" class="py-28" itemscope itemtype="https://schema.org/FAQPage">
			<div class="container">
				<div class="mx-auto text-center max-w-[700px] mb-[70px]">
					<h3 class="text-[40px] font-bold leading-[140%] text-white">Frequently asked <span class="text-[#41DB78]">questions</span></h3>

					<p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">Search for the questions that are frequently asked about <?php echo $websiteTitle; ?></p>
				</div>

				<div class="grid lg:grid-cols-3 grid-cols-1 sm:grid-cols-2 gap-10">
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">What is <?php echo $websiteTitle; ?></h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">

							<p class="text-gray-400" itemprop="text"><?php echo $websiteTitle; ?> is a DIY platform that allows anyone to create their dream online store within 2 minutes. It's an ideal solution for small and medium-scale business owners, including those running offline stores such as grocery shops, apparel stores, snack vendors, restaurants, homemade business owners, and more.</p>
						</div>
					</div>
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">How is <?php echo $websiteTitle; ?> different from other e-commerce platforms?</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">

							<p class="text-gray-400" itemprop="text"><?php echo $websiteTitle; ?> stands out for its simplicity. Unlike other platforms that may be complex, <?php echo $websiteTitle; ?> is designed to be easy to understand and use. There are no intricate processes, making it perfect for users with basic computer or mobile operating knowledge.</p>
						</div>
					</div>
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Is <?php echo $websiteTitle; ?> affordable compared to other e-commerce platforms?</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">

							<p class="text-gray-400" itemprop="text">Yes, the pricing for <?php echo $websiteTitle; ?> is more budget-friendly compared to other e-commerce platforms like Shopify, Dukaan, Wix, and Woocommerce. We believe in providing cost-effective solutions to cater to the needs of small and medium-sized businesses.</p>
						</div>
					</div>
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">What types of businesses is <?php echo $websiteTitle; ?> suitable for?</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">

							<p class="text-gray-400" itemprop="text"><?php echo $websiteTitle; ?> is perfect for a variety of businesses, including grocery stores, apparel shops, snack vendors, restaurants, and homemade business owners. It caters to the needs of small and medium-scale business owners looking to establish their online presence.</p>
						</div>
					</div>
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Do I need coding skills to use <?php echo $websiteTitle; ?>?</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">

							<p class="text-gray-400" itemprop="text">No, <?php echo $websiteTitle; ?> is a no-code platform. Basic computer or mobile operating knowledge is sufficient to run your store. The platform is designed to be user-friendly, allowing anyone to set up and manage their online store without the need for coding skills.</p>
						</div>
					</div>
					<div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
						<h3 class="mb-4 text-lg text-white min-h-[56px]" itemprop="name">Is there a free trial available?</h3>
						<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">

							<p class="text-gray-400" itemprop="text">While there isn't a traditional free trial, <?php echo $websiteTitle; ?> offers an introductory period of 1 month at Just ₹199 only. This gives you the opportunity to explore and use the platform. If you find it suitable for your needs, you can then choose to upgrade to one of our SIP plans, including Starter, Intermediate, and Professional plans.</p>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!-- footer -->
	</main>

	<footer>
		<?php include("footer.php"); ?>
	</footer>


</body>

</html>


<script>
	$(document).ready(function(e) {
		//form-content
		$("#form-1").on('submit', (function(e) {
			e.preventDefault();

			//mobile
			value = document.getElementById("mobile").value.trim();

			if (value == null || value === "") {
				showAlert(3, "Please enter mobile number.");
				document.getElementById("mobile").focus();

				return false;
			} else {
				var validMobile = validateMobileNumber(value);
				if (!validMobile) {
					showAlert(3, "Please enter valid 10 digit mobile number.");
					document.getElementById("mobile").focus();
					return false;
				}
			}

			loadingOpen();

			$.ajax({
				url: "mobile-enquiry-send-mail.php",
				type: "POST",
				contentType: false,
				cache: false,
				processData: false,
				data: new FormData(this),
				success: function(data) {
					data = data.trim();
					if (isNaN(data)) {
						showAlert(2, "Error : " + data);
						loadingClose();
					} else {
						if (data > 0) {
							showAlert(1, "Enquiry sent successfully.");
							loadingClose();
							window.location = "<?php echo $systemHostlink; ?>";
							//location.reload();
						} else {
							showAlert(3, "Error : " + data);
							loadingClose();
						}
					}
				},
				error: function() {
					showAlert(3, "Oops something went wrong. Please try later.");
					loadingClose();
				}
			});

		}));

	});
</script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
<script type="text/javascript">
	(function () {
		emailjs.init("d9_yW4ix6I7rxyv6a");
	})();
</script>

<script>
	function sendMail() {
		event.preventDefault(); // Prevent form from refreshing page

		var params = {

			email: document.getElementById("email").value,
			yourname: document.getElementById("name").value,
			mobile: document.getElementById("mobile").value,
			whatsapp: document.getElementById("whatsapp").value,
			business: document.getElementById("business").value,
			message: document.getElementById("message").value,
		};

		const serviceID = "service_i1nnodg";
		const templateID = "template_t70fp98";

		emailjs.send(serviceID, templateID, params)
			.then(res => {
				// Clear the form fields
				document.getElementById("form-2").reset();
				console.log(res);
				alert("Your message sent successfully!!");
			})
			.catch(err => console.log(err));
	}
</script>

<script>
	$(document).ready(function(e) {
		//form-content
		$("#form-2").on('submit', (function(e) {
			e.preventDefault();

			//name
			value = document.getElementById("name").value.trim();
			if (value == null || value == "") {
				showAlert(3, "Please enter name");
				document.getElementById("name").focus();
				return false;
			} else {
				let name = document.getElementById("name").value.trim();
				if (name.length < 3 || !/^[A-Za-z\s]+$/.test(name)) {
					showAlert(3, "Please enter a valid name with a minimum of 3 characters, only alphabets allowed.");
					document.getElementById("name").focus();
					return false;
				}
			}

			//mobile
			value = document.getElementById("mobile").value.trim();
			if (value == null || value === "") {
				showAlert(3, "Please enter mobile number.");
				document.getElementById("mobile").focus();

				return false;
			} else {
				var validMobile = validateMobileNumber(value);
				if (!validMobile) {
					showAlert(3, "Please enter valid 10 digit mobile number.");
					document.getElementById("mobile").focus();
					return false;
				}
			}

			//business
			value = document.getElementById("business").value.trim();
			if (value == null || value == "") {
				showAlert(3, "Please enter your business");
				document.getElementById("business").focus();
				return false;
			}

			//message
			value = document.getElementById("message").value.trim();
			if (value == null || value == "") {
				showAlert(3, "Please enter message");
				document.getElementById("message").focus();
				return false;
			}

			loadingOpen();

			$.ajax({
				url: "contact-enquiry-send-mail.php",
				type: "POST",
				contentType: false,
				cache: false,
				processData: false,
				data: new FormData(this),
				success: function(data) {
					data = data.trim();
					if (isNaN(data)) {
						showAlert(2, "Error : " + data);
						loadingClose();
					} else {
						if (data > 0) {
							showAlert(1, "Enquiry sent successfully.");
							loadingClose();
							window.location = "<?php echo $systemHostlink; ?>";
							//location.reload();
						} else {
							showAlert(3, "Error : " + data);
							loadingClose();
						}
					}
				},
				error: function() {
					showAlert(3, "Oops something went wrong. Please try later.");
					loadingClose();
				}
			});

		}));

	});
</script>