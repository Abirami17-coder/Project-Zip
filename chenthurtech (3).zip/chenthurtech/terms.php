<?php
include("init.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include("head.php"); ?>

    <!-- Primary Meta Tags -->
    <title>BulkSms - Your Dream Online Store within 2 mins | ChenthurTech</title>
    <meta name="title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
    <meta name="description"
        content="Plan to Start an Online Ecommerce Store? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 2 mins!. No coding requires!.Best Shopify alternative for small medium business owners." />

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website" />
    <meta property="og:url" content="<?php echo $websiteTitle; ?>" />
    <meta property="og:title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
    <meta property="og:description"
        content="Plan to Start an Online Ecommerce Store ? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 2 mins!. No coding requires!.Best Shopify Alternative for small medium business owners" />
    <meta property="og:image" content="<?php echo $systemHostlink; ?>uploads/favicon.png" />

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image" />
    <meta property="twitter:url" content="<?php echo $websiteTitle; ?>" />
    <meta property="twitter:title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
    <meta property="twitter:description"
        content="Plan to Start an Online Ecommerce Store ? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 5 mins!. No coding requires!." />
    <meta property="twitter:image" content="<?php echo $systemHostlink; ?>uploads/logo.png" />

</head>

<body class="text-white bg-black">

    <!-- Navbar -->
    <?php include("menu.php"); ?>

    <main class="min-h-[calc(100vh-251.98px)]">
        <!-- Hero section -->



        <section id="faq" class="py-28" itemscope itemtype="https://schema.org/FAQPage">
            <div class="container">
                <div class="mx-auto text-center max-w-[700px] mb-[70px]">
                    <h3 class="text-[40px] font-bold leading-[140%] text-white">Terms and <span
                            class="text-[#41DB78]">Conditions</span></h3>
                </div>


                <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
                    <h3 class="mb-4 text-lg text-white min-h-[96px] w-full" itemprop="name">
                        Our website
                    </h3>
                    <p class="text-base leading-relaxed text-gray-400">
                        Our website address is:
                        <a href="https://www.theeducamps.com" target="_blank" rel="noopener noreferrer"
                            class="text-green-400 hover:text-green-300">
                            https://www.theeducamps.com
                        </a>
                    </p>

                    <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">

                        <p class="text-gray-400" itemprop="text">We dont operate from anyother apps or website</p>
                    </div>
                    <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
                        <h3 class="mt-4 text-lg text-white min-h-[96px] w-full" itemprop="name">
                            Definitions of basic terms, rights and restriction:
                        </h3>
                        <div class=" text-gray-400 p-6 rounded-lg w-full mt-4">
                            <div class="space-y-2  w-full">
                                <p>1. Members must be at least 12 years of age.</p>
                                <p>2. Members are granted a time-limited, non-exclusive, revocable, nontransferable, and
                                    non-sublicensable right to access that portion of the online course corresponding to
                                    the purchase.</p>
                                <p>3. The portion of the online course corresponding to the purchase will be available
                                    to the Member as long as the course is maintained by the Company, which will be a
                                    minimum of one year after Member’s purchase.</p>
                                <p>4. The videos in the course are provided as a video stream and are not downloadable.
                                </p>
                                <p>5. By agreeing to grant such access, the Company does not obligate itself to maintain
                                    the course, or to maintain it in its present form.</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>

        <!-- footer -->
    </main>

    <footer>
        <?php include("footer.php"); ?>
    </footer>


</body>

</html>


<script>
    $(document).ready(function (e) {
        //form-content
        $("#form-1").on('submit', (function (e) {
            e.preventDefault();

            //mobile
            value = document.getElementById("mobile").value.trim();

            if (value == null || value === "") {
                showAlert(3, "Please enter mobile number.");
                document.getElementById("mobile").focus();

                return false;
            } else {
                var validMobile = validateMobileNumber(value);
                if (!validMobile) {
                    showAlert(3, "Please enter valid 10 digit mobile number.");
                    document.getElementById("mobile").focus();
                    return false;
                }
            }

            loadingOpen();

            $.ajax({
                url: "mobile-enquiry-send-mail.php",
                type: "POST",
                contentType: false,
                cache: false,
                processData: false,
                data: new FormData(this),
                success: function (data) {
                    data = data.trim();
                    if (isNaN(data)) {
                        showAlert(2, "Error : " + data);
                        loadingClose();
                    } else {
                        if (data > 0) {
                            showAlert(1, "Enquiry sent successfully.");
                            loadingClose();
                            window.location = "<?php echo $systemHostlink; ?>";
                            //location.reload();
                        } else {
                            showAlert(3, "Error : " + data);
                            loadingClose();
                        }
                    }
                },
                error: function () {
                    showAlert(3, "Oops something went wrong. Please try later.");
                    loadingClose();
                }
            });

        }));

    });
</script>

<script>
    $(document).ready(function (e) {
        //form-content
        $("#form-2").on('submit', (function (e) {
            e.preventDefault();

            //name
            value = document.getElementById("name").value.trim();
            if (value == null || value == "") {
                showAlert(3, "Please enter name");
                document.getElementById("name").focus();
                return false;
            } else {
                let name = document.getElementById("name").value.trim();
                if (name.length < 3 || !/^[A-Za-z\s]+$/.test(name)) {
                    showAlert(3, "Please enter a valid name with a minimum of 3 characters, only alphabets allowed.");
                    document.getElementById("name").focus();
                    return false;
                }
            }

            //mobile
            value = document.getElementById("mobile").value.trim();
            if (value == null || value === "") {
                showAlert(3, "Please enter mobile number.");
                document.getElementById("mobile").focus();

                return false;
            } else {
                var validMobile = validateMobileNumber(value);
                if (!validMobile) {
                    showAlert(3, "Please enter valid 10 digit mobile number.");
                    document.getElementById("mobile").focus();
                    return false;
                }
            }

            //business
            value = document.getElementById("business").value.trim();
            if (value == null || value == "") {
                showAlert(3, "Please enter your business");
                document.getElementById("business").focus();
                return false;
            }

            //message
            value = document.getElementById("message").value.trim();
            if (value == null || value == "") {
                showAlert(3, "Please enter message");
                document.getElementById("message").focus();
                return false;
            }

            loadingOpen();

            $.ajax({
                url: "contact-enquiry-send-mail.php",
                type: "POST",
                contentType: false,
                cache: false,
                processData: false,
                data: new FormData(this),
                success: function (data) {
                    data = data.trim();
                    if (isNaN(data)) {
                        showAlert(2, "Error : " + data);
                        loadingClose();
                    } else {
                        if (data > 0) {
                            showAlert(1, "Enquiry sent successfully.");
                            loadingClose();
                            window.location = "<?php echo $systemHostlink; ?>";
                            //location.reload();
                        } else {
                            showAlert(3, "Error : " + data);
                            loadingClose();
                        }
                    }
                },
                error: function () {
                    showAlert(3, "Oops something went wrong. Please try later.");
                    loadingClose();
                }
            });

        }));

    });
</script>