<?php
//session checker
session_start();
ob_start();

error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

include('mail-controller.php');
$mailController = new MailController();


//system variable
$systemHostlink = "http://$_SERVER[HTTP_HOST]" . "/chenthurtech/";
$systemPagelink = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$systemPathLink = "$_SERVER[REQUEST_URI]";
$systemImage404 = $systemHostlink . "media/system/image404.png";

$websiteTitle = "Ecommerce";
$adminMailId = "ramyaj.tkp@gmail.com";
$companyAddress = "The King Phoenix, Palakarai, Trichy.";
?>

