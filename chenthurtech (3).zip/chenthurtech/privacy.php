<?php
include("init.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<?php include("head.php"); ?>

	<!-- Primary Meta Tags -->
	<title>Matrimony - Your Dream Online Store within 2 mins | ChenthurTech</title>
	<meta name="title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
	<meta name="description" content="Plan to Start an Online Ecommerce Store? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 2 mins!. No coding requires!.Best Shopify alternative for small medium business owners." />

	<!-- Open Graph / Facebook -->
	<meta property="og:type" content="website" />
	<meta property="og:url" content="<?php echo $websiteTitle; ?>" />
	<meta property="og:title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
	<meta property="og:description" content="Plan to Start an Online Ecommerce Store ? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 2 mins!. No coding requires!.Best Shopify Alternative for small medium business owners" />
	<meta property="og:image" content="<?php echo $systemHostlink; ?>uploads/favicon.png" />

	<!-- Twitter -->
	<meta property="twitter:card" content="summary_large_image" />
	<meta property="twitter:url" content="<?php echo $websiteTitle; ?>" />
	<meta property="twitter:title" content="<?php echo $websiteTitle; ?> - Your Dream Online Store within 2 mins" />
	<meta property="twitter:description" content="Plan to Start an Online Ecommerce Store ? <?php echo $websiteTitle; ?> helps you to Create a beautiful E com website within 5 mins!. No coding requires!." />
	<meta property="twitter:image" content="<?php echo $systemHostlink; ?>uploads/logo.png" />

</head>

<body class="text-white bg-black">

	<!-- Navbar -->
	<?php include("menu.php"); ?>
   
		<section id="faq" class="py-28" itemscope itemtype="https://schema.org/FAQPage">
			<div class="container">
				<div class="mx-auto text-center max-w-[700px] mb-[70px]">
					<h3 class="text-[40px] font-bold leading-[140%] text-white">Privacy <span
					class="text-[#41DB78]">Policy</span></h3>
                    <p class="text-[17px] leading-[28px] text-[#BDBDBD] mt-[22px]">This Privacy Policy is applicable for anyone involves with the 
                      registering and course engagement at The Edu Camps.
                     </p>
                </div>
                   	<h3 class="mb-4 text-lg text-white min-h-[96px]" itemprop="name">Availability of Website</h3>

                    <ul>
                        <li>
                              <p class="text-gray-400" itemprop="text">1. Member recognizes that the traffic of data through the Internet may cause delays during the download of information from the website and accordingly, it shall not hold the Company liable for delays that are ordinary in the course of Internet use.</p>
                        </li>
                        <li>
                                 <p class="text-gray-400" itemprop="text">2. Member further acknowledges and accepts that the website will not be available on a continual twenty-four-hour basis due to such delays, or delays caused by the Company’s upgrading, modification, or standard maintenance of the website.</p>
                        </li>
                        
                   </ul>

                   	<h3 class="mb-4 mt-4 text-lg text-white min-h-[96px]" itemprop="name">Intellectual Property Rights</h3>

                    <ul>
                        <li>
                              <p class="text-gray-400" itemprop="text">1. The online course is owned by the Company and is protected by Indian and international copyright, trademark, patent, trade secret and other intellectual property or proprietary rights laws.</p>
                        </li>
                        <li>
                                 <p class="text-gray-400" itemprop="text">2. No right, title or interest in or to the online course or any portion thereof, is transferred to any Member, and all rights not expressly granted herein, are reserved by the Company.</p>
                        </li>
                         <li>
                                 <p class="text-gray-400" itemprop="text">3. The Company name, the Company logo, and all related names, logos, product and service names, designs and slogans are trademarks of the Company. Member may not use such marks without the prior written permission of the Company.</p>
                        </li>
                        
                   </ul>
                   	<h3 class="mb-4 mt-4 text-lg text-white min-h-[96px]" itemprop="name">Company Obligations</h3>

                    <ul>
                        <li>
                              <p class="text-gray-400" itemprop="text">The Company will use commercially reasonable efforts to enable the online course to be accessible, except for scheduled maintenance and required repairs, and except for any interruption due to causes beyond the reasonable control of, or not reasonably foreseeable by the Company.</p>
                        </li>
                    </ul>

                    	<h3 class="mb-4 mt-4 text-lg text-white min-h-[96px]" itemprop="name">Governing Law and Venue</h3>

                    <ul>
                        <li>
                              <p class="text-gray-400" itemprop="text">1. These Terms of Service are construed and governed by the laws of the government of India</p>
                        </li>
                        <li>
                                 <p class="text-gray-400" itemprop="text">2. If any of the provisions, either in whole or in part, of the contract is or becomes invalid or unenforceable, this shall not serve to invalidate the remaining provisions thereof.</p>
                        </li>
                        
                     </ul>
                    
            </div>
		</section>

		
    </main>
   
	<!-- footer -->
	<footer>
		<?php include("footer.php"); ?>
	</footer>

</body>

</html>


<script>
	$(document).ready(function(e) {
		//form-content
		$("#form-1").on('submit', (function(e) {
			e.preventDefault();

			//mobile
			value = document.getElementById("mobile").value.trim();

			if (value == null || value === "") {
				showAlert(3, "Please enter mobile number.");
				document.getElementById("mobile").focus();

				return false;
			} else {
				var validMobile = validateMobileNumber(value);
				if (!validMobile) {
					showAlert(3, "Please enter valid 10 digit mobile number.");
					document.getElementById("mobile").focus();
					return false;
				}
			}

			loadingOpen();

			$.ajax({
				url: "mobile-enquiry-send-mail.php",
				type: "POST",
				contentType: false,
				cache: false,
				processData: false,
				data: new FormData(this),
				success: function(data) {
					data = data.trim();
					if (isNaN(data)) {
						showAlert(2, "Error : " + data);
						loadingClose();
					} else {
						if (data > 0) {
							showAlert(1, "Enquiry sent successfully.");
							loadingClose();
							window.location = "<?php echo $systemHostlink; ?>";
							//location.reload();
						} else {
							showAlert(3, "Error : " + data);
							loadingClose();
						}
					}
				},
				error: function() {
					showAlert(3, "Oops something went wrong. Please try later.");
					loadingClose();
				}
			});

		}));

	});
</script>

<script>
	$(document).ready(function(e) {
		//form-content
		$("#form-2").on('submit', (function(e) {
			e.preventDefault();

			//name
			value = document.getElementById("name").value.trim();
			if (value == null || value == "") {
				showAlert(3, "Please enter name");
				document.getElementById("name").focus();
				return false;
			} else {
				let name = document.getElementById("name").value.trim();
				if (name.length < 3 || !/^[A-Za-z\s]+$/.test(name)) {
					showAlert(3, "Please enter a valid name with a minimum of 3 characters, only alphabets allowed.");
					document.getElementById("name").focus();
					return false;
				}
			}

			//mobile
			value = document.getElementById("mobile").value.trim();
			if (value == null || value === "") {
				showAlert(3, "Please enter mobile number.");
				document.getElementById("mobile").focus();

				return false;
			} else {
				var validMobile = validateMobileNumber(value);
				if (!validMobile) {
					showAlert(3, "Please enter valid 10 digit mobile number.");
					document.getElementById("mobile").focus();
					return false;
				}
			}

			//business
			value = document.getElementById("business").value.trim();
			if (value == null || value == "") {
				showAlert(3, "Please enter your business");
				document.getElementById("business").focus();
				return false;
			}

			//message
			value = document.getElementById("message").value.trim();
			if (value == null || value == "") {
				showAlert(3, "Please enter message");
				document.getElementById("message").focus();
				return false;
			}

			loadingOpen();

			$.ajax({
				url: "contact-enquiry-send-mail.php",
				type: "POST",
				contentType: false,
				cache: false,
				processData: false,
				data: new FormData(this),
				success: function(data) {
					data = data.trim();
					if (isNaN(data)) {
						showAlert(2, "Error : " + data);
						loadingClose();
					} else {
						if (data > 0) {
							showAlert(1, "Enquiry sent successfully.");
							loadingClose();
							window.location = "<?php echo $systemHostlink; ?>";
							//location.reload();
						} else {
							showAlert(3, "Error : " + data);
							loadingClose();
						}
					}
				},
				error: function() {
					showAlert(3, "Oops something went wrong. Please try later.");
					loadingClose();
				}
			});

		}));

	});
</script>