<!-- Top -->
<div class="py-10 border-t border-gray-900">
	<div class="container">
		<div class="items-center justify-between lg:flex">
			<div class="flex items-center gap-6">
				<a href="<?php echo $systemHostlink; ?>" class="text-[26px] font-light text-white">
					<img src="<?php echo $systemHostlink; ?>/uploads/logo.png" alt="" class="max-h-[55px]">
				</a>
			</div>

			<ul class="flex flex-wrap items-center gap-6 pt-5 mt-5 border-t lg:border-t-0 lg:pt-0 lg:mt-0">
				<li><a href="terms.php" class="text-base transition hover:underline">Terms and Conditions</a></li>
				<li><a href="privacy.php" class="text-base transition hover:underline">Privacy Policies</a></li>
				<li><a href="refund.php" class="text-base transition hover:underline">Refund Policies</a></li>
				<li><a href="#" class="text-base transition hover:underline">Partner With Us</a></li>
			</ul>
		</div>
	</div>
</div>

<!-- Bottom -->
<div class="py-7 bg-[#0d0d0d]">
	<div class="container">
		<div class="flex items-center justify-between">
			<p class="text-sm text-gray-200">Powered by <a href="https://thekingphoenix.com/" target="_blank"> The King Phoenix </a> @ All Rights Reserved, 2025.</p>

			<div class="items-center gap-7 lg:flex">
				<div class="flex items-center gap-2">
					<a href="#" target="_blank" class="w-[44px] h-[44px] block rounded-full text-center leading-[54px] transition hover:bg-primary-500 hover:shadow">
						<i class='text-2xl bx bxl-facebook'></i>
					</a>

					<a href="#" target="_blank" class="w-[44px] h-[44px] block rounded-full text-center leading-[54px] transition hover:bg-primary-500 hover:shadow">
						<i class='text-2xl bx bxl-instagram'></i>
					</a>

					<a href="#" target="_blank" class="w-[44px] h-[44px] block rounded-full text-center leading-[54px] transition hover:bg-primary-500 hover:shadow">
						<i class='text-2xl bx bxl-twitter'></i>
					</a>

					<a href="#" target="_blank" class="w-[44px] h-[44px] block rounded-full text-center leading-[54px] transition hover:bg-primary-500 hover:shadow">
						<i class='text-2xl bx bxl-youtube'></i>
					</a>

					<a href="#" target="_blank" class="w-[44px] h-[44px] block rounded-full text-center leading-[54px] transition hover:bg-primary-500 hover:shadow">
						<i class='text-2xl bx bxl-linkedin-square'></i>
					</a>
				</div>

				<div class="items-center hidden gap-2 text-sm text-gray-200 lg:flex">
					Made In <img src="<?php echo $systemHostlink; ?>uploads/india.svg" alt="">
				</div>
			</div>
		</div>
	</div>
</div>




<script>
	// mobile menu
	function toggleMenu() {
		let mobileMenu = document.getElementById("mobileMenu");

		if (mobileMenu.classList.contains("-left-[9999%]")) {
			mobileMenu.classList.add("left-0");
			mobileMenu.classList.remove("-left-[9999%]");
		} else {
			mobileMenu.classList.add("-left-[9999%]");
			mobileMenu.classList.remove("left-0");
		}
	}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<script src="<?php echo $systemHostlink; ?>assets/js/jquery-3.7.0.min.js"></script>
<script src="<?php echo $systemHostlink; ?>assets/js/app.js"></script>
<script src="<?php echo $systemHostlink; ?>assets/js/simple_validation.js"></script>